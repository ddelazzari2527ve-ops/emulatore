using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.Windows.Forms;

namespace DigitalTwinManager
{
    /// <summary>
    /// Card della dashboard che mostra titolo, valore numerico grande e unità di misura.
    /// Il font del valore si adatta automaticamente allo spazio disponibile (vedi AdjustFontSize).
    /// </summary>
    public sealed class ValueCard : RoundedPanel
    {
        private readonly Label _titleLabel;
        private readonly Label _valueLabel;
        private readonly Label _unitLabel;

        public string Title
        {
            get => _titleLabel.Text;
            set => _titleLabel.Text = value?.ToUpperInvariant() ?? string.Empty;
        }

        public string Value
        {
            get => _valueLabel.Text;
            set
            {
                _valueLabel.Text = FormatValueText(value);
                AdjustFontSize();
            }
        }

        public string Unit
        {
            get => _unitLabel.Text;
            set => _unitLabel.Text = value;
        }

        private Color _accentColor = Color.FromArgb(0x00, 0xD4, 0xFF);

        public Color AccentColor
        {
            get => _accentColor;
            set
            {
                _accentColor  = value;
                _valueLabel.ForeColor = value;
                _unitLabel.ForeColor  = Color.FromArgb(160,
                    Math.Min(255, value.R + 20),
                    Math.Min(255, value.G + 20),
                    Math.Min(255, value.B + 20));
                Invalidate();
            }
        }

        public ValueCard()
        {
            BackColor    = Color.FromArgb(0x2A, 0x2A, 0x2A);
            CornerRadius = 20;
            Padding      = new Padding(14, 12, 14, 10);
            MinimumSize  = new Size(300, 170);
            Size         = new Size(340, 190);

            _titleLabel = new Label
            {
                AutoSize  = false,
                Dock      = DockStyle.Fill,
                Font      = new Font("Segoe UI", 8F, FontStyle.Bold),
                ForeColor = Color.FromArgb(0x8A, 0x9B, 0xBD),
                TextAlign = ContentAlignment.BottomCenter,
                BackColor = Color.Transparent,
                Padding   = new Padding(0, 0, 0, 2)
            };

            _valueLabel = new Label
            {
                AutoSize = false,
                Dock     = DockStyle.Fill,
                Font     = new Font("Segoe UI", 48F, FontStyle.Bold),
                ForeColor = _accentColor,
                TextAlign = ContentAlignment.MiddleCenter,
                UseCompatibleTextRendering = true,
                BackColor = Color.Transparent,
                Padding   = new Padding(0)
            };

            _unitLabel = new Label
            {
                AutoSize  = false,
                Dock      = DockStyle.Fill,
                Font      = new Font("Segoe UI", 10F, FontStyle.Regular),
                ForeColor = Color.FromArgb(160, _accentColor.R, _accentColor.G, _accentColor.B),
                TextAlign = ContentAlignment.TopCenter,
                BackColor = Color.Transparent,
                Padding   = new Padding(0, 2, 0, 0)
            };

            // Layout a tre righe: titolo (18%), valore (62%), unità (20%).
            var layout = new TableLayoutPanel
            {
                Dock        = DockStyle.Fill,
                BackColor   = Color.Transparent,
                ColumnCount = 1,
                RowCount    = 3,
                Padding     = new Padding(0),
                Margin      = new Padding(0),
                AutoSize    = false
            };
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 18F));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 62F));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));

            layout.Controls.Add(_titleLabel, 0, 0);
            layout.Controls.Add(_valueLabel, 0, 1);
            layout.Controls.Add(_unitLabel,  0, 2);

            Controls.Add(layout);
        }

        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            // IsHandleCreated evita di ricalcolare il font durante la costruzione del controllo,
            // quando ClientSize non è ancora affidabile.
            if (IsHandleCreated && _valueLabel != null)
                AdjustFontSize();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            // Barra di accento inferiore con estremità arrotondate.
            int margin = Padding.Left + 6;
            int left   = margin;
            int right  = Width - margin - 1;
            int y      = Height - 6;

            using var pen = new Pen(_accentColor, 3f) { StartCap = LineCap.Round, EndCap = LineCap.Round };
            g.DrawLine(pen, left, y, right, y);

            // Sfumatura chiara nella parte alta della card per dare un minimo di profondità/rilievo.
            using var topBrush = new LinearGradientBrush(
                new Rectangle(0, 0, Width, 40),
                Color.FromArgb(18, 255, 255, 255),
                Color.Transparent,
                LinearGradientMode.Vertical);
            using var topPath = RoundedPanel.GetRoundPath(
                new Rectangle(1, 1, Width - 2, 38), CornerRadius);
            g.FillPath(topBrush, topPath);
        }

        // Toglie i decimali inutili: valori interi mostrati senza virgola, gli altri con una sola cifra
        // decimale. Se il testo non è un numero valido (es. "N/A") viene restituito invariato.
        private static string FormatValueText(string text)
        {
            if (decimal.TryParse(text, NumberStyles.Any, CultureInfo.InvariantCulture, out var value))
            {
                return value % 1 == 0
                    ? value.ToString("0",   CultureInfo.InvariantCulture)
                    : value.ToString("0.0", CultureInfo.InvariantCulture);
            }
            return text;
        }

        /// <summary>
        /// Trova, per tentativi, la dimensione di font più grande (partendo da 72pt, passi di 1.5pt)
        /// che permette al testo di stare in un'unica riga dentro lo spazio disponibile della label.
        /// Necessario perché il valore mostrato può variare molto in lunghezza (es. "5" vs "1234.5")
        /// e un font fisso o sarebbe troppo piccolo per i numeri corti o "esploderebbe" fuori dalla card
        /// per quelli lunghi.
        /// </summary>
        private void AdjustFontSize()
        {
            if (_valueLabel == null || string.IsNullOrEmpty(_valueLabel.Text)) return;
            try
            {
                const int padX = 10;
                const int padY = 6;

                int availW = _valueLabel.ClientSize.Width  - padX * 2;
                int availH = _valueLabel.ClientSize.Height - padY * 2;
                if (availW <= 0 || availH <= 0) return;

                string text   = _valueLabel.Text;
                var    family = _valueLabel.Font.FontFamily;
                var    style  = _valueLabel.Font.Style;

                float   fontSize = 72f;
                Font?   bestFont = null;

                while (fontSize >= 11f)
                {
                    using var testFont = new Font(family, fontSize, style);
                    var size = TextRenderer.MeasureText(text, testFont,
                        new Size(int.MaxValue, int.MaxValue),
                        TextFormatFlags.SingleLine | TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix);

                    if (size.Width <= availW && size.Height <= availH)
                    {
                        bestFont = new Font(family, fontSize, style);
                        break;
                    }
                    fontSize -= 1.5f;
                }

                // Se nemmeno 11pt entra nello spazio disponibile, si usa comunque 11pt come minimo
                // leggibile piuttosto che continuare a rimpicciolire all'infinito.
                bestFont ??= new Font(family, 11f, style);

                if (_valueLabel.Font.Size != bestFont.Size)
                    _valueLabel.Font = bestFont;
                else
                    bestFont.Dispose();
            }
            catch
            {
                // Fallback difensivo: in caso di problemi nel calcolo (es. font di sistema mancante)
                // meglio mostrare un valore leggibile che lanciare un'eccezione durante il paint.
                _valueLabel.Font = new Font("Segoe UI", 12f, FontStyle.Bold);
            }
        }
    }
}