using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace DigitalTwinManager
{
    /// <summary>
    /// Panel con angoli arrotondati, usato come base per gli altri controlli custom della UI
    /// (ValueCard, ParameterControl, ecc.) per ottenere uno stile coerente in tutta l'app.
    /// </summary>
    public class RoundedPanel : Panel
    {
        public int CornerRadius { get; set; } = 20;

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            // Rettangolo ridotto di 1px per evitare che il bordo venga tagliato ai margini del controllo.
            var bounds = new Rectangle(1, 1, Width - 2, Height - 2);
            using var path = GetRoundPath(bounds, CornerRadius);

            using var borderPen = new Pen(Color.FromArgb(55, 130, 150, 200), 1.2f);
            g.DrawPath(borderPen, path);
        }

        /// <summary>
        /// Costruisce un GraphicsPath rettangolare con i quattro angoli arrotondati.
        /// Riutilizzato anche da altri controlli (es. ValueCard, ParameterControl) che devono
        /// disegnare forme coerenti con questo pannello, quindi è pubblico e statico.
        /// </summary>
        public static GraphicsPath GetRoundPath(Rectangle bounds, int radius)
        {
            int d    = radius * 2;
            var path = new GraphicsPath();
            path.AddArc(bounds.X,               bounds.Y,                d, d, 180, 90);
            path.AddArc(bounds.Right - d,        bounds.Y,                d, d, 270, 90);
            path.AddArc(bounds.Right - d,        bounds.Bottom - d,       d, d,   0, 90);
            path.AddArc(bounds.X,               bounds.Bottom - d,       d, d,  90, 90);
            path.CloseFigure();
            return path;
        }
    }
}