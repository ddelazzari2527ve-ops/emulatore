using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace DigitalTwinManager
{
    /// <summary>
    /// Controllo per impostare un parametro numerico: slider (TrackBar) + input numerico,
    /// con titolo, descrizione e unità di misura. Slider e input restano sempre sincronizzati.
    /// </summary>
    public sealed class ParameterControl : RoundedPanel
    {
        public TrackBar      Track   { get; private set; }
        public NumericUpDown Numeric { get; private set; }

        // Nessun listener collegato di default: l'evento è pensato per essere usato dal form
        // che ospita il controllo, quindi il warning "mai invocato" va soppresso qui.
#pragma warning disable CS0067
        public event EventHandler? ValueChanged;
#pragma warning restore CS0067

        private readonly Label _titleLabel;
        private readonly Label _descLabel;
        private readonly Label _unitLabel;

        private Color   _accentColor = Color.FromArgb(0x00, 0xB4, 0xD8);
        private decimal _minValue;
        private decimal _maxValue;

        // Fattore di scala usato per rappresentare i decimali come interi nel TrackBar
        // (che lavora solo con Int32). Vedi UpdateTrackRange/ToScaledInt/ToUnscaledValue.
        private int _scale = 1;

        // Costanti di layout: dimensioni e spaziature dei controlli interni.
        private const int PAD_H     = 14;
        private const int PAD_V     = 11;
        private const int NUMERIC_W = 96;
        private const int NUMERIC_H = 28;
        private const int TRACK_H   = 20;
        private const int ACCENT_W  =  4;
        private const int ACCENT_R  = ACCENT_W + 8;

        // Timer per l'effetto "flash" di evidenziazione quando il valore cambia.
        private readonly System.Windows.Forms.Timer _hlTimer = new();
        private bool _highlighted;

        public string Title
        {
            get => _titleLabel.Text;
            set => _titleLabel.Text = value;
        }

        public string Description
        {
            get => _descLabel.Text;
            set => _descLabel.Text = value;
        }

        public string Unit
        {
            get => _unitLabel.Text;
            set => _unitLabel.Text = value;
        }

        // Minimum/Maximum aggiornano anche il NumericUpDown e ricalcolano il range dello slider,
        // quindi vanno sempre impostati tramite queste proprietà e non modificando Numeric/Track direttamente.
        public decimal Minimum
        {
            get => _minValue;
            set { _minValue = value; Numeric.Minimum = value; UpdateTrackRange(); }
        }

        public decimal Maximum
        {
            get => _maxValue;
            set { _maxValue = value; Numeric.Maximum = value; UpdateTrackRange(); }
        }

        // Value tiene sincronizzati slider e input numerico e ignora l'assegnazione se il valore
        // (clampato tra Minimum e Maximum) è già quello corrente, per evitare eventi ValueChanged inutili.
        public decimal Value
        {
            get => Numeric.Value;
            set
            {
                value = Math.Max(Minimum, Math.Min(Maximum, value));
                if (Numeric.Value == value) return;
                Numeric.Value = value;
                Track.Value   = Clamp(ToScaledInt(value));
            }
        }

        public int DecimalPlaces
        {
            get => Numeric.DecimalPlaces;
            set
            {
                Numeric.DecimalPlaces = value;
                Numeric.Increment     = (decimal)Math.Pow(0.1, value);
                UpdateTrackRange();     // il range dello slider dipende dalla scala legata ai decimali
            }
        }

        public ParameterControl()
        {
            CornerRadius = 14;
            BackColor    = Color.FromArgb(0x16, 0x21, 0x3E);
            MinimumSize  = new Size(320, 130);
            AutoSize     = true;
            AutoSizeMode = AutoSizeMode.GrowOnly;
            Padding      = new Padding(ACCENT_R + PAD_H, PAD_V, PAD_H, PAD_V);

            _titleLabel = new Label
            {
                AutoSize     = false,
                Dock         = DockStyle.Top,
                Height       = 20,
                Font         = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor    = Color.FromArgb(0xD8, 0xEA, 0xFF),
                TextAlign    = ContentAlignment.MiddleLeft,
                BackColor    = Color.Transparent,
                AutoEllipsis = false,
                Padding      = new Padding(0)
            };

            _descLabel = new Label
            {
                AutoSize  = true,
                Dock      = DockStyle.Top,
                Font      = new Font("Segoe UI", 7F, FontStyle.Italic),
                ForeColor = Color.FromArgb(0x5A, 0x6E, 0x99),
                BackColor = Color.Transparent,
                Padding   = new Padding(0, 1, 0, 3)
            };

            Track = new TrackBar
            {
                TickStyle = TickStyle.None,
                Height    = TRACK_H,
                Dock      = DockStyle.Top,
                BackColor = Color.FromArgb(0x16, 0x21, 0x3E),
                Margin    = new Padding(0, 2, 0, 0)
            };

            // Riga inferiore: input numerico + unità, allineati a destra (prima colonna = spacer vuoto
            // che assorbe lo spazio residuo, così Numeric e Unit restano ancorati a destra).
            var bottomRow = new TableLayoutPanel
            {
                Dock        = DockStyle.Top,
                Height      = NUMERIC_H + 6,
                ColumnCount = 3,
                RowCount    = 1,
                BackColor   = Color.Transparent,
                Margin      = new Padding(0, 4, 0, 0),
                Padding     = new Padding(0)
            };
            bottomRow.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            bottomRow.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, NUMERIC_W));
            bottomRow.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 60));

            Numeric = new NumericUpDown
            {
                Dock        = DockStyle.Fill,
                TextAlign   = HorizontalAlignment.Right,
                Font        = new Font("Segoe UI", 10F, FontStyle.Bold),
                BackColor   = Color.FromArgb(0x0A, 0x11, 0x22),
                ForeColor   = Color.FromArgb(0x48, 0xCA, 0xE4),
                BorderStyle = BorderStyle.FixedSingle
            };

            _unitLabel = new Label
            {
                AutoSize  = false,
                Dock      = DockStyle.Fill,
                Font      = new Font("Segoe UI", 8F, FontStyle.Bold),
                ForeColor = Color.FromArgb(0x44, 0x55, 0x77),
                TextAlign = ContentAlignment.MiddleLeft,
                Padding   = new Padding(5, 0, 0, 0),
                BackColor = Color.Transparent
            };

            bottomRow.Controls.Add(new Label { BackColor = Color.Transparent }, 0, 0); // spacer
            bottomRow.Controls.Add(Numeric,    1, 0);
            bottomRow.Controls.Add(_unitLabel, 2, 0);

            _hlTimer.Interval = 450;
            _hlTimer.Tick += (_, _) =>
            {
                _highlighted = false;
                _hlTimer.Stop();
                Invalidate();
            };

            // Trascinando lo slider si aggiorna l'input numerico, ma solo se l'utente non ci sta
            // scrivendo dentro (altrimenti si "ruberebbe" il focus/testo mentre digita).
            Track.Scroll += (_, _) =>
            {
                if (Numeric.Focused) return;
                decimal newValue = ToUnscaledValue(Track.Value);
                if (Numeric.Value != newValue)
                {
                    Numeric.Value = newValue;
                    ValueChanged?.Invoke(this, EventArgs.Empty);
                }
            };

            // Il NumericUpDown è la fonte di verità: ogni sua modifica (digitata, da frecce, o
            // impostata da codice tramite la proprietà Value) sincronizza lo slider e notifica il form.
            Numeric.ValueChanged += (_, _) =>
            {
                Track.Value = Clamp(ToScaledInt(Numeric.Value));
                ValueChanged?.Invoke(this, EventArgs.Empty);
                Flash();
            };

            // Aggiunti in ordine inverso perché con DockStyle.Top ogni controllo si posiziona
            // sopra l'ultimo aggiunto: per ottenere titolo/descrizione/slider/riga finale dall'alto
            // in basso, vanno inseriti nell'ordine opposto.
            Controls.Add(bottomRow);
            Controls.Add(Track);
            Controls.Add(_descLabel);
            Controls.Add(_titleLabel);
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            var g  = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            var rc = ClientRectangle;

            Color bg = _highlighted
                ? Color.FromArgb(0x22, 0x18, 0x44)
                : BackColor;
            using var bgBrush = new SolidBrush(bg);
            using var path    = RoundedPanel.GetRoundPath(
                new Rectangle(0, 0, rc.Width - 1, rc.Height - 1), CornerRadius);
            g.FillPath(bgBrush, path);

            // Barra laterale colorata (accento), sfumata dall'alto (più opaca) verso il basso
            // (più trasparente), per distinguere visivamente i gruppi di parametri.
            int barTop = CornerRadius / 2;
            int barH   = rc.Height - CornerRadius;
            using var accentBrush = new LinearGradientBrush(
                new Rectangle(0, barTop, ACCENT_W, Math.Max(1, barH)),
                Color.FromArgb(210, _accentColor),
                Color.FromArgb(40,  _accentColor),
                LinearGradientMode.Vertical);
            using var accentPath = new GraphicsPath();
            accentPath.AddRoundedRectangle(
                new RectangleF(ACCENT_W - 1, barTop, ACCENT_W, barH), 2);
            g.FillPath(accentBrush, accentPath);

            using var borderPen = new Pen(
                _highlighted
                    ? Color.FromArgb(80, _accentColor)
                    : Color.FromArgb(30, 0xAA, 0xBB, 0xFF), 1f);
            g.DrawPath(borderPen, path);

            using var shimPen = new Pen(Color.FromArgb(18, 255, 255, 255), 1f);
            g.DrawLine(shimPen, CornerRadius, 1, rc.Width - CornerRadius, 1);
        }

        // Il disegno vero e proprio avviene in OnPaintBackground: qui si sopprime OnPaint per
        // evitare che il Panel base ridisegni sopra (duplicando bordo/sfondo).
        protected override void OnPaint(PaintEventArgs e) { }

        public Color AccentColor
        {
            get => _accentColor;
            set
            {
                _accentColor = value;
                _titleLabel.ForeColor = Color.FromArgb(
                    Math.Min(255, value.R + 80),
                    Math.Min(255, value.G + 80),
                    Math.Min(255, value.B + 80));
                Invalidate();
            }
        }

        // Riavvia sempre il timer da zero: se il valore cambia più volte di seguito (es. trascinando
        // lo slider), l'evidenziazione resta accesa finché l'utente non si ferma per 450ms.
        private void Flash()
        {
            _highlighted = true;
            _hlTimer.Stop();
            _hlTimer.Start();
            Invalidate();
        }

        /// <summary>
        /// Ricalcola il range del TrackBar in base al numero di decimali e ai valori min/max.
        /// Il TrackBar supporta solo interi, quindi min/max/valore vengono moltiplicati per
        /// 10^DecimalPlaces (_scale). In questo modo lo zero fisico resta al centro dello slider
        /// quando min = -max (es. carico stampo -50000..+50000) e i range asimmetrici (es. pompa 30-100)
        /// vengono comunque rappresentati correttamente.
        /// </summary>
        private void UpdateTrackRange()
        {
            _scale = (int)Math.Pow(10, Numeric.DecimalPlaces);
            if (_scale < 1) _scale = 1;

            int scaledMin = (int)Math.Round(_minValue * _scale);
            int scaledMax = (int)Math.Round(_maxValue * _scale);
            Track.Minimum     = scaledMin;
            Track.Maximum     = scaledMax;
            Track.SmallChange = 1;
            Track.LargeChange = Math.Max(1, (scaledMax - scaledMin) / 10);
            Track.Value       = Clamp(ToScaledInt(Numeric.Value));
        }

        // decimale -> intero scalato (per lo slider)
        private int ToScaledInt(decimal value)
            => Clamp((int)Math.Round(value * _scale));

        // intero scalato dello slider -> decimale (per il NumericUpDown)
        private decimal ToUnscaledValue(int scaledValue)
            => Math.Round(scaledValue / (decimal)_scale, Numeric.DecimalPlaces);

        private int Clamp(int v)
            => Math.Max(Track.Minimum, Math.Min(Track.Maximum, v));
    }

    /// <summary>
    /// Estensione di GraphicsPath per aggiungere rettangoli con angoli arrotondati
    /// (usata dalla barra laterale colorata di ParameterControl).
    /// </summary>
    internal static class GraphicsPathExtensions
    {
        public static void AddRoundedRectangle(this GraphicsPath path, RectangleF rect, float r)
        {
            float d = r * 2f;
            path.AddArc(rect.X,               rect.Y,                d, d, 180, 90);
            path.AddArc(rect.Right - d,        rect.Y,                d, d, 270, 90);
            path.AddArc(rect.Right - d,        rect.Bottom - d,       d, d,   0, 90);
            path.AddArc(rect.X,               rect.Bottom - d,       d, d,  90, 90);
            path.CloseFigure();
        }
    }
}