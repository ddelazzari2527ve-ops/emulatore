#include <Arduino.h>
#include <SPI.h>
#include <Preferences.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <math.h>
#include "system.h"
#include "math_handling.h"
#include "table.h"

// ══════════════════════════════════════════════════════════════════
//  STATO GLOBALE - Parametri configurabili del sistema termico
// ══════════════════════════════════════════════════════════════════
float p_temp_rete            = 15.0f;   // Temperatura della rete di raffreddamento [°C]
float p_portata              = 20.0f;   // Portata attuale della pompa [L/min] (calcolata dinamicamente)
float p_massa_acqua          = MASSA_ACQUA_NOMINALE;  // Massa acqua nel serbatoio [kg]
float p_pot_risc             = 12000.0f; // Potenza resistenza riscaldamento [W] (12kW nominale)
float p_pot_raffreddamento   = 100000.0f; // Potenza unità raffreddamento [W] (aumentata a 100kW per coerenza con max 120kW)
float p_k_hx                 = 1200.0f; // Coefficiente scambiatore termico [W/K] — k=1200 W/K dà ~10-15 min 80→20°C
float p_pot_stampo           = 0.0f; // Potenza carico termico stampo [W] (stampo medio ~2-5kW)
float p_temp_ambiente        = 20.0f;   // Temperatura ambiente [°C]
float p_k_disp_tubi          = 2.5f;    // Coefficiente dispersione tubazioni [W/K]
float p_k_disp_serbatoio     = 2.0f;    // Coefficiente dispersioni serbatoio [W/K] (ridotto per serbatoio isolato)
float p_massa_stampo         = 15.0f;   // Massa termica dello stampo [kg]
float K_stampo               = K_STAMPO_DEFAULT;  // Coefficiente scambio termico stampo [W/K]
float ff_gain                = 0.1f;    // Guadagno feedforward per compensazione carico (ridotto per evitare oscillazioni)
float p_portata_valvola      = 8.0f;    // Portata valvola riempimento [L/min]
float p_ostruzione_circuito  = 0.0f;    // Fattore ostruzione circuito [0-1]
float p_pressione_bar        = 0.0f;    // Pressione impianto [bar]
float p_dt_pompa             = 0.5f;    // Incremento termico diretto della pompa [°C/h]

float temp_resistenza        = 20.0f;   // Temperatura resistenza riscaldamento [°C]
float temp_resistenza_filtrata = 20.0f; // Temperatura resistenza filtrata per allarme [°C]
float temp_metallo           = 20.0f;   // Temperatura metallo serbatoio [°C]
float temp_nucleo_res        = 20.0f;   // Temperatura nucleo resistenza (filtrata) [°C]
float temp_serbatoio         = 20.0f;   // Temperatura acqua nel serbatoio [°C]
float temp_sonda_mandata     = 20.0f;   // Temperatura letta sonda mandata [°C]
float temp_sonda_ritorno     = 20.0f;   // Temperatura letta sonda ritorno [°C]
float temp_stampo            = 20.0f;   // Temperatura stampo industriale [°C]
float adc_filtrato           = 0.0f;    // Valore ADC filtrato per comando riscaldamento [0-1]
float t_mandata_stasi        = 20.0f;   // Temperatura mandata a pompa ferma [°C]
float t_ritorno_stasi        = 20.0f;   // Temperatura ritorno a pompa ferma [°C]
float t_mandata_reale        = 20.0f;   // Temperatura mandata reale (con dead-time) [°C]
float t_ritorno_reale        = 20.0f;   // Temperatura ritorno reale [°C]

float dead_buffer[DEAD_BUF_SIZE] = {};       // Buffer temperature per ritardo trasporto (riempito in setup/resetStatoTermico)
int   dead_buf_idx = 0;                     // Indice corrente nel buffer circolare

bool          errore_acqua          = false;  // True se c'è errore livello acqua
bool          raffreddamento_cmd    = false;  // True se comando freddo da hardware
bool          perdita_attiva        = false;  // True se simulazione perdita attiva
bool          raffreddamento_attivo = false;  // True se raffreddamento attivo
bool          stato_pompa           = false;  // True se pompa accesa
bool          macchina_accesa       = true;   // True se la macchina è accesa (default true)
PumpMode      pump_mode             = PUMP_MODE_AUTO;  // Modalità pompa (AUTO/MAN-ON/MAN-OFF)
bool          pump_manual_override   = false;  // True se override manuale attivo
bool          rele_carico_acqua     = false;  // True se relè valvola acqua attivo
bool          mantieni_temp_iniziale = false;  // True se mantenere temperatura iniziale (non forzare verso ambiente)

bool fault_clogging_active          = false;  // Guasto 0: ostruzione circuito
bool fault_scaling_active           = false;  // Guasto 1: calcare scambiatore
bool fault_insulation_loss_active   = false;  // Guasto 2: perdita coibentazione
bool fault_sensor_drift_active      = false;  // Guasto 3: deriva sensore
bool fault_heater_failure_active    = false;  // Guasto 4: fase resistenza bruciata
bool fault_valve_stuck_closed       = false;  // Guasto 5: valvola bloccata chiusa
bool fault_valve_stuck_open         = false;  // Guasto 6: valvola bloccata aperta
bool fault_air_in_circuit           = false;  // Guasto 7: aria nel circuito
bool fault_heater_short_active      = false;  // Guasto 8: corto parziale resistenza
bool fault_float_stuck_high         = false;  // Guasto 9: galleggiante bloccato in alto (falso pieno)
bool fault_float_stuck_low          = false;  // Guasto 10: galleggiante bloccato in basso (falso vuoto)
bool fault_float_no_signal          = false;  // Guasto 11: sensore rotto/scollegato (nessun segnale)
float fault_sensor_drift_offset_c   = 0.0f;   // Offset deriva sensore [°C]

// ══════════════════════════════════════════════════════════════════
//  OFFSET DI CALIBRAZIONE SONDE (determinati numericamente via CALIBRA)
// ══════════════════════════════════════════════════════════════════
float r_offset_mandata_ohm = 0;
float r_offset_ritorno_ohm = 0;

// ── Persistenza calibrazione sonde in NVS (flash) ──────────────────
// Problema risolto: prima d'ora r_offset_mandata_ohm/r_offset_ritorno_ohm
// vivevano solo in RAM e venivano azzerati ad ogni riavvio (vedi i vecchi
// messaggi "l'offset non e' persistente"). Questo faceva si' che, subito
// dopo un power-on, la sonda mandata mostrasse il suo errore fisico "grezzo"
// (non ancora ricalibrato) mentre la ritorno, se per caso ha un offset
// hardware piu' piccolo, sembrava "di serie" gia' precisa. Ora l'offset
// calcolato da CALIBRA viene salvato in NVS e ricaricato automaticamente
// ad ogni avvio/reset, cosi' la mandata riparte già corretta, il piu'
// vicino possibile alla temperatura ambiente reale, esattamente come la ritorno.
static Preferences prefsCalib;
static constexpr const char* NVS_NAMESPACE_CALIB     = "efp_calib";
static constexpr const char* NVS_KEY_OFFSET_MANDATA  = "off_mand";
static constexpr const char* NVS_KEY_OFFSET_RITORNO  = "off_rit";

// Carica gli offset salvati in flash (0.0 se non e' mai stata fatta una CALIBRA)
static void caricaCalibrazioneNVS() {
    prefsCalib.begin(NVS_NAMESPACE_CALIB, true);  // sola lettura
    r_offset_mandata_ohm = prefsCalib.getFloat(NVS_KEY_OFFSET_MANDATA, 0.0f);
    r_offset_ritorno_ohm = prefsCalib.getFloat(NVS_KEY_OFFSET_RITORNO, 0.0f);
    prefsCalib.end();
    Serial.printf("Calibrazione sonde ripristinata da memoria: mandata=%+.3f ohm, ritorno=%+.3f ohm\n",
                  r_offset_mandata_ohm, r_offset_ritorno_ohm);
}

// Salva su flash gli offset correnti, cosi' sopravvivono al riavvio
static void salvaCalibrazioneNVS() {
    prefsCalib.begin(NVS_NAMESPACE_CALIB, false);
    prefsCalib.putFloat(NVS_KEY_OFFSET_MANDATA, r_offset_mandata_ohm);
    prefsCalib.putFloat(NVS_KEY_OFFSET_RITORNO, r_offset_ritorno_ohm);
    prefsCalib.end();
}

// Cancella la calibrazione salvata (usata da "CALIBRA RESET")
static void cancellaCalibrazioneNVS() {
    prefsCalib.begin(NVS_NAMESPACE_CALIB, false);
    prefsCalib.clear();
    prefsCalib.end();
}

bool alarm_boiling                  = false;  // Allarme 0x01: bollitura acqua
bool alarm_dry_run                  = false;  // Allarme 0x02: marcia a secco
bool alarm_pump_fail                = false;  // Allarme 0x04: guasto pompa
bool warning_thermal_shock          = false;  // Allarme 0x08: shock termico
bool alarm_circulation_insufficient = false;  // Allarme 0x10: circolazione insufficiente
bool alarm_serbatoio_vuoto         = false;  // Allarme 0x20: serbatoio vuoto
bool alarm_cavitation              = false;  // Allarme 0x40: cavitazione
bool alarm_sensor_dislodged        = false;  // Allarme 0x80: sonda fuori sede
bool alarm_overheat_res            = false;  // Allarme 0x100: resistenza in surriscaldo (rischio bruciatura)
bool alarm_heater_short            = false;  // Allarme 0x2000: corto parziale resistenza
bool alarm_alta_pressione          = false;  // Allarme 0x200: pressione effettiva oltre soglia
bool alarm_aria_circuito           = false;  // Allarme 0x400: aria rilevata nel circuito
bool alarm_perdita_acqua           = false;  // Allarme 0x800: perdita d'acqua (simulata o da aria)
bool alarm_float_failure           = false;  // Allarme 0x1000: guasto sensore livello (galleggiante)

static bool handshake_done = false;  // True se handshake con PC completato

unsigned long t_last = 0UL;  // Timestamp ultimo ciclo completo [ms]
unsigned long t_log  = 0UL;  // timestamp ultimo log JSON [ms]

// ══════════════════════════════════════════════════════════════════
//  VARIABILI INTERNE - Modello fisico termodinamico
// ══════════════════════════════════════════════════════════════════
static float cp_fluido            = CP_ACQUA;  // Calore specifico fluido [J/kg·K]
static float t_ebollizione        = 100.0f;   // Temperatura ebollizione alla pressione attuale [°C]
static bool  is_olio              = false;    // True se fluido è olio, false se acqua
static float apertura_valvola_hx  = 0.0f;     // Apertura valvola scambiatore [0-1]
static unsigned long t_ultimo_comando_auto_pompa = 0UL;  // Timestamp ultimo comando auto pompa [ms]
static float last_q_scambiatore   = 0.0f;     // Ultima potenza scambiatore [W]
static float last_q_raffreddamento = 0.0f;    // Ultima potenza raffreddamento [W]
static float last_q_iniezione     = 0.0f;     // Ultima potenza iniezione acqua [W]
static float last_q_conv          = 0.0f;     // Ultima potenza convezione stampo [W]
static float last_q_proc          = 0.0f;     // Ultima potenza processo [W]
static float last_q_pompa         = 0.0f;     // Ultima potenza pompa [W]
static float last_q_out           = 0.0f;     // Ultima potenza uscita netta [W]

static bool   acqua_pulse_attivo  = false;    // True se impulso riempimento attivo
static unsigned long t_pulse_acqua = 0UL;     // Timestamp inizio impulso acqua [ms]
static float p_portata_base_cmd    = PORTATA_NOMINALE_LMIN;  // Portata base comando [L/min]
static float p_massa_tubi           = 6.0f;    // Massa termica tubazioni [kg]
static float p_efficienza_pompa     = 1.0f;    // Efficienza pompa [0-1]
static float temp_tubi              = 20.0f;   // Temperatura tubazioni [°C]
static float pressione_effettiva_bar = 0.0f;   // Pressione effettiva calcolata [bar]
static unsigned long long ore_pompa_s = 0ULL;     // Ore funzionamento pompa [ms]
static unsigned long long ore_resistenza_s = 0ULL;// Ore funzionamento resistenza [ms]
static unsigned long long ore_hx_s = 0ULL;        // Ore funzionamento scambiatore [ms]
static float temp_sonda_mandata_pura = 20.0f;   // Temperatura sonda mandata senza deriva [°C]
static float temp_sonda_ritorno_pura = 20.0f;   // Temperatura sonda ritorno senza deriva [°C]

// ── Rampa automatica di avvicinamento SOLO DISPLAY (non tocca i potenziometri SPI) ──
// Aggiunge gradualmente fino a +1°C al valore mostrato in telemetria/JSON per
// le due sonde, in modo che il termoregolatore esterno veda il valore
// avvicinarsi dolcemente invece di un salto istantaneo.
// La rampa avanza SOLO quando la macchina è accesa e c'è un comando di
// caldo o freddo attivo; a macchina ferma o senza comando resta congelata
// al valore raggiunto (non sale e non scende).
// Non modifica in alcun modo r_offset_mandata_ohm/r_offset_ritorno_ohm, quindi
// non scrive nulla sul potenziometro digitale reale: è puramente cosmetico
// sul numero mostrato (JSON "mand"/"rit" e comando SONDE).
static float ramp_display_accum_ms            = 0.0f;   // ms accumulati di rampa (solo mentre attiva)
static constexpr float STARTUP_DISPLAY_RAMP_MAX_C = 1.0f;     // offset massimo raggiungibile [°C]
static constexpr unsigned long STARTUP_DISPLAY_RAMP_MS = 30000UL; // durata rampa [ms] (30s)
static float temp_sonda_mandata_display = 20.0f; // Valore mostrato (con rampa avvio) [°C]
static float temp_sonda_ritorno_display = 20.0f; // Valore mostrato (con rampa avvio) [°C]

// ══════════════════════════════════════════════════════════════════
//  COSTANTI - Soglie e tempi di stabilità del sistema
// ══════════════════════════════════════════════════════════════════
static constexpr float MASSA_TERMICA_MIN_EFF = 1.0f;    // Massa termica minima effettiva [kg]
static constexpr float HX_VALVE_TAU_OPEN_S   = 0.10f;   // Costante tempo apertura valvola HX [s] (apertura istantanea)
static constexpr float HX_VALVE_TAU_CLOSE_S  = 0.50f;   // Costante tempo chiusura valvola HX [s]
static constexpr float HX_COOL_RATE_WATER_C_PER_S = 0.18f; // Velocità di raffreddamento massima dell'HX per acqua [°C/s]
static constexpr float HX_COOL_RATE_OIL_C_PER_S   = 0.04f; // Velocità di raffreddamento massima dell'HX per olio [°C/s]
static constexpr float HX_CONDUCTANCE_FRACTION_WATER = 0.45f; // Frazione di p_k_hx usata per acqua
static constexpr float HX_CONDUCTANCE_FRACTION_OIL   = 0.18f; // Frazione di p_k_hx usata per olio
static constexpr float HX_FLOW_FACTOR_MIN = 0.20f; // Portata minima considerata nell'HX
static constexpr float STASI_TAU_S           = 120.0f;  // Costante tempo temperatura a pompa ferma [s] (dead-leg realistico)
static constexpr unsigned long PUMP_AUTO_STOP_DELAY_MS = 120000UL; // Ritardo spegnimento pompa in AUTO dopo perdita segnale [ms] (120 secondi per evitare spegnimenti prematuri)
static constexpr unsigned long CIRC_DEBOUNCE_MS  = 9000UL;   // Debounce allarme circolazione [ms]
static constexpr unsigned long SHOCK_DEBOUNCE_MS = 9000UL;   // Debounce allarme shock termico [ms]
static constexpr float CAPACITA_SICURA_MIN   = 1000.0f;  // Capacità termica minima sicura [J/K] (aumentata per stabilità)
static constexpr unsigned long ACQUA_PULSE_MS  = 3000UL;   // Durata impulso riempimento acqua [ms]
static constexpr float PRESSURE_LOW_CAVITATION_BAR  = 0.80f;  // Soglia pressione bassa per cavitazione [bar]
static constexpr float PRESSURE_HIGH_ALARM_BAR       = 4.50f;  // Soglia allarme alta pressione [bar]
static constexpr float TEMP_RES_OVERHEAT_C           = 220.0f; // Temperatura critica metallo/involucro [°C] (thermoswitch fisico)
static constexpr float TEMP_RES_OVERHEAT_HYST_C      = 200.0f; // Isteresi disattivazione surriscaldo [°C]
static constexpr float TEMP_RES_CORE_OVERHEAT_C     = 180.0f; // Temperatura critica nucleo resistenza [°C] (evita bruciatura)
static constexpr float TEMP_RES_MAX_DT_PER_CYCLE_C  = 0.5f;   // Max ΔT per ciclo per temp_resistenza [°C] (rate limiter)
static constexpr unsigned long CAVITATION_DEBOUNCE_MS = 2500UL; // Debounce allarme cavitazione [ms]
static constexpr unsigned long SENSOR_DISLODGED_DEBOUNCE_MS = 3000UL; // Debounce allarme sonda [ms]
static constexpr unsigned long RAFFREDDAMENTO_DEBOUNCE_MS = 1000UL; // Debounce richiesta raffreddamento per evitare chatter sul pin (aumentato a 1s per tollerare salti momentanei)
static constexpr unsigned long RAFFREDDAMENTO_HOLD_MS = 5000UL; // Tempo minimo di mantenimento segnale freddo dopo che il pin torna HIGH (isteresi)
static constexpr unsigned long HX_MIN_ON_DWELL_MS  = 5000UL; // Permanenza minima ON prima di poter richiudere la valvola HX (evita saltellamento temperatura)
static constexpr unsigned long HX_MIN_OFF_DWELL_MS = 3000UL; // Permanenza minima OFF prima di poter riaprire la valvola HX
static constexpr float SENSOR_DRIFT_STEP_C_PER_MIN = 0.5f;  // Velocità deriva sensore [°C/min]
// Effetti fisici aria nel circuito (binario ON/OFF)
static constexpr float AIR_PORTATA_FACTOR    = 0.62f;   // Portata ridotta al 62% (sacca d'aria in pompa)
static constexpr float AIR_KHX_FACTOR        = 0.65f;   // Scambio HX ridotto al 65% (isolamento da bolla)
static constexpr float AIR_DP_BAR            = 0.28f;   // Calo pressione statica da aria compressa [bar]
static constexpr float AIR_MASSA_ESPULSA_KG  = 0.80f;   // Acqua espulsa dagli sfiatatoi all'attivazione [kg]
static constexpr float AIR_TAU_TUBI_MIN_S    = 30.0f;   // Tau minima tubazioni con aria (propagazione lenta) [s]
static constexpr float PUMP_WEAR_PER_HOUR = 0.00002f; // Usura pompa per ora di funzionamento [1/h]

// Alias locali per compatibilità codice esistente
static constexpr uint8_t FAULT_BTN_1_LOCAL = FAULT_BTN_1_PIN;
static constexpr uint8_t FAULT_BTN_2_LOCAL = FAULT_BTN_2_PIN;
static constexpr uint8_t FAULT_BTN_3_LOCAL = FAULT_BTN_3_PIN;
static constexpr uint8_t FAULT_BTN_4_LOCAL = FAULT_BTN_4_PIN;
static constexpr uint8_t FAULT_BTN_5_LOCAL = FAULT_BTN_5_PIN;

// Portata filtrata globale per inerzia idraulica
static float p_portata_filtrata_global = PORTATA_NOMINALE_LMIN;
static float deadtime_last_out = 20.0f;
static float deadtime_accum_s  = 0.0f;
static float deadtime_delay_s_filt = -1.0f; // ritardo filtrato [s], -1 = non inizializzato

// Timer debounce/latch allarmi (esposti per resetStatoTermico)
static unsigned long t_pump_fail_ms          = 0UL;
static unsigned long t_shock_ms              = 0UL;
static unsigned long t_circ_ms               = 0UL;
static unsigned long t_cav_ms                = 0UL;
static unsigned long t_sond_ms               = 0UL;
static unsigned long t_overheat_ms           = 0UL;
static unsigned long t_heater_short_ms       = 0UL;
static unsigned long t_press_ms              = 0UL;
static unsigned long t_aria_attivazione_ms   = 0UL;
static unsigned long t_setpoint_fail_ms      = 0UL;
static bool          warning_setpoint_fail_prev = false;
static unsigned long t_inizio_riempimento    = 0UL;
static unsigned long t_pressione_alta_05bar_ms = 0UL;  // Timer debounce pressione > 0.5 bar per cavitazione
static float t_serb_snapshot = 0.0f;  // Snapshot temperatura serbatoio per allarme setpoint irraggiungibile
static unsigned long t_ultimo_riempimento    = 0UL; // Traccia ultima aggiunta acqua
static unsigned long t_totale_riempimento_ms = 0UL; // Tempo cumulativo riempimento attivo
static bool          heat_latched            = false;
static bool          cooling_pin_last_raw    = false;
static bool          cooling_pin_filtered   = false;
static unsigned long t_last_cooling_change_ms = 0UL;
static unsigned long t_last_cooling_active_ms = 0UL;  // Timestamp ultima volta che il pin freddo era LOW

// Variabili statiche spostate a scope file per reset corretto
static bool          richiesta_freddo_stabile = false;
static unsigned long t_ultimo_cambio_freddo_ms = 0UL;
static float         dither_accum_mandata = 0.0f;
static float         dither_accum_ritorno = 0.0f;
static PumpMode      last_pump_mode = PUMP_MODE_AUTO;

// ══════════════════════════════════════════════════════════════════
//  FUNZIONI DI SUPPORTO / UTILITY
// ══════════════════════════════════════════════════════════════════

// Verifica se un pin è valido (non è 255 = non assegnato)
static inline bool pinValido(uint8_t pin) {
    return pin != 255;
}

// Calcola delta tempo in secondi con protezione overflow e clamping
static inline float tempoDtSecondi(unsigned long now, unsigned long then) {
    unsigned long diff_ms = now - then;  // Overflow-safe per unsigned (gestisce wrap-around)
    float dt_s = diff_ms * 0.001f;
    if (dt_s > 10.0f) return 0.0f;   // Sospende l'integrazione per timeout evitando picchi energetici artificiali
    return (dt_s > DT_MAX_S) ? DT_MAX_S : dt_s;
}

// Restituisce capacità termica con floor minimo per stabilità numerica
static inline float capacitaSicura(float c) {
    return max(c, CAPACITA_SICURA_MIN);
}

// Restituisce massa termica effettiva con floor minimo (evita divisione per zero)
static inline float massaTermicaSerbatoioEffettiva(float massa_acqua) {
    return max(massa_acqua, MASSA_TERMICA_MIN);
}

// Converte portata da L/min a kg/s (assumendo densità acqua = 1 kg/L)
static inline float portataMassicaDaLMin(float portata_lmin) {
    return max(portata_lmin, 0.0f) / 60.0f;
}

// NOTA: spiMux è attualmente ridondante (loop Arduino single-threaded, senza ISR o task FreeRTOS)
// ma mantenuto per scenari futuri multi-threading. Se si aggiunge un secondo task (es. ADC asincrono o watchdog),
// le variabili di stato termico globale (temp_serbatoio, p_massa_acqua, fault_*, ecc.) devono essere rese volatile
// e protette da mutex per evitare race conditions reali.
static portMUX_TYPE spiMux = portMUX_INITIALIZER_UNLOCKED;

// Scrive l'offset di calibrazione sul potenziometro digitale PT1000 via SPI
// Implementa dithering temporale per evitare saltelli nella resistenza quando la temperatura
// attraversa il punto medio tra due gradini della tabella lookup. Alternando tra i due
// gradini adiacenti con duty-cycle proporzionale alla frazione, la resistenza media nel
// tempo converge al valore continuo desiderato.
static inline void aggiornaCalibrazionePT1000(uint8_t cs, float temperatura_c, float offset_ohm, float &dither_accum) {
    const float r_corretta = resistenzaPt1000Corretta(temperatura_c, offset_ohm);
    const PassiInterpolati pi = trovaPassiPotenziometroInterpolati(r_corretta);

    dither_accum += pi.frac;
    bytes8_t passi;
    if (dither_accum >= 1.0f) {
        dither_accum -= 1.0f;
        passi = pi.hi;
    } else {
        passi = pi.lo;
    }

    // Clamp dei passi a 511 (9 bit max del potenziometro)
    uint16_t p1_safe = min(passi.p1, (uint16_t)511u);
    uint16_t p2_safe = min(passi.p2, (uint16_t)511u);
    SPI.beginTransaction(SPISettings(1000000, MSBFIRST, SPI_MODE0));
    portENTER_CRITICAL(&spiMux);
    digitalWrite(cs, LOW);
    SPI.transfer((uint8_t)(0x00 | ((p1_safe > 255U) ? 0x01 : 0x00)));
    SPI.transfer((uint8_t)(p1_safe & 0xFFU));
    SPI.transfer((uint8_t)(0x10 | ((p2_safe > 255U) ? 0x01 : 0x00)));
    SPI.transfer((uint8_t)(p2_safe & 0xFFU));
    digitalWrite(cs, HIGH);
    portEXIT_CRITICAL(&spiMux);
    SPI.endTransaction();
}

// autocalibraSonde
// ══════════════════════════════════════════════════════════════════
// Determina automaticamente r_offset_mandata_ohm e r_offset_ritorno_ohm
// confrontando la lettura della sonda con il valore vero del modello
// a sistema fermo (pompa OFF, stasi termica). Usa la pendenza esatta
// locale della curva PT1000 per calcolo preciso in un solo colpo.
// Avanza il modello fisico di un passo (definita più avanti, vedi loop())
static void aggiornaFisica(unsigned long now, float dt_s);

static void autocalibraSonde() {
    if (stato_pompa || p_portata > 0.05f) {
        Serial.println(F("ERRORE: fermare la pompa (POMPA OFF / P0) prima di calibrare."));
        Serial.println(F("        La calibrazione richiede sistema in stasi termica."));
        return;
    }

    Serial.println(F("=============== AUTOCALIBRAZIONE SONDE ==============="));
    Serial.println(F("ATTENZIONE: acquisizione in corso (~2 s). Allarmi sospesi. Watchdog resettato."));
    Serial.printf("Acquisizione di %d campioni (%lu ms tra un campione e l'altro)...\n",
                  AUTOCAL_N_CAMPIONI, AUTOCAL_DT_MS);

    double somma_err_mandata = 0.0;
    double somma_err_ritorno = 0.0;
    double somma_t_vera_mandata = 0.0;
    double somma_t_vera_ritorno = 0.0;
    float primo_mandata = t_mandata_reale;
    float primo_ritorno = t_ritorno_reale;

    for (int i = 0; i < AUTOCAL_N_CAMPIONI; ++i) {
        delay(AUTOCAL_DT_MS);
        yield();  // Resetta il task watchdog e cede CPU a FreeRTOS
        // Fa avanzare realmente la simulazione (e rilegge gli I/O reali) invece
        // di limitarsi ad aspettare: senza questo, i valori resterebbero
        // congelati durante il delay() bloccante, rendendo l'acquisizione
        // identica a un singolo campione e il controllo di stabilità sempre
        // "falso positivo" (deriva sempre 0).
        unsigned long now_cal = millis();
        aggiornaFisica(now_cal, AUTOCAL_DT_MS / 1000.0f);
        t_last = now_cal;

        somma_err_mandata     += (double)(temp_sonda_mandata_pura - t_mandata_reale);
        somma_err_ritorno     += (double)(temp_sonda_ritorno_pura  - t_ritorno_reale);
        somma_t_vera_mandata  += (double)t_mandata_reale;
        somma_t_vera_ritorno  += (double)t_ritorno_reale;
    }

    // Controllo di stabilità: se durante l'acquisizione la temperatura vera si è
    // mossa più della soglia, il sistema non era ancora in stasi termica stabile.
    const float deriva_mandata = fabsf(t_mandata_reale - primo_mandata);
    const float deriva_ritorno = fabsf(t_ritorno_reale - primo_ritorno);
    const float SOGLIA_INSTABILITA_C = 0.05f;
    if (deriva_mandata > SOGLIA_INSTABILITA_C || deriva_ritorno > SOGLIA_INSTABILITA_C) {
        Serial.println(F("ATTENZIONE: la temperatura si stava ancora muovendo durante l'acquisizione."));
        Serial.printf("  Deriva mandata nei 2s di misura: %.3f C  |  Deriva ritorno: %.3f C\n",
                      deriva_mandata, deriva_ritorno);
        Serial.println(F("  Il sistema non e' ancora in stasi termica stabile (pompa fermata da"));
        Serial.println(F("  troppo poco tempo). Attendere ancora prima di fidarsi del risultato,"));
        Serial.println(F("  oppure ripetere CALIBRA quando la deriva sara' sotto soglia."));
    }

    float err_mandata_medio = (float)(somma_err_mandata / AUTOCAL_N_CAMPIONI);
    float err_ritorno_medio = (float)(somma_err_ritorno / AUTOCAL_N_CAMPIONI);
    float t_vera_mandata_media = (float)(somma_t_vera_mandata / AUTOCAL_N_CAMPIONI);
    float t_vera_ritorno_media = (float)(somma_t_vera_ritorno / AUTOCAL_N_CAMPIONI);

    float t_letta_mandata = t_vera_mandata_media + err_mandata_medio;
    float t_letta_ritorno = t_vera_ritorno_media + err_ritorno_medio;

    float nuovo_offset_mandata = tempAResistenza(t_vera_mandata_media) - tempAResistenza(t_letta_mandata);
    float nuovo_offset_ritorno = tempAResistenza(t_vera_ritorno_media) - tempAResistenza(t_letta_ritorno);

    // Limite di sicurezza: offset enorme indica sonda/cablaggio guasto
    if (fabsf(nuovo_offset_mandata) > AUTOCAL_MAX_OFFSET_OHM ||
        fabsf(nuovo_offset_ritorno) > AUTOCAL_MAX_OFFSET_OHM) {
        Serial.println(F("ERRORE: offset calcolato fuori range plausibile (>15 Ω)."));
        Serial.println(F("        Probabile guasto sonda/cablaggio: calibrazione NON applicata."));
        Serial.printf("        Offset calcolati: mandata=%.3f ohm, ritorno=%.3f ohm\n",
                      nuovo_offset_mandata, nuovo_offset_ritorno);
        return;
    }

    r_offset_mandata_ohm = nuovo_offset_mandata;
    r_offset_ritorno_ohm = nuovo_offset_ritorno;
    salvaCalibrazioneNVS();

    float incertezza_mandata_c = incertezzaResiduaStimataC(t_vera_mandata_media);
    float incertezza_ritorno_c = incertezzaResiduaStimataC(t_vera_ritorno_media);

    Serial.println(F("--- RISULTATO ---"));
    Serial.printf("MANDATA: errore medio misurato = %+.3f C  ->  nuovo offset = %+.3f ohm\n",
                  err_mandata_medio, r_offset_mandata_ohm);
    Serial.printf("RITORNO: errore medio misurato = %+.3f C  ->  nuovo offset = %+.3f ohm\n",
                  err_ritorno_medio, r_offset_ritorno_ohm);
    Serial.println(F("--- INCERTEZZA RESIDUA NON COMPENSABILE (tolleranze hardware) ---"));
    Serial.printf("Dovuta a: R_FISSA +/-%.2f%%, INL pot +/-%.1f ohm, PT1000 classe B +/-(%.2f+%.3f*|T|) C\n",
                  R_FISSA_TOLLERANZA_PCT * 100.0f, POT_DIGITALE_INL_OHM,
                  PT1000_CLASSE_B_TOLL_BASE_C, PT1000_CLASSE_B_TOLL_COEFF);
    Serial.printf("MANDATA: residuo atteso ~ +/-%.3f C (oltre questo, non rincorrere lo zero)\n",
                  incertezza_mandata_c);
    Serial.printf("RITORNO: residuo atteso ~ +/-%.3f C\n", incertezza_ritorno_c);
    Serial.println(F("Calibrazione applicata. Usare SONDE per verificare."));
    Serial.println(F("NOTA: offset salvato in memoria flash, resta attivo anche dopo il riavvio."));
    Serial.println(F("      Usare CALIBRA RESET per cancellarlo."));
    Serial.println(F("========================================================"));
}

// autocalibraSondeDaRiferimento
// ══════════════════════════════════════════════════════════════════
// Variante che usa come riferimento i valori letti sul display del
// regolatore fisico esterno invece del modello interno.
// Uso: CALIBRA <t_mandata_regolatore> <t_ritorno_regolatore>
// Esempio: CALIBRA 19.2 18.6
// NOTA: esegue UN SOLO calcolo (non iterativo) perché l'offset agisce
// solo sul potenziometro esterno, non sulle letture interne.
static void autocalibraSondeDaRiferimento(float t_mandata_regolatore, float t_ritorno_regolatore) {
    if (stato_pompa || p_portata > 0.05f) {
        Serial.println(F("ERRORE: fermare la pompa (POMPA OFF / P0) prima di calibrare."));
        Serial.println(F("        La calibrazione richiede sistema in stasi termica."));
        return;
    }

    Serial.println(F("=========== AUTOCALIBRAZIONE SU REGOLATORE ESTERNO ==========="));
    Serial.printf("Riferimento inserito -> mandata: %.2f C, ritorno: %.2f C\n",
                  t_mandata_regolatore, t_ritorno_regolatore);
    Serial.printf("Acquisizione di %d campioni (%lu ms tra un campione e l'altro)...\n",
                  AUTOCAL_N_CAMPIONI, AUTOCAL_DT_MS);

    double somma_vera_mandata = 0.0;
    double somma_vera_ritorno = 0.0;
    float primo_mandata = t_mandata_reale;
    float primo_ritorno = t_ritorno_reale;

    for (int i = 0; i < AUTOCAL_N_CAMPIONI; ++i) {
        delay(AUTOCAL_DT_MS);
        yield();
        // Fa avanzare realmente la simulazione invece di leggere un valore
        // congelato: senza questo, la deriva calcolata sotto era sempre 0
        // per costruzione e il controllo di stabilità non poteva mai scattare.
        unsigned long now_cal = millis();
        aggiornaFisica(now_cal, AUTOCAL_DT_MS / 1000.0f);
        t_last = now_cal;

        somma_vera_mandata += (double)t_mandata_reale;
        somma_vera_ritorno += (double)t_ritorno_reale;
    }

    float t_vera_mandata_media = (float)(somma_vera_mandata / AUTOCAL_N_CAMPIONI);
    float t_vera_ritorno_media = (float)(somma_vera_ritorno / AUTOCAL_N_CAMPIONI);

    // Controllo di stabilità: se durante l'acquisizione la temperatura vera si è
    // mossa più della soglia, il sistema non era ancora in stasi termica stabile
    // (es. pompa appena fermata: mandata/ritorno ancora in transitorio verso
    // l'ambiente con tau diversi). Un offset calcolato su un valore instabile
    // cambia ogni volta che si ripete la prova.
    const float deriva_mandata = fabsf(t_mandata_reale - primo_mandata);
    const float deriva_ritorno = fabsf(t_ritorno_reale - primo_ritorno);
    const float SOGLIA_INSTABILITA_C = 0.05f;
    if (deriva_mandata > SOGLIA_INSTABILITA_C || deriva_ritorno > SOGLIA_INSTABILITA_C) {
        Serial.println(F("ATTENZIONE: la temperatura si stava ancora muovendo durante l'acquisizione."));
        Serial.printf("  Deriva mandata nei 2s di misura: %.3f C  |  Deriva ritorno: %.3f C\n",
                      deriva_mandata, deriva_ritorno);
        Serial.println(F("  Il sistema non e' ancora in stasi termica stabile (pompa fermata da"));
        Serial.println(F("  troppo poco tempo). Attendere almeno 60 secondi dopo POMPA OFF, poi"));
        Serial.println(F("  ripetere CALIBRA con i valori letti ora sul regolatore."));
    }

    // Errore del regolatore esterno rispetto alla temperatura VERA del sistema:
    // positivo se il regolatore legge troppo alto, negativo se legge troppo basso.
    float errore_regolatore_mandata_c = t_mandata_regolatore - t_vera_mandata_media;
    float errore_regolatore_ritorno_c = t_ritorno_regolatore - t_vera_ritorno_media;

    // Pendenza locale nel punto di lavoro vero, per convertire l'errore in °C -> Ω
    float pendenza_mandata = pendenzaLocalePt1000(t_vera_mandata_media);
    float pendenza_ritorno = pendenzaLocalePt1000(t_vera_ritorno_media);

    // Correzione da SOMMARE all'offset già esistente (non sovrascrive):
    // se il regolatore legge troppo alto (errore positivo) -> tolgo ohm (correzione negativa)
    // se il regolatore legge troppo basso (errore negativo) -> aggiungo ohm (correzione positiva)
    float correzione_mandata_ohm = -errore_regolatore_mandata_c * pendenza_mandata;
    float correzione_ritorno_ohm = -errore_regolatore_ritorno_c * pendenza_ritorno;

    float nuovo_offset_mandata = r_offset_mandata_ohm + correzione_mandata_ohm;
    float nuovo_offset_ritorno = r_offset_ritorno_ohm + correzione_ritorno_ohm;

    if (fabsf(nuovo_offset_mandata) > AUTOCAL_MAX_OFFSET_OHM ||
        fabsf(nuovo_offset_ritorno) > AUTOCAL_MAX_OFFSET_OHM) {
        Serial.println(F("ERRORE: offset calcolato fuori range plausibile (>15 Ω)."));
        Serial.println(F("        Probabile guasto sonda/cablaggio: calibrazione NON applicata."));
        Serial.printf("        Offset calcolati: mandata=%.3f ohm, ritorno=%.3f ohm\n",
                      nuovo_offset_mandata, nuovo_offset_ritorno);
        return;
    }

    r_offset_mandata_ohm = nuovo_offset_mandata;
    r_offset_ritorno_ohm = nuovo_offset_ritorno;
    salvaCalibrazioneNVS();

    float incertezza_mandata_c = incertezzaResiduaStimataC(t_mandata_regolatore);
    float incertezza_ritorno_c = incertezzaResiduaStimataC(t_ritorno_regolatore);

    Serial.println(F("--- RISULTATO ---"));
    Serial.printf("MANDATA: vera %.2f C, regolatore %.2f C (errore regolatore %+.3f C) -> correzione %+.3f ohm -> nuovo offset = %+.3f ohm\n",
                  t_vera_mandata_media, t_mandata_regolatore, errore_regolatore_mandata_c, correzione_mandata_ohm, r_offset_mandata_ohm);
    Serial.printf("RITORNO: vera %.2f C, regolatore %.2f C (errore regolatore %+.3f C) -> correzione %+.3f ohm -> nuovo offset = %+.3f ohm\n",
                  t_vera_ritorno_media, t_ritorno_regolatore, errore_regolatore_ritorno_c, correzione_ritorno_ohm, r_offset_ritorno_ohm);
    Serial.println(F("--- INCERTEZZA RESIDUA NON COMPENSABILE (tolleranze hardware) ---"));
    Serial.printf("MANDATA: residuo atteso ~ +/-%.3f C (oltre questo, non rincorrere lo zero)\n",
                  incertezza_mandata_c);
    Serial.printf("RITORNO: residuo atteso ~ +/-%.3f C\n", incertezza_ritorno_c);
    Serial.println(F("Calibrazione applicata. Guardare ORA il display del regolatore."));
    Serial.println(F("Se non coincide ancora, leggere il NUOVO valore sul regolatore e"));
    Serial.println(F("ripetere CALIBRA con quei numeri (questo e' il vero giro 2, perche'"));
    Serial.println(F("solo cosi' il regolatore ha gia' ricevuto la resistenza corretta)."));
    Serial.println(F("NOTA: offset salvato in memoria flash, resta attivo anche dopo il riavvio."));
    Serial.println(F("      Usare CALIBRA RESET per cancellarlo."));
    Serial.println(F("================================================================"));
}

// Verifica se una stringa inizia con un dato token
static inline bool startsWithToken(const char *s, const char *token) {
    return (strncmp(s, token, strlen(token)) == 0);
}

// Rimuove spazi bianchi all'inizio e alla fine di una stringa (in-place)
static void trimInPlace(char *s) {
    if (!s) return;
    size_t len = strlen(s);
    if (len == 0) return;
    size_t start = 0;
    while (start < len && isspace((unsigned char)s[start])) start++;
    size_t end = len;
    while (end > start && isspace((unsigned char)s[end - 1])) end--;
    if (end <= start) { s[0] = '\0'; return; }
    if (start > 0) memmove(s, s + start, end - start);
    s[end - start] = '\0';
}

// Converte una stringa in maiuscolo (in-place)
static void toUpperInPlace(char *s) {
    if (!s) return;
    for (; *s; ++s) *s = (char)toupper((unsigned char)*s);
}

// Legge il comando di riscaldo dall'ADC con isteresi per evitare oscillazioni
static inline float leggiComandoRiscaldo() {
    const int raw = analogRead(PIN_CALORE_IN);

    if (raw < ADC_ZERO_SOGLIA) {
        adc_filtrato = filtraPL(adc_filtrato, 0.0f, ADC_ALPHA);
        return 0.0f;
    }

    float frazione = constrain((float)raw / ADC_CALDO_MAX, 0.0f, 1.0f);
    adc_filtrato = filtraPL(adc_filtrato, frazione, ADC_ALPHA);

    if (!heat_latched) {
        if (adc_filtrato >= HEAT_ON_TH) heat_latched = true;
    } else {
        if (adc_filtrato <= HEAT_OFF_TH) heat_latched = false;
    }

    return heat_latched ? adc_filtrato : 0.0f;
}

// Emette messaggio seriale solo quando lo stato di un allarme cambia
static void emettiCambioAllarme(bool nuovo_stato, bool &stato_memoria, const __FlashStringHelper *on_msg, const __FlashStringHelper *off_msg) {
    if (nuovo_stato == stato_memoria) return;
    stato_memoria = nuovo_stato;
    Serial.println(nuovo_stato ? on_msg : off_msg);
}

// Imposta lo stato di un guasto tramite indice
static void setFaultState(uint8_t idx, bool stato) {
    switch (idx) {
        case 0: fault_clogging_active        = stato; break;
        case 1: fault_scaling_active         = stato; break;
        case 2: fault_insulation_loss_active = stato; break;
        case 3: fault_sensor_drift_active    = stato; break;
        case 4: fault_heater_failure_active   = stato; if (stato) fault_heater_short_active = false; break;
        case 5: fault_valve_stuck_closed      = stato; if (stato) fault_valve_stuck_open = false; break;
        case 6: fault_valve_stuck_open        = stato; if (stato) fault_valve_stuck_closed = false; break;
        // case 7 rimosso: fault_air_in_circuit è gestito solo da impostaFaultAria() (single point of truth)
        case 8: fault_heater_short_active     = stato; if (stato) fault_heater_failure_active = false; break;
        case 9: fault_float_stuck_high        = stato; break;
        case 10: fault_float_stuck_low         = stato; break;
        case 11: fault_float_no_signal         = stato; break;
        default: return;
    }
}

// Inverte lo stato di un guasto tramite indice
static void toggleFaultState(uint8_t idx) {
    switch (idx) {
        case 0: fault_clogging_active        = !fault_clogging_active; break;
        case 1: fault_scaling_active         = !fault_scaling_active; break;
        case 2: fault_insulation_loss_active = !fault_insulation_loss_active; break;
        case 3: fault_sensor_drift_active    = !fault_sensor_drift_active; break;
        case 4: fault_heater_failure_active   = !fault_heater_failure_active; break;
        case 5: fault_valve_stuck_closed      = !fault_valve_stuck_closed; if (fault_valve_stuck_closed) fault_valve_stuck_open = false; break;
        case 6: fault_valve_stuck_open        = !fault_valve_stuck_open; if (fault_valve_stuck_open) fault_valve_stuck_closed = false; break;
        case 7: impostaFaultAria(!fault_air_in_circuit); break;
        case 8: fault_heater_short_active     = !fault_heater_short_active; break;
        case 9: fault_float_stuck_high        = !fault_float_stuck_high; break;
        case 10: fault_float_stuck_low         = !fault_float_stuck_low; break;
        case 11: fault_float_no_signal         = !fault_float_no_signal; break;
        default: return;
    }
}

// Imposta lo stato del guasto aria nel circuito (idx 7) con comportamento unificato
// La massa acqua espulsa NON viene ripristinata al clear (persa fisicamente),
// il rabbocco automatico la reintegrerà se richiesto.
static void impostaFaultAria(bool nuovo) {
    if (nuovo && !fault_air_in_circuit) {
        fault_air_in_circuit = true;
        p_massa_acqua = max(p_massa_acqua - AIR_MASSA_ESPULSA_KG, 0.0f);
        errore_acqua = true;
        rele_carico_acqua = true;
        digitalWrite(PIN_RELE_ACQUA, LOW);
    } else if (!nuovo && fault_air_in_circuit) {
        fault_air_in_circuit = false;
        // NON ripristinare la massa: l'acqua espulsa dagli sfiatatoi è persa fisicamente.
        // Il rabbocco automatico (aggiornaRifornimentoAcqua) la reintegrerà se richiesto.
        if (!perdita_attiva && !acqua_pulse_attivo && !alarm_serbatoio_vuoto) {
            rele_carico_acqua = false;
            digitalWrite(PIN_RELE_ACQUA, HIGH);
            errore_acqua = false;
        }
    }
}

// Restituisce stato stringa di un guasto tramite indice
static const char* statoGuastoByIndex(uint8_t idx) {
    switch (idx) {
        case 0: return fault_clogging_active ? "ON" : "OFF";
        case 1: return fault_scaling_active ? "ON" : "OFF";
        case 2: return fault_insulation_loss_active ? "ON" : "OFF";
        case 3: return fault_sensor_drift_active ? "ON" : "OFF";
        case 4: return fault_heater_failure_active ? "ON" : "OFF";
        case 5: return fault_valve_stuck_closed ? "ON" : "OFF";
        case 6: return fault_valve_stuck_open ? "ON" : "OFF";
        case 7: return fault_air_in_circuit ? "ON" : "OFF";
        case 8: return fault_heater_short_active ? "ON" : "OFF";
        case 9: return fault_float_stuck_high ? "ON" : "OFF";
        case 10: return fault_float_stuck_low ? "ON" : "OFF";
        case 11: return fault_float_no_signal ? "ON" : "OFF";
        default: return "?";
    }
}

// Estrae numero slot (1-3) da comando stringa (es. SAVE1 -> 0)
static int estraiSlotComando(const char *s) {
    for (const char *p = s; *p; ++p) {
        if (*p >= '1' && *p <= '3') return (*p - '1');
    }
    return -1;
}

// Massimo indice guasto valido (0-based)
static constexpr int FAULT_MAX_IDX = 11;

// Estrae l'indice del guasto da una stringa di comando (es. GUASTO1 -> 0)
static int estraiIndiceGuasto(const char *s) {
    if (!s) return -1;

    const char *p = s;
    while (*p && !isdigit((unsigned char)*p)) ++p;
    if (!*p) return -1;

    char *endptr = nullptr;
    long raw = strtol(p, &endptr, 10);
    if (endptr == p) return -1;        // nessuna cifra letta
    int idx = (int)raw - 1;
    if (idx < 0 || idx > FAULT_MAX_IDX) return -1;
    return idx;
}

// Struttura per salvare/caricare profili di configurazione
struct ProcessProfile {
    float p_temp_rete;           // Temperatura della rete di raffreddamento [°C]
    float p_portata_base_cmd;    // Portata base della pompa [L/min]
    float p_massa_acqua;         // Massa dell'acqua nel serbatoio [kg]
    float p_pot_risc;            // Potenza resistenza riscaldamento [W]
    float p_pot_raffreddamento;  // Potenza unità raffreddamento [W]
    float p_k_hx;                // Coefficiente scambiatore termico [W/K]
    float p_pot_stampo;          // Potenza carico stampo [W]
    float p_temp_ambiente;       // Temperatura ambiente [°C]
    float p_k_disp_tubi;         // Coefficiente dispersione tubazioni [W/K]
    float p_k_disp_serbatoio;    // Coefficiente dispersione serbatoio [W/K]
    float p_massa_stampo;        // Massa dello stampo [kg]
    float K_stampo;              // Coefficiente scambio stampo [W/K]
    float ff_gain;               // Guadagno feedforward per compensazione carico
    float p_portata_valvola;     // Portata valvola riempimento [L/min]
    float p_ostruzione_circuito; // Fattore ostruzione circuito [0-1]
    float p_pressione_bar;       // Pressione impianto [bar]
    float p_dt_pompa;            // Incremento termico pompa [°C/h]
    float p_massa_tubi;          // Massa termica tubazioni [kg]
    float p_efficienza_pompa;    // Efficienza pompa [0-1]
    bool  is_olio;               // true se il fluido è olio, false se acqua
};

static ProcessProfile profili[3];

// Salva configurazione attuale in uno dei 3 slot profili
static void salvaProfilo(int idx) {
    if (idx < 0 || idx >= 3) return;
    profili[idx] = {
        p_temp_rete,
        p_portata_base_cmd,
        p_massa_acqua,
        p_pot_risc,
        p_pot_raffreddamento,
        p_k_hx,
        p_pot_stampo,
        p_temp_ambiente,
        p_k_disp_tubi,
        p_k_disp_serbatoio,
        p_massa_stampo,
        K_stampo,
        ff_gain,
        p_portata_valvola,
        p_ostruzione_circuito,
        p_pressione_bar,
        p_dt_pompa,
        p_massa_tubi,
        p_efficienza_pompa,
        is_olio
    };
}

// Carica configurazione da uno dei 3 slot profili
static void caricaProfilo(int idx) {
    if (idx < 0 || idx >= 3) return;
    const ProcessProfile &p = profili[idx];
    p_temp_rete = p.p_temp_rete;
    p_portata_base_cmd = p.p_portata_base_cmd;
    p_massa_acqua = p.p_massa_acqua;
    p_pot_risc = p.p_pot_risc;
    p_pot_raffreddamento = p.p_pot_raffreddamento;
    p_k_hx = p.p_k_hx;
    p_pot_stampo = p.p_pot_stampo;
    p_temp_ambiente = p.p_temp_ambiente;
    p_k_disp_tubi = p.p_k_disp_tubi;
    p_k_disp_serbatoio = p.p_k_disp_serbatoio;
    p_massa_stampo = p.p_massa_stampo;
    K_stampo = p.K_stampo;
    ff_gain = p.ff_gain;
    p_portata_valvola = p.p_portata_valvola;
    p_ostruzione_circuito = p.p_ostruzione_circuito;
    p_pressione_bar = p.p_pressione_bar;
    p_dt_pompa = p.p_dt_pompa;
    p_massa_tubi = p.p_massa_tubi;
    p_efficienza_pompa = p.p_efficienza_pompa;
    is_olio = p.is_olio;
    cp_fluido = is_olio ? CP_OLIO_VAL : CP_ACQUA;
    if (is_olio || p_pressione_bar <= 0.0f) {
        pressione_effettiva_bar = 0.0f;
    } else {
        pressione_effettiva_bar = p_pressione_bar;
    }
    t_ebollizione = is_olio ? 300.0f
                  : (pressione_effettiva_bar <= 0.0f) ? 100.0f
                  : temperaturaEbollizioneDaPressioneBar(pressione_effettiva_bar);
}

// Stampa statistiche ore funzionamento e usura componenti
static void stampaManutenzione() {
    const double ore_pompa = (double)ore_pompa_s / 3600000.0;
    const double ore_res = (double)ore_resistenza_s / 3600000.0;
    const double ore_hx = (double)ore_hx_s / 3600000.0;
    const double usura_pompa = constrain(ore_pompa * PUMP_WEAR_PER_HOUR, 0.0, 0.25);
    Serial.printf("MANUTENZIONE | POMPA:%6.1lf h | RES:%6.1lf h | HX:%6.1lf h | USURA_POMPA:%4.2lf | EFF_POMPA:%4.2f\n",
                  ore_pompa, ore_res, ore_hx, usura_pompa, p_efficienza_pompa);
    if (ore_hx > 2000.0f) Serial.println(F("NOTA: HX da verificare"));
    if (ore_pompa > 3000.0f) Serial.println(F("NOTA: pompa da controllare"));
    if (ore_res > 2500.0f) Serial.println(F("NOTA: resistenza da ispezionare"));
}

// Stampa stato guasti in formato compatto
static void stampaFaultSintetico() {
    Serial.printf("FAULT | OSTR:%s | CALC:%s | COIB:%s | DRIFT:%s | RESA:%s | VALV-CH:%s | VALV-AP:%s | ARIA:%s | CORTO:%s | FLT-HIGH:%s | FLT-LOW:%s | FLT-NO-SIG:%s\n",
                  fault_clogging_active ? "ON" : "OFF",
                  fault_scaling_active ? "ON" : "OFF",
                  fault_insulation_loss_active ? "ON" : "OFF",
                  fault_sensor_drift_active ? "ON" : "OFF",
                  fault_heater_failure_active ? "ON" : "OFF",
                  fault_valve_stuck_closed ? "ON" : "OFF",
                  fault_valve_stuck_open ? "ON" : "OFF",
                  fault_air_in_circuit ? "ON" : "OFF",
                  fault_heater_short_active ? "ON" : "OFF",
                  fault_float_stuck_high ? "ON" : "OFF",
                  fault_float_stuck_low ? "ON" : "OFF",
                  fault_float_no_signal ? "ON" : "OFF");
}

// Stampa allarmi attivi in formato leggibile
static void stampaAllarmiSintetici() {
    bool vuoto = true;
    Serial.print(F("ALLARMI: "));
    if (alarm_boiling) {
        Serial.print(F("Bollitura"));
        vuoto = false;
    }
    if (alarm_dry_run) {
        if (!vuoto) Serial.print(F(" | "));
        Serial.print(F("Secco"));
        vuoto = false;
    }
    if (alarm_pump_fail) {
        if (!vuoto) Serial.print(F(" | "));
        Serial.print(F("Guasto pompa"));
        vuoto = false;
    }
    if (warning_thermal_shock) {
        if (!vuoto) Serial.print(F(" | "));
        Serial.print(F("Shock termico"));
        vuoto = false;
    }
    if (alarm_circulation_insufficient) {
        if (!vuoto) Serial.print(F(" | "));
        Serial.print(F("Circolazione insufficiente"));
        vuoto = false;
    }
    if (alarm_serbatoio_vuoto) {
        if (!vuoto) Serial.print(F(" | "));
        Serial.print(F("Serbatoio vuoto"));
        vuoto = false;
    }
    if (alarm_cavitation) {
        if (!vuoto) Serial.print(F(" | "));
        Serial.print(F("Cavitazione"));
        vuoto = false;
    }
    if (alarm_sensor_dislodged) {
        if (!vuoto) Serial.print(F(" | "));
        Serial.print(F("Sonda uscita"));
        vuoto = false;
    }
    if (alarm_overheat_res) {
        if (!vuoto) Serial.print(F(" | "));
        Serial.print(F("Surriscaldo resistenza"));
        vuoto = false;
    }
    if (alarm_alta_pressione) {
        if (!vuoto) Serial.print(F(" | "));
        Serial.print(F("Alta pressione"));
        vuoto = false;
    }
    if (alarm_aria_circuito) {
        if (!vuoto) Serial.print(F(" | "));
        Serial.print(F("Aria nel circuito"));
        vuoto = false;
    }
    if (alarm_perdita_acqua) {
        if (!vuoto) Serial.print(F(" | "));
        Serial.print(F("Perdita d'acqua"));
        vuoto = false;
    }
    if (alarm_float_failure) {
        if (!vuoto) Serial.print(F(" | "));
        Serial.print(F("Guasto sensore livello"));
        vuoto = false;
    }
    if (vuoto) Serial.print(F("Nessuno"));
    Serial.println();
}

// Stampa riepilogo stato completo del sistema
static void stampaStatoSintetico() {
    const char* modo_pompa = (pump_mode == PUMP_MODE_AUTO) ? "AUTO" :
                             (pump_mode == PUMP_MODE_MANUAL_ON ? "MAN-ON" : "MAN-OFF");
    const bool richiesta_freddo = (raffreddamento_cmd || raffreddamento_attivo);
    const bool pompa_effettiva = (stato_pompa && p_portata > 0.0f && !alarm_serbatoio_vuoto);

    Serial.printf("POMPA:%s [%s] | FREDDO:%s | RIEMPIMENTO:%s | PULSO_ACQUA:%s | PRES:%4.2f bar\n",
                  stato_pompa ? "ON" : "OFF",
                  modo_pompa,
                  richiesta_freddo ? "ON" : "OFF",
                  rele_carico_acqua ? "ON" : "OFF",
                  acqua_pulse_attivo ? "ON" : "OFF",
                  pressione_effettiva_bar);

    Serial.printf("TERMICO | SERB:%6.2f C | MET:%6.2f C | TUBI:%6.2f C | MAND:%6.2f C | RIT:%6.2f C | STAMPO:%6.2f C | RES:%6.2f C\n",
                  temp_serbatoio,
                  temp_metallo,
                  temp_tubi,
                  temp_sonda_mandata,
                  temp_sonda_ritorno,
                  temp_stampo,
                  temp_resistenza);

    Serial.printf("FLUSSO  | PORTATA:%5.1f L/min | OST:%4.2f | ACQUA:%5.2f kg | POMPA EFF:%s\n",
                  p_portata,
                  p_ostruzione_circuito,
                  p_massa_acqua,
                  pompa_effettiva ? "SI" : "NO");

    Serial.printf("ENERGIA | Qhx:%7.0f W | Qraff:%7.0f W | Qfill:%7.0f W | Qconv:%7.0f W | Qproc:%7.0f W | Qpump:%7.0f W\n",
                  last_q_scambiatore,
                  last_q_raffreddamento,
                  last_q_iniezione,
                  last_q_conv,
                  last_q_proc,
                  last_q_pompa);

    stampaFaultSintetico();
    stampaAllarmiSintetici();
}

// Stampa dettaglio sonde e verifica coerenza termodinamica
static void stampaDettaglioSonde() {
    Serial.println(F("=============== DETTAGLIO SONDE ==============="));
    Serial.printf("SONDA MANDATA:\n");
    Serial.printf("  - Valore reale (t_mandata_reale):  %6.2f °C\n", t_mandata_reale);
    Serial.printf("  - Sonda pura (senza deriva):        %6.2f °C\n", temp_sonda_mandata_pura);
    Serial.printf("  - Sonda letta (con deriva):        %6.2f °C\n", temp_sonda_mandata);
    Serial.printf("  - Offset deriva attivo:            %6.2f °C\n", fault_sensor_drift_offset_c);
    Serial.printf("  - Guasto deriva attivo:             %s\n", fault_sensor_drift_active ? "SI" : "NO");
    Serial.printf("  - Offset calibrazione (R):         %6.3f ohm\n", r_offset_mandata_ohm);
    Serial.printf("  - Incertezza residua stimata:      +/-%5.3f °C\n", incertezzaResiduaStimataC(t_mandata_reale));
    Serial.printf("  - Valore mostrato su interfaccia:   %6.2f °C (rampa avvio +%.2f °C)\n",
                  temp_sonda_mandata_display, temp_sonda_mandata_display - temp_sonda_mandata);

    Serial.printf("\nSONDA RITORNO:\n");
    Serial.printf("  - Valore reale (t_ritorno_reale):  %6.2f °C\n", t_ritorno_reale);
    Serial.printf("  - Sonda pura (senza deriva):        %6.2f °C\n", temp_sonda_ritorno_pura);
    Serial.printf("  - Sonda letta:                      %6.2f °C\n", temp_sonda_ritorno);
    Serial.printf("  - Offset calibrazione (R):         %6.3f ohm\n", r_offset_ritorno_ohm);
    Serial.printf("  - Incertezza residua stimata:      +/-%5.3f °C\n", incertezzaResiduaStimataC(t_ritorno_reale));
    Serial.printf("  - Valore mostrato su interfaccia:   %6.2f °C (rampa avvio +%.2f °C)\n",
                  temp_sonda_ritorno_display, temp_sonda_ritorno_display - temp_sonda_ritorno);
    
    Serial.printf("\nTERMODINAMICA:\n");
    Serial.printf("  - Delta T ritorno (mandata - ritorno): %6.2f °C\n", t_mandata_reale - t_ritorno_reale);
    Serial.printf("  - Q_conv (scambio stampo):            %7.0f W\n", last_q_conv);
    Serial.printf("  - Portata massica:                     %6.3f kg/s\n", p_portata / 60.0f);
    Serial.printf("  - Cp fluido:                          %6.0f J/kg·K\n", cp_fluido);
    
    Serial.printf("\nVERIFICA TERMODINAMICA:\n");
    
    if (p_portata < 0.1f) {
        Serial.printf("  - ESITO: NESSUNA VERIFICA (pompa ferma, flusso nullo)\n");
    } else {
        float deltaT_calcolato = last_q_conv / (max(p_portata / 60.0f, 0.001f) * cp_fluido);
        float deltaT_misurato = t_mandata_reale - t_ritorno_reale;
        float errore_relativo = fabsf(deltaT_calcolato - deltaT_misurato) / max(fabsf(deltaT_calcolato), 0.1f) * 100.0f;
        
        Serial.printf("  - Delta T calcolato da Q_conv:        %6.2f °C\n", deltaT_calcolato);
        Serial.printf("  - Delta T misurato:                   %6.2f °C\n", deltaT_misurato);
        Serial.printf("  - Errore relativo:                    %6.2f %%\n", errore_relativo);
        
        if (errore_relativo < 5.0f) {
            Serial.printf("  - ESITO: COERENTE (errore < 5%%)\n");
        } else if (errore_relativo < 15.0f) {
            Serial.printf("  - ESITO: ACCETTABILE (errore < 15%%)\n");
        } else {
            Serial.printf("  - ESITO: DISCREPANZA SIGNIFICATIVA (errore >= 15%%)\n");
        }
    }
    
    Serial.printf("\nCONDIZIONI OPERATIVE:\n");
    Serial.printf("  - Circuito idraulico attivo:          %s\n", (stato_pompa && p_portata > 0.0f && !alarm_serbatoio_vuoto && p_massa_acqua > 0.0f) ? "SI" : "NO");
    Serial.printf("  - Temp serbatoio:                     %6.2f °C\n", temp_serbatoio);
    Serial.printf("  - Temp stampo:                        %6.2f °C\n", temp_stampo);
    Serial.printf("  - K_stampo:                           %6.1f W/K\n", K_stampo);
    Serial.printf("================================================\n");
}

// Stampa menu comandi disponibili
static void stampaMenu() {
    Serial.println(F("=============== SIMULATORE TERMICO ==============="));
    Serial.println(F("Comandi rapidi:"));
    Serial.println(F("  MENU o ?           -> mostra questo menu"));
    Serial.println(F("  STATO              -> stampa riepilogo immediato"));
    Serial.println(F("  SONDE              -> stampa dettaglio sonde e verifica termodinamica"));
    Serial.println(F("  HOURS / SERVICE    -> ore di lavoro e manutenzione"));
    Serial.println(F("  POMPA AUTO         -> automatico"));
    Serial.println(F("  POMPA ON / P1      -> pompa manuale ON"));
    Serial.println(F("  POMPA OFF / P0     -> pompa manuale OFF"));
    Serial.println(F("  RAFFREDDAMENTO ON  -> abilita richiesta freddo"));
    Serial.println(F("  RAFFREDDAMENTO OFF -> disabilita richiesta freddo"));
    Serial.println(F("  OLIO / H2O         -> selezione fluido"));
    Serial.println(F("  ACQUA              -> ricarica acqua per 3 secondi"));
    Serial.println(F("  PERDITA ON / OFF   -> simula o ferma la perdita"));
    Serial.println(F("  VALVOLA CHIUSA     -> valvola HX bloccata chiusa"));
    Serial.println(F("  VALVOLA APERTA     -> valvola HX bloccata aperta"));
    Serial.println(F("  VALVOLA NORMALE    -> rimuove blocco valvola"));
    Serial.println(F("  ARIA ON / OFF      -> aria nel circuito (apre valvola riempimento)"));
    Serial.println(F("  CORTO ON / OFF     -> corto parziale resistenza (+15% pot, RES piu calda)"));
    Serial.println(F("  SAVE1..3 / LOAD1..3-> salva o carica profilo"));
    Serial.println(F("  CALIBRA            -> autocalibra offset sonde mandata/ritorno (pompa OFF)"));
    Serial.println(F("  CALIBRA <m> <r>    -> calibra su lettura regolatore esterno (es: CALIBRA 19.2 18.6)"));
    Serial.println(F("  CALIBRA RESET      -> azzera offset di calibrazione sonde"));
    Serial.println(F("  RIPRISTINA         -> reset completo dello stato (temp = ambiente)"));
    Serial.println(F("  T_RETE             -> reset completo con temperatura iniziale = temperatura rete"));
    Serial.println(F("Parametri numerici (esempio: F3000 oppure T45.0):"));
    Serial.println(F("  T rete [C]"));
    Serial.println(F("  E ambiente [C]"));
    Serial.println(F("  L portata base [L/min]"));
    Serial.println(F("  A massa acqua [kg]"));
    Serial.println(F("  M massa stampo [kg]"));
    Serial.println(F("  J massa tubi [kg]"));
    Serial.println(F("  K efficienza pompa [0..1]"));
    Serial.println(F("  R potenza resistenza [W]"));
    Serial.println(F("  F potenza raffreddamento [W]"));
    Serial.println(F("  S carico stampo [W]"));
    Serial.println(F("  X dispersione tubi [W/K]"));
    Serial.println(F("  Y dispersione serbatoio [W/K]"));
    Serial.println(F("  V portata valvola riempimento [L/min]"));
    Serial.println(F("  P pressione impianto [bar]"));
    Serial.println(F("  O ostruzione circuito [0..1]"));
    Serial.println(F("Guasti via seriale:"));
    Serial.println(F("  GUASTO1 ON/OFF   -> ostruzione (riduce portata + aumenta pressione a monte)"));
    Serial.println(F("  GUASTO2 ON/OFF   -> calcare (HX a 50%, serb non riesce a cedere calore)"));
    Serial.println(F("  GUASTO3 ON/OFF   -> perdita coibentazione (dispersioni x10)"));
    Serial.println(F("  GUASTO4 ON/OFF   -> deriva sensore (+0.5 C/min, max 10 C)"));
    Serial.println(F("  GUASTO5 ON/OFF   -> fase bruciata (pot -33%, RES si scalda di piu)"));
    Serial.println(F("  GUASTO6 ON/OFF   -> valvola chiusa (nessun scambio -> bollitura)"));
    Serial.println(F("  GUASTO7 ON/OFF   -> valvola aperta (scambio sempre max -> allarme setpoint)"));
    Serial.println(F("  GUASTO8 ON/OFF   -> aria nel circuito (espelle acqua, apre rele riempimento)"));
    Serial.println(F("  GUASTO9 ON/OFF   -> galleggiante falso pieno (stuck-high)"));
    Serial.println(F("  GUASTO10 ON/OFF  -> galleggiante falso vuoto (stuck-low)"));
    Serial.println(F("  GUASTO11 ON/OFF  -> galleggiante nessun segnale (scollegato/rotto)"));
    Serial.println(F("--------------------------------------------------"));
    Serial.printf("Valori | T rete:%5.1f C | T amb:%5.1f C | Portata base:%5.1f L/min | Pressione:%4.2f bar\n",
                  p_temp_rete, p_temp_ambiente, p_portata_base_cmd, p_pressione_bar);
    Serial.printf("Impianto | Res:%7.0f W | HX:%6.1f W/K | Stampo:%6.0f W | Valvola:%4.1f L/min | Ost:%4.2f\n",
                  p_pot_risc, p_k_hx, p_pot_stampo, p_portata_valvola, p_ostruzione_circuito);
    Serial.printf("Pompa    | DT pompa:%5.2f C/h | Massa tubi:%5.2f kg | Eff pompa:%4.2f | Aria:%s\n",
                  p_dt_pompa, p_massa_tubi, p_efficienza_pompa,
                  fault_air_in_circuit ? "GUASTO" : "OK");
    stampaFaultSintetico();
    stampaAllarmiSintetici();
    Serial.println(F("=================================================="));
}

// Reset completo dello stato termico a temperatura specificata o ambiente
static void resetStatoTermico(float temp_iniziale = -999.0f) {
    const float t0 = (temp_iniziale > -500.0f) ? temp_iniziale : p_temp_ambiente;
    mantieni_temp_iniziale = (temp_iniziale > -500.0f);  // Mantieni temp iniziale solo se specificata

    temp_resistenza    = t0;
    temp_resistenza_filtrata = t0;
    temp_metallo       = t0;
    temp_nucleo_res    = t0;
    temp_serbatoio     = t0;
    temp_tubi          = t0;
    temp_sonda_mandata = t0;
    temp_sonda_ritorno = t0;
    temp_sonda_mandata_pura = t0;
    temp_sonda_ritorno_pura = t0;
    temp_sonda_mandata_display = t0;
    temp_sonda_ritorno_display = t0;
    ramp_display_accum_ms = 0.0f;  // riavvia la rampa display ad ogni reset termico
    temp_stampo        = t0;
    t_mandata_stasi    = t0;
    t_ritorno_stasi    = t0;
    t_mandata_reale    = t0;
    t_ritorno_reale    = t0;

    p_massa_acqua = MASSA_ACQUA_NOMINALE;
    p_portata_base_cmd = PORTATA_NOMINALE_LMIN;
    p_portata = PORTATA_NOMINALE_LMIN;
    p_ostruzione_circuito = 0.0f;
    p_pressione_bar = 0.0f;
    p_efficienza_pompa = 1.0f;
    p_massa_tubi = 6.0f;
    pressione_effettiva_bar = p_pressione_bar;

    // Ricarica l'offset di calibrazione salvato in flash (se presente) invece
    // di azzerarlo semplicemente: cosi' anche dopo RESET/RIPRISTINA la sonda
    // mandata resta calibrata come prima, invece di ripartire "scoperta".
    caricaCalibrazioneNVS();

    for (int i = 0; i < DEAD_BUF_SIZE; ++i) dead_buffer[i] = t0;
    dead_buf_idx = 0;
    deadtime_last_out = t0;
    deadtime_accum_s  = 0.0f;

    adc_filtrato = 0.0f;
    apertura_valvola_hx = 0.0f;
    cooling_pin_last_raw = false;
    cooling_pin_filtered = false;
    t_last_cooling_change_ms = 0UL;
    t_last_cooling_active_ms = 0UL;
    pump_mode = PUMP_MODE_AUTO;
    pump_manual_override = false;
    stato_pompa = false;

    errore_acqua = false;
    raffreddamento_cmd = false;
    perdita_attiva = false;
    raffreddamento_attivo = false;
    rele_carico_acqua = false;
    acqua_pulse_attivo = false;
    t_pulse_acqua = 0UL;

    fault_clogging_active = false;
    fault_scaling_active = false;
    fault_insulation_loss_active = false;
    fault_sensor_drift_active = false;
    fault_heater_failure_active = false;
    fault_valve_stuck_closed = false;
    fault_valve_stuck_open = false;
    fault_air_in_circuit = false;
    fault_heater_short_active = false;
    fault_float_stuck_high = false;
    fault_float_stuck_low = false;
    fault_float_no_signal = false;
    fault_sensor_drift_offset_c = 0.0f;

    ore_pompa_s = 0ULL;
    ore_resistenza_s = 0ULL;
    ore_hx_s = 0ULL;

    alarm_boiling = false;
    alarm_dry_run = false;
    alarm_pump_fail = false;
    warning_thermal_shock = false;
    alarm_circulation_insufficient = false;
    alarm_serbatoio_vuoto = false;
    alarm_cavitation = false;
    alarm_sensor_dislodged = false;
    alarm_overheat_res = false;
    alarm_alta_pressione = false;
    alarm_aria_circuito = false;
    alarm_perdita_acqua = false;
    alarm_float_failure = false;
    alarm_heater_short = false;

    t_pump_fail_ms = 0UL;
    t_shock_ms = 0UL;
    t_circ_ms = 0UL;
    t_cav_ms = 0UL;
    t_sond_ms = 0UL;
    t_overheat_ms = 0UL;
    t_heater_short_ms = 0UL;
    t_press_ms = 0UL;
    t_aria_attivazione_ms = 0UL;
    t_setpoint_fail_ms = 0UL;
    t_pressione_alta_05bar_ms = 0UL;
    t_serb_snapshot = 0.0f;
    warning_setpoint_fail_prev = false;
    t_inizio_riempimento = 0UL;
    t_ultimo_riempimento = 0UL;
    t_totale_riempimento_ms = 0UL;
    heat_latched = false;
    p_portata_filtrata_global = PORTATA_NOMINALE_LMIN;  // Reset portata filtrata

    // Reset variabili statiche spostate a scope file
    richiesta_freddo_stabile = false;
    t_ultimo_cambio_freddo_ms = 0UL;
    dither_accum_mandata = 0.0f;
    dither_accum_ritorno = 0.0f;
    last_pump_mode = PUMP_MODE_AUTO;
}

// Reset stato termico con temperatura iniziale = temperatura rete
static void resetStatoTermicoDaRete() {
    resetStatoTermico(p_temp_rete);
    Serial.printf("OK: stato ripristinato con temperatura iniziale = %.1f C (temperatura rete)\n", p_temp_rete);
}

// Gestisce i pulsanti fisici per attivare/disattivare i guasti (debounce 200ms)
static void gestisciFaultButtons(unsigned long now_ms) {
    struct ButtonInfo { uint8_t pin; bool last_state; unsigned long last_change; };
    static bool first_call = true;
    static ButtonInfo buttons[5] = {
        {FAULT_BTN_1_LOCAL, true, 0UL},
        {FAULT_BTN_2_LOCAL, true, 0UL},
        {FAULT_BTN_3_LOCAL, true, 0UL},
        {FAULT_BTN_4_LOCAL, true, 0UL},
        {FAULT_BTN_5_LOCAL, true, 0UL},
    };
    if (first_call) {
        first_call = false;
        for (uint8_t i = 0; i < 5; ++i) buttons[i].last_change = now_ms;
    }

    for (uint8_t i = 0; i < 5; ++i) {
        if (!pinValido(buttons[i].pin)) continue;
        bool stato = (digitalRead(buttons[i].pin) == LOW); // attivo LOW
        if (stato != buttons[i].last_state && (now_ms - buttons[i].last_change) > 200UL) {
            buttons[i].last_change = now_ms;
            buttons[i].last_state = stato;
            if (stato) {
                toggleFaultState(i);
                Serial.printf("OK: tasto fisico %u -> guasto %u %s\n", (unsigned)(i + 1), (unsigned)(i + 1),
                              (i == 0 ? (fault_clogging_active ? "ON" : "OFF") :
                               i == 1 ? (fault_scaling_active ? "ON" : "OFF") :
                               i == 2 ? (fault_insulation_loss_active ? "ON" : "OFF") :
                               i == 3 ? (fault_sensor_drift_active ? "ON" : "OFF") :
                                        (fault_heater_failure_active ? "ON" : "OFF")));
            }
        }
    }
}

// Avvia impulso di riempimento acqua (durata 3 secondi)
static void avviaPulsoAcqua(unsigned long now_ms) {
    acqua_pulse_attivo = true;
    t_pulse_acqua = now_ms;
    rele_carico_acqua = true;
    digitalWrite(PIN_RELE_ACQUA, LOW);   // relè attivo LOW
    Serial.println(F("OK: ricarica acqua avviata per 3 secondi"));
}

// Gestisce comando guasto da seriale (ON/OFF/toggle)
static void gestisciComandoGuasto(char *input) {
    int idx = estraiIndiceGuasto(input);
    if (idx < 0) return;

    bool chiedi_on  = (strstr(input, "ON")  != nullptr);
    bool chiedi_off = (strstr(input, "OFF") != nullptr);
    bool nuovo_stato;

    if      (chiedi_on && !chiedi_off) nuovo_stato = true;
    else if (chiedi_off)               nuovo_stato = false;
    else                               nuovo_stato = !( // toggle: leggi stato attuale
        idx == 0 ? fault_clogging_active :
        idx == 1 ? fault_scaling_active :
        idx == 2 ? fault_insulation_loss_active :
        idx == 3 ? fault_sensor_drift_active :
        idx == 4 ? fault_heater_failure_active :
        idx == 5 ? fault_valve_stuck_closed :
        idx == 6 ? fault_valve_stuck_open :
        idx == 7 ? fault_air_in_circuit :
        idx == 8 ? fault_heater_short_active :
        idx == 9 ? fault_float_stuck_high :
        idx == 10 ? fault_float_stuck_low :
                    fault_float_no_signal);

    if (idx == 7) {
        impostaFaultAria(nuovo_stato);
        Serial.printf("OK: guasto 8 = %s\n", fault_air_in_circuit ? "ON" : "OFF");
        return;
    }

    setFaultState((uint8_t)idx, nuovo_stato);
    Serial.printf("OK: guasto %d = %s\n", idx + 1, statoGuastoByIndex((uint8_t)idx));
}

// Gestisce comandi da seriale (handshake, menu, parametri, guasti)
static void gestisciSerial() {
    if (!Serial.available()) return;

    char input[128] = {0};
    size_t n = Serial.readBytesUntil('\n', input, 127);
    input[n] = '\0';

    trimInPlace(input);
    toUpperInPlace(input);

    if (strcmp(input, "NOME?") == 0 || strcmp(input, "HANDSHAKE") == 0 || strstr(input, "NOME") != nullptr) {
        Serial.println("TERMOREGOLATORE");
        handshake_done = true;
        return;
    }

    if (strcmp(input, "?") == 0 || strcmp(input, "MENU") == 0 || strcmp(input, "AIUTO") == 0) {
        stampaMenu();
        return;
    }

    if (strcmp(input, "STATO") == 0) {
        stampaStatoSintetico();
        return;
    }

    if (strcmp(input, "SONDE") == 0 || strcmp(input, "SONDA") == 0 || strcmp(input, "SENSORI") == 0) {
        stampaDettaglioSonde();
        return;
    }

    if (strcmp(input, "HOURS") == 0 || strcmp(input, "SERVICE") == 0) {
        stampaManutenzione();
        return;
    }

    if (startsWithToken(input, "SAVE")) {
        int slot = estraiSlotComando(input);
        if (slot >= 0) {
            salvaProfilo(slot);
            Serial.printf("OK: profilo %d salvato\n", slot + 1);
        } else {
            Serial.println(F("ERRORE: usa SAVE1..3"));
        }
        return;
    }

    if (startsWithToken(input, "LOAD")) {
        int slot = estraiSlotComando(input);
        if (slot >= 0) {
            caricaProfilo(slot);
            Serial.printf("OK: profilo %d caricato\n", slot + 1);
        } else {
            Serial.println(F("ERRORE: usa LOAD1..3"));
        }
        return;
    }

    if (strcmp(input, "VALVOLA CHIUSA") == 0 || strcmp(input, "VALVOLA STUCK CLOSED") == 0) {
        fault_valve_stuck_closed = true;
        fault_valve_stuck_open = false;
        Serial.println(F("OK: valvola HX bloccata chiusa"));
        return;
    }

    if (strcmp(input, "VALVOLA APERTA") == 0 || strcmp(input, "VALVOLA STUCK OPEN") == 0) {
        fault_valve_stuck_open = true;
        fault_valve_stuck_closed = false;
        Serial.println(F("OK: valvola HX bloccata aperta"));
        return;
    }

    if (strcmp(input, "VALVOLA NORMALE") == 0 || strcmp(input, "VALVOLA OFF") == 0) {
        fault_valve_stuck_open = false;
        fault_valve_stuck_closed = false;
        Serial.println(F("OK: valvola HX ripristinata"));
        return;
    }

    if (strcmp(input, "ARIA ON") == 0) {
        impostaFaultAria(true);
        Serial.println(F("OK: aria nel circuito attivata"));
        return;
    }

    if (strcmp(input, "ARIA OFF") == 0) {
        impostaFaultAria(false);
        Serial.println(F("OK: aria nel circuito rimossa (massa NON ripristinata, va reintegrata dal riempimento)"));
        return;
    }

    if (strcmp(input, "CORTO ON") == 0) {
        fault_heater_short_active = true;
        fault_heater_failure_active = false;
        Serial.println(F("OK: corto parziale resistenza attivo"));
        return;
    }

    if (strcmp(input, "CORTO OFF") == 0) {
        fault_heater_short_active = false;
        Serial.println(F("OK: corto parziale resistenza disattivato"));
        return;
    }

    if (strcmp(input, "CALIBRA") == 0 || strcmp(input, "CALIBRA SONDE") == 0) {
        autocalibraSonde();
        return;
    }

    if (startsWithToken(input, "CALIBRA ") && strcmp(input, "CALIBRA RESET") != 0 && strcmp(input, "CALIBRA SONDE") != 0) {
        // Forma: CALIBRA <t_mandata_regolatore> <t_ritorno_regolatore>
        float v_mandata = 0.0f, v_ritorno = 0.0f;
        int n = sscanf(input + 8, "%f %f", &v_mandata, &v_ritorno);
        if (n == 2) {
            autocalibraSondeDaRiferimento(v_mandata, v_ritorno);
        } else {
            Serial.println(F("ERRORE: formato non valido."));
            Serial.println(F("Uso: CALIBRA <t_mandata_regolatore> <t_ritorno_regolatore>"));
            Serial.println(F("Esempio: CALIBRA 19.2 18.6"));
        }
        return;
    }

    if (strcmp(input, "CALIBRA RESET") == 0) {
        r_offset_mandata_ohm = 0.0f;
        r_offset_ritorno_ohm = 0.0f;
        cancellaCalibrazioneNVS();
        Serial.println(F("OK: offset di calibrazione azzerati (mandata e ritorno) e memoria flash cancellata"));
        return;
    }

    if (startsWithToken(input, "GUASTO") || startsWithToken(input, "FAULT")) {
        gestisciComandoGuasto(input);
        return;
    }
    
    // Routing a cifra singola per compatibilità: accetta "1"-"12", "1 ON", "12 OFF", ecc.
    // come comandi guasto. Richiede che il PRIMO token sia numerico (1-2 cifre) ed
    // eventualmente seguito da uno spazio + "ON"/"OFF"; evita attivazioni accidentali
    // da comandi numerici futuri controllando che dopo le cifre ci sia solo uno spazio
    // seguito da ON/OFF, oppure fine stringa.
    {
        size_t len = strlen(input);
        if (len >= 1 && input[0] >= '1' && input[0] <= '9') {
            size_t i = 0;
            while (i < len && isdigit((unsigned char)input[i])) ++i;

            bool token_valido = (i >= 1 && i <= 2);          // 1 o 2 cifre iniziali
            bool resto_valido = (i == len)                    // solo cifre (es. "1", "12")
                || (input[i] == ' '                            // oppure "<cifre> ON/OFF"
                    && (strcmp(input + i + 1, "ON") == 0 || strcmp(input + i + 1, "OFF") == 0));

            if (token_valido && resto_valido) {
                gestisciComandoGuasto(input);
                return;
            }
        }
    }

    if (strcmp(input, "ACQUA") == 0 || strcmp(input, "REINTEGRA") == 0) {
        errore_acqua = true;
        avviaPulsoAcqua(millis());
        return;
    }

    if (strcmp(input, "PERDITA ON") == 0 || strcmp(input, "PERDITA") == 0) {
        errore_acqua = true;
        perdita_attiva = true;
        rele_carico_acqua = true;
        acqua_pulse_attivo = false;
        digitalWrite(PIN_RELE_ACQUA, LOW);
        Serial.println(F("OK: simulazione perdita attiva, relè acqua forzato ON"));
        return;
    }

    if (strcmp(input, "PERDITA OFF") == 0) {
        perdita_attiva = false;
        if (!acqua_pulse_attivo && !alarm_serbatoio_vuoto) {
            rele_carico_acqua = false;
            digitalWrite(PIN_RELE_ACQUA, HIGH);
        }
        if (!alarm_serbatoio_vuoto) {
            errore_acqua = false;
        }
        Serial.println(F("OK: simulazione perdita disattivata"));
        return;
    }

    if (strcmp(input, "RAFFREDDAMENTO ON") == 0 || strcmp(input, "RAFFREDDAMENTO") == 0 || startsWithToken(input, "FREDDO ON") || strcmp(input, "START") == 0 || strcmp(input, "ON") == 0 || strcmp(input, "MACCHINA ON") == 0) {
        raffreddamento_attivo = true;
        macchina_accesa = true;
        Serial.println(F("OK: macchina accesa e richiesta freddo attiva"));
        return;
    }

    if (strcmp(input, "RAFFREDDAMENTO OFF") == 0 || strcmp(input, "STOP") == 0 || startsWithToken(input, "FREDDO OFF") || strcmp(input, "OFF") == 0 || strcmp(input, "MACCHINA OFF") == 0) {
        raffreddamento_attivo = false;
        macchina_accesa = false;
        Serial.println(F("OK: macchina spenta e richiesta freddo disattivata"));
        return;
    }

    if (strcmp(input, "RIPRISTINA") == 0 || strcmp(input, "RESET") == 0) {
        resetStatoTermico();
        digitalWrite(PIN_RELE_ACQUA, HIGH);
        Serial.println(F("OK: stato ripristinato"));
        return;
    }

    if (strcmp(input, "T_RETE") == 0) {
        resetStatoTermicoDaRete();
        digitalWrite(PIN_RELE_ACQUA, HIGH);
        return;
    }

    if (strcmp(input, "POMPA AUTO") == 0 || strcmp(input, "PAUTO") == 0) {
        pump_manual_override = false;
        pump_mode = PUMP_MODE_AUTO;
        Serial.println(F("OK: pompa in automatico"));
        return;
    }

    if (strcmp(input, "POMPA ON") == 0 || strcmp(input, "P1") == 0) {
        pump_manual_override = true;
        pump_mode = PUMP_MODE_MANUAL_ON;
        stato_pompa = true;
        mantieni_temp_iniziale = false;  // Reset flag quando pompa si accende
        t_ultimo_comando_auto_pompa = millis();
        Serial.println(F("OK: pompa ON manuale"));
        return;
    }

    if (strcmp(input, "POMPA OFF") == 0 || strcmp(input, "P0") == 0) {
        pump_manual_override = true;
        pump_mode = PUMP_MODE_MANUAL_OFF;
        stato_pompa = false;
        Serial.println(F("OK: pompa OFF manuale"));
        return;
    }

    if (strcmp(input, "OLIO") == 0) {
        is_olio = true;
        cp_fluido = CP_OLIO_VAL;
        t_ebollizione = 300.0f;
        p_pressione_bar = 0.0f;
        Serial.println(F("OK: fluido impostato su OLIO"));
        Serial.println(F("INFO: pressione forzata a 0 (non modificabile in modalita olio)"));
        return;
    }

    if (strcmp(input, "H2O") == 0) {
        is_olio = false;
        cp_fluido = CP_ACQUA;
        if (p_pressione_bar <= 0.0f) {
            pressione_effettiva_bar = 0.0f;
        } else {
            pressione_effettiva_bar = p_pressione_bar;
        }
        t_ebollizione = (pressione_effettiva_bar <= 0.0f) ? 100.0f
                      : temperaturaEbollizioneDaPressioneBar(pressione_effettiva_bar);
        Serial.println(F("OK: fluido impostato su ACQUA"));
        return;
    }

    const char lettera = input[0];
    if (!isalpha((unsigned char)lettera)) {
        Serial.println(F("Comando non riconosciuto. Digita MENU o ?"));
        return;
    }

    char *endptr = nullptr;
    float val = strtof(input + 1, &endptr);
    if (endptr == input + 1 || *endptr != '\0') {
        Serial.println(F("ERRORE: valore numerico non valido"));
        return;
    }

    switch (lettera) {
        case 'T': p_temp_rete          = clampTempRealistica(val);
                  Serial.printf("OK: T rete = %.1f C\n", p_temp_rete);                      break;
        case 'E': p_temp_ambiente      = clampTempRealistica(val);
                  Serial.printf("OK: T ambiente = %.1f C\n", p_temp_ambiente);              break;
        case 'L': p_portata_base_cmd   = max(0.0f, val);
                  Serial.printf("OK: portata base = %.1f L/min\n", p_portata_base_cmd);     break;
        case 'A':
            p_massa_acqua = max(0.0f, val);
            // Se l'utente imposta massa acqua sopra la soglia, resetta allarme serbatoio vuoto
            if (p_massa_acqua >= MASSA_SERBATOIO_VUOTO_OFF_KG && alarm_serbatoio_vuoto) {
                alarm_serbatoio_vuoto = false;
                errore_acqua = false;
                Serial.println(F("OK: allarme serbatoio vuoto resettato - massa acqua sufficiente"));
            }
            Serial.printf("OK: massa acqua = %.1f kg\n", p_massa_acqua);
            break;
        case 'M': p_massa_stampo       = max(0.1f, val);
                  Serial.printf("OK: massa stampo = %.1f kg\n", p_massa_stampo);            break;
        case 'J': p_massa_tubi         = max(0.1f, val);
                  Serial.printf("OK: massa tubi = %.1f kg (tau_tubi = %.1f s)\n",
                                p_massa_tubi, 4.0f + 1.6f * p_massa_tubi);                  break;
        case 'K': p_efficienza_pompa   = constrain(val, 0.30f, 1.0f);
                  Serial.printf("OK: efficienza pompa = %.2f (%.0f%%)\n",
                                p_efficienza_pompa, p_efficienza_pompa * 100.0f);            break;
        case 'X': p_k_disp_tubi        = max(0.0f, val);
                  Serial.printf("OK: dispersione tubi = %.1f W/K\n", p_k_disp_tubi);       break;
        case 'Y': p_k_disp_serbatoio   = max(0.0f, val);
                  Serial.printf("OK: dispersione serbatoio = %.1f W/K\n", p_k_disp_serbatoio); break;
        case 'R': p_pot_risc           = constrain(val, 0.0f, POTENZA_RISCALDO_MAX_W);
                  Serial.printf("OK: potenza resistenza = %.0f W\n", p_pot_risc);           break;
        case 'F': p_pot_raffreddamento = constrain(val, 0.0f, POTENZA_RAFFREDDAMENTO_MAX_W);
                  Serial.printf("OK: potenza raffreddamento = %.0f W\n", p_pot_raffreddamento); break;
        case 'S': p_pot_stampo         = val;
                  Serial.printf("OK: carico stampo = %.0f W\n", p_pot_stampo);              break;
        case 'V': p_portata_valvola    = constrain(val, 0.0f, PORTATA_VALVOLA_MAX_LMIN);
                  Serial.printf("OK: portata valvola = %.1f L/min\n", p_portata_valvola);   break;
        case 'P':
            if (is_olio) {
                Serial.println(F("ATTENZIONE: pressione non modificabile in modalita olio"));
            } else {
                p_pressione_bar = constrain(val, 0.0f, 5.0f);
                if (p_pressione_bar <= 0.0f) {
                    pressione_effettiva_bar = 0.0f;
                } else {
                    pressione_effettiva_bar = p_pressione_bar;
                }
            }
            break;
        case 'O': p_ostruzione_circuito = constrain(val, 0.0f, 1.0f);                        break;
        case 'D': p_dt_pompa           = constrain(val, 0.0f, 20.0f);                        break;
        default:
            Serial.println(F("Comando non riconosciuto. Digita MENU o ?"));
            break;
    }
}

// Verifica tutti gli allarmi di sicurezza del sistema
static void checkAlarms(float t_mandata_locale,
                        float t_ritorno_locale,
                        float flusso_lmin,
                        bool richiesta_freddo,
                        bool pompa_effettiva,
                        float frac_caldo,
                        float frac_caldo_raw,
                        float pressione_locale_bar,
                        unsigned long now_ms) {

    // ── 0x01 BOLLITURA ─────────────────────────────────────────────
    {
        const bool cond_on  = (temp_serbatoio >= t_ebollizione);
        const bool cond_off = (temp_serbatoio <  t_ebollizione - 2.0f);
        if (!alarm_boiling && cond_on) {
            alarm_boiling = true;
            if (is_olio)
                Serial.printf("ALLARME [DEGRADO TERMICO OLIO] T olio %.1f°C >= soglia %.0f°C - RISCALDO FORZATO OFF\n",
                              temp_serbatoio, t_ebollizione);
            else
                Serial.printf("ALLARME [BOLLITURA] Serb %.1f°C >= Teb %.1f°C a %.2f bar - RISCALDO FORZATO OFF\n",
                              temp_serbatoio, t_ebollizione, pressione_locale_bar);
            adc_filtrato = 0.0f;
        } else if (alarm_boiling && cond_off) {
            alarm_boiling = false;
            Serial.println(F("RIPRISTINO [BOLLITURA] Temperatura rientrata sotto soglia"));
        }
    }

    // ── 0x02 MARCIA A SECCO ────────────────────────────────────────
    // In modalità olio il fluido non evapora: soglia critica ridotta al 10% (circuito quasi vuoto)
    {
        float soglia_secco_on  = is_olio ? (MASSA_CRITICA_ACQUA * 0.3f) : MASSA_CRITICA_ACQUA;
        float soglia_secco_off = soglia_secco_on + 0.3f;  // 0.3 kg di isteresi
        const bool cond_massa = alarm_dry_run ? (p_massa_acqua < soglia_secco_off)
                                               : (p_massa_acqua < soglia_secco_on);
        // OR con cause esterne (surriscaldo resistenza, guasto galleggiante) per evitare chatter
        const bool cond = cond_massa || (temp_metallo > TEMP_RES_OVERHEAT_C) || alarm_float_failure;
        if (cond != alarm_dry_run) {
            alarm_dry_run = cond;
            if (cond) {
                Serial.printf(is_olio
                    ? "ALLARME [SECCO-OLIO] Massa olio %.2f kg < soglia %.1f kg - RISCALDO FORZATO OFF\n"
                    : "ALLARME [SECCO] Massa acqua %.2f kg < soglia %.1f kg - RISCALDO FORZATO OFF\n",
                              p_massa_acqua, soglia_secco_on);
                adc_filtrato = 0.0f;
                if (!richiesta_freddo && (pump_mode == PUMP_MODE_AUTO || pump_manual_override)) {
                    stato_pompa = false;
                    Serial.println(F("ALLARME [SECCO] Pompa fermata (marcia a secco senza raffreddamento)"));
                }
            } else {
                Serial.println(F("RIPRISTINO [SECCO] Livello acqua ripristinato"));
            }
        }
    }

    // ── 0x04 GUASTO POMPA ──────────────────────────────────────────
    {
        const bool pompa_on_con_acqua = (stato_pompa && p_massa_acqua > MASSA_CRITICA_ACQUA && !alarm_serbatoio_vuoto);
        const bool flusso_assente = (flusso_lmin < 0.5f);
        const bool cond = (pompa_on_con_acqua && flusso_assente);
        if (cond) {
            if (t_pump_fail_ms == 0UL) t_pump_fail_ms = now_ms;
            if (!alarm_pump_fail && (now_ms - t_pump_fail_ms >= 3000UL)) {
                alarm_pump_fail = true;
                Serial.println(F("ALLARME [POMPA] Pompa ON e acqua presente ma flusso nullo - verificare girante/valvola"));
            }
        } else {
            t_pump_fail_ms = 0UL;
            if (alarm_pump_fail) {
                alarm_pump_fail = false;
                Serial.println(F("RIPRISTINO [POMPA] Flusso rilevato"));
            }
        }
    }

    // ── 0x08 SHOCK TERMICO ─────────────────────────────────────────
    {
        const float delta_t = fabsf(t_mandata_locale - t_ritorno_locale);
        const bool pompa_gira_stabilmente = (stato_pompa && flusso_lmin >= PORTATA_MIN_CIRC_LMIN);
        const bool cond = (pompa_gira_stabilmente && delta_t > THERMAL_SHOCK_DELTA_C);
        if (cond) {
            if (t_shock_ms == 0UL) t_shock_ms = now_ms;
            if (!warning_thermal_shock && (now_ms - t_shock_ms >= SHOCK_DEBOUNCE_MS)) {
                warning_thermal_shock = true;
                Serial.printf("ALLARME [SHOCK TERMICO] DeltaT %.1f°C > soglia %.1f°C (portata %.1f L/min)\n",
                              delta_t, (float)THERMAL_SHOCK_DELTA_C, flusso_lmin);
            }
        } else {
            t_shock_ms = 0UL;
            if (warning_thermal_shock) {
                warning_thermal_shock = false;
                Serial.println(F("RIPRISTINO [SHOCK TERMICO] DeltaT rientrato"));
            }
        }
    }

    // ── 0x10 CIRCOLAZIONE INSUFFICIENTE ────────────────────────────
    {
        const bool circ_bassa = (pompa_effettiva && flusso_lmin < PORTATA_MIN_CIRC_LMIN);
        const bool risc_senza_pompa = (frac_caldo_raw > (HEAT_ON_TH * 2.0f) && !stato_pompa && p_massa_acqua > MASSA_CRITICA_ACQUA);
        const bool cond = (circ_bassa || risc_senza_pompa);
        if (cond) {
            if (t_circ_ms == 0UL) t_circ_ms = now_ms;
            if (!alarm_circulation_insufficient && (now_ms - t_circ_ms >= CIRC_DEBOUNCE_MS)) {
                alarm_circulation_insufficient = true;
                if (circ_bassa)
                    Serial.printf("ALLARME [CIRCOLAZIONE] Portata %.2f L/min < minimo %.1f L/min\n",
                                  flusso_lmin, PORTATA_MIN_CIRC_LMIN);
                else
                    Serial.println(F("ALLARME [CIRCOLAZIONE] Riscaldamento attivo con pompa ferma"));
            }
        } else {
            t_circ_ms = 0UL;
            if (alarm_circulation_insufficient) {
                alarm_circulation_insufficient = false;
                Serial.printf("RIPRISTINO [CIRCOLAZIONE] Portata %.1f L/min\n", flusso_lmin);
            }
        }
    }

    // ── 0x40 CAVITAZIONE ───────────────────────────────────────────
    {
        const bool sistema_pressurizzato = (!is_olio && pressione_locale_bar > 0.5f);
        if (sistema_pressurizzato && t_pressione_alta_05bar_ms == 0UL) {
            t_pressione_alta_05bar_ms = now_ms;
        }
        if (!sistema_pressurizzato) {
            t_pressione_alta_05bar_ms = 0UL;
        }
        const bool pressione_stabile_alta = (t_pressione_alta_05bar_ms > 0UL && (now_ms - t_pressione_alta_05bar_ms) >= 5000UL);
        const bool cond = (!is_olio &&
                           stato_pompa && flusso_lmin >= PORTATA_MIN_CIRC_LMIN &&
                           temp_serbatoio > 90.0f &&
                           pressione_stabile_alta &&
                           pressione_locale_bar > 0.3f &&
                           pressione_locale_bar < PRESSURE_LOW_CAVITATION_BAR);
        if (cond) {
            if (t_cav_ms == 0UL) t_cav_ms = now_ms;
            if (!alarm_cavitation && (now_ms - t_cav_ms >= CAVITATION_DEBOUNCE_MS)) {
                alarm_cavitation = true;
                Serial.printf("ALLARME [CAVITAZIONE] T serb %.1f°C, P %.2f bar < %.2f bar\n",
                               temp_serbatoio, pressione_locale_bar, PRESSURE_LOW_CAVITATION_BAR);
            }
        } else {
            // Isteresi numerica per stabilizzazione allarme
            static constexpr float CAVITATION_HYST_BAR = 0.15f;
            if (pressione_locale_bar > (PRESSURE_LOW_CAVITATION_BAR + CAVITATION_HYST_BAR)) {
                t_cav_ms = 0UL;
                if (alarm_cavitation) {
                    alarm_cavitation = false;
                    Serial.println(F("RIPRISTINO [CAVITAZIONE] Condizioni normalizzate (isteresi)"));
                }
            }
        }
    }

    // ── 0x80 SONDA FUORI SEDE ──────────────────────────────────────
    {
        const bool drift_attivo = fault_sensor_drift_active;
        const bool cond = (!drift_attivo &&
                           frac_caldo >= 0.80f &&
                           t_mandata_locale > temp_sonda_mandata + 5.0f);
        if (cond) {
            if (t_sond_ms == 0UL) t_sond_ms = now_ms;
            if (!alarm_sensor_dislodged && (now_ms - t_sond_ms >= SENSOR_DISLODGED_DEBOUNCE_MS)) {
                alarm_sensor_dislodged = true;
                Serial.printf("ALLARME [SONDA] Lettura sonda %.1f°C vs T reale %.1f°C con riscaldo al massimo\n",
                               temp_sonda_mandata, t_mandata_locale);
            }
        } else {
            t_sond_ms = 0UL;
            if (alarm_sensor_dislodged) {
                alarm_sensor_dislodged = false;
                Serial.println(F("RIPRISTINO [SONDA] Lettura sonda coerente"));
            }
        }
    }

    // ── 0x100 SURRISCALDO RESISTENZA ───────────────────────────────
    static constexpr unsigned long OVERHEAT_DEBOUNCE_MS = 2000UL;

    const bool cond_on_metallo  = (temp_metallo >= TEMP_RES_OVERHEAT_C);
    const bool cond_on_core     = (temp_resistenza >= TEMP_RES_CORE_OVERHEAT_C);
    const bool cond_on          = cond_on_metallo || cond_on_core;
    const bool cond_off         = (temp_metallo < TEMP_RES_OVERHEAT_HYST_C) && (temp_resistenza < (TEMP_RES_CORE_OVERHEAT_C - 10.0f));

    if (cond_on) {
        if (t_overheat_ms == 0UL) t_overheat_ms = now_ms;
        if (!alarm_overheat_res && (now_ms - t_overheat_ms >= OVERHEAT_DEBOUNCE_MS)) {
            alarm_overheat_res = true;
            if (cond_on_core) {
                Serial.printf("ALLARME [SOVRAT. RES. CORE] Temp resistenza %.1f°C >= soglia %.0f°C - RISCALDO FORZATO OFF\n",
                              temp_resistenza, TEMP_RES_CORE_OVERHEAT_C);
            } else {
                Serial.printf("ALLARME [SOVRAT. RES.] Temp metallo %.1f°C >= soglia %.0f°C - RISCALDO FORZATO OFF\n",
                              temp_metallo, TEMP_RES_OVERHEAT_C);
            }
            adc_filtrato = 0.0f;
        }
    } else if (cond_off) {
        t_overheat_ms = 0UL;
        if (alarm_overheat_res) {
            alarm_overheat_res = false;
            Serial.printf("RIPRISTINO [SOVRAT. RES.] Temp metallo %.1f°C, resistenza %.1f°C\n",
                          temp_metallo, temp_resistenza);
        }
    }

    // ── 0x2000 CORTO PARZIALE RESISTENZA ────────────────────────────
    {
        static constexpr unsigned long HEATER_SHORT_DEBOUNCE_MS = 500UL;
        if (fault_heater_short_active) {
            if (t_heater_short_ms == 0UL) t_heater_short_ms = now_ms;
            if (!alarm_heater_short && (now_ms - t_heater_short_ms >= HEATER_SHORT_DEBOUNCE_MS)) {
                alarm_heater_short = true;
                Serial.println(F("ALLARME [CORTO RES.] Corto parziale resistenza rilevato - potenza/scambio anomali"));
            }
        } else {
            t_heater_short_ms = 0UL;
            if (alarm_heater_short) {
                alarm_heater_short = false;
                Serial.println(F("RIPRISTINO [CORTO RES.] Corto parziale resistenza rientrato"));
            }
        }
    }

    // ── 0x200 ALTA PRESSIONE ────────────────────────────────────────
    {
        float soglia_alta_pressione = PRESSURE_HIGH_ALARM_BAR;
        if (p_pressione_bar > 0.0f) {
            soglia_alta_pressione = min(PRESSURE_HIGH_ALARM_BAR, p_pressione_bar * 1.2f);
        }
        constexpr float PRESSURE_HIGH_HYST_BAR = 3.20f;
        float soglia_off = clampFloat(min(PRESSURE_HIGH_HYST_BAR, soglia_alta_pressione - 0.3f), 0.05f, soglia_alta_pressione - 0.05f);
        const bool cond_on = (!is_olio && pressione_locale_bar >= soglia_alta_pressione);
        const bool cond_off = (!is_olio && pressione_locale_bar < soglia_off);
        if (cond_on) {
            if (t_press_ms == 0UL) t_press_ms = now_ms;
            if (!alarm_alta_pressione && (now_ms - t_press_ms >= 3000UL)) {
                alarm_alta_pressione = true;
                Serial.printf("ALLARME [ALTA PRESSIONE] P %.2f bar >= soglia %.1f bar\n",
                               pressione_locale_bar, soglia_alta_pressione);
            }
        } else if (cond_off) {
            t_press_ms = 0UL;
            if (alarm_alta_pressione) {
                alarm_alta_pressione = false;
                Serial.printf("RIPRISTINO [ALTA PRESSIONE] P %.2f bar\n", pressione_locale_bar);
            }
        }
    }

    // ── 0x400 ARIA NEL CIRCUITO ─────────────────────────────────────
    {
        if (fault_air_in_circuit != alarm_aria_circuito) {
            alarm_aria_circuito = fault_air_in_circuit;
            if (alarm_aria_circuito)
                Serial.println(F("ALLARME [ARIA] Sacca d'aria nel circuito - portata/scambio ridotti, valvola aperta"));
            else
                Serial.println(F("RIPRISTINO [ARIA] Circuito idraulico normalizzato"));
        }
    }

    // ── 0x800 PERDITA D'ACQUA ───────────────────────────────────────
    {
        if (fault_air_in_circuit && t_aria_attivazione_ms == 0UL) {
            t_aria_attivazione_ms = now_ms;
        }
        if (!fault_air_in_circuit) {
            t_aria_attivazione_ms = 0UL;
        }
        const bool perdita_da_aria_transitoria = (fault_air_in_circuit &&
                                                   t_aria_attivazione_ms > 0UL &&
                                                   (now_ms - t_aria_attivazione_ms) < 30000UL &&
                                                   p_massa_acqua < MASSA_ACQUA_NOMINALE - 0.5f);
        const bool cond = (perdita_attiva || perdita_da_aria_transitoria);
        if (cond != alarm_perdita_acqua) {
            alarm_perdita_acqua = cond;
            if (cond)
                Serial.printf("ALLARME [PERDITA] Massa acqua %.2f kg, perdita rilevata\n", p_massa_acqua);
            else
                Serial.println(F("RIPRISTINO [PERDITA] Perdita d'acqua cessata"));
        }
    }

    // ── ALLARME SETPOINT IRRAGGIUNGIBILE ────────────────────────────
    {
        const bool   cond_valv_ap = fault_valve_stuck_open && pompa_effettiva && (frac_caldo >= 0.95f);
        if (cond_valv_ap) {
            if (t_setpoint_fail_ms == 0UL) {
                t_setpoint_fail_ms = now_ms;
                t_serb_snapshot    = temp_serbatoio;
            }
            const bool stagnante = (fabsf(temp_serbatoio - t_serb_snapshot) < 1.0f);
            const bool timeout   = ((now_ms - t_setpoint_fail_ms) >= 30000UL);
            if (!warning_setpoint_fail_prev && stagnante && timeout) {
                warning_setpoint_fail_prev = true;
                Serial.printf("ALLARME [VALVOLA APERTA] Riscaldo massimo ma T serbatoio stagnante a %.1f C - valvola HX bloccata aperta?\n",
                               temp_serbatoio);
            }
        } else {
            t_setpoint_fail_ms = 0UL;
            if (warning_setpoint_fail_prev) {
                warning_setpoint_fail_prev = false;
                Serial.println(F("RIPRISTINO [VALVOLA APERTA] Condizione setpoint irraggiungibile cessata"));
            }
        }
    }
}

// Simula ritardo di trasporto fluido tramite buffer circolare (dead-time)
// Il ritardo dipende dalla portata: più flusso = meno ritardo
static float aggiornaDeadTimeMandata(float t_sorgente, float flusso_lmin, float dt_s) {
    if (dt_s <= 0.0f || flusso_lmin <= 0.0f) return deadtime_last_out;

    deadtime_accum_s += dt_s;

    float delay_s = DEADTIME_S * (PORTATA_NOMINALE_LMIN / max(flusso_lmin, 0.01f));
    delay_s = clampFloat(delay_s, CICLO_S, DEADTIME_MAX_S);

    if (deadtime_delay_s_filt < 0.0f) {
        deadtime_delay_s_filt = delay_s; // inizializzazione
    } else {
        deadtime_delay_s_filt = filtraPL(deadtime_delay_s_filt, delay_s, alphaDaTau(dt_s, 5.0f));
    }

    float delay_samples_f = deadtime_delay_s_filt / CICLO_S;
    if (delay_samples_f < 0.0f) delay_samples_f = 0.0f;
    if (delay_samples_f > (float)(DEAD_BUF_SIZE - 2)) delay_samples_f = (float)(DEAD_BUF_SIZE - 2);

    int push_count = (int)floorf(deadtime_accum_s / CICLO_S);
    if (push_count < 1 && deadtime_accum_s > 0.0f) push_count = 1;
    else if (push_count < 1) push_count = 0;
    if (push_count > DEAD_BUF_SIZE - 1) push_count = DEAD_BUF_SIZE - 1;  // Evita corruzione buffer
    deadtime_accum_s -= (float)push_count * CICLO_S;
    if (deadtime_accum_s < 0.0f) deadtime_accum_s = 0.0f;

    for (int i = 0; i < push_count; ++i) {
        dead_buffer[dead_buf_idx] = t_sorgente;
        dead_buf_idx = (dead_buf_idx + 1) % DEAD_BUF_SIZE;
    }

    if (push_count == 0) {
        return deadtime_last_out;
    }

    int   delay_samples_lo = (int)floorf(delay_samples_f);
    float frac            = delay_samples_f - (float)delay_samples_lo;
    int   delay_samples_hi = delay_samples_lo + 1;

    int read_idx_lo = (dead_buf_idx - delay_samples_lo + DEAD_BUF_SIZE * 2) % DEAD_BUF_SIZE;
    int read_idx_hi = (dead_buf_idx - delay_samples_hi + DEAD_BUF_SIZE * 2) % DEAD_BUF_SIZE;

    float v_lo = dead_buffer[read_idx_lo];
    float v_hi = dead_buffer[read_idx_hi];

    deadtime_last_out = v_lo + (v_hi - v_lo) * frac;
    return deadtime_last_out;
}

// Aggiorna stato pompa: in AUTO la pompa gira sempre finché la macchina è
// accesa (vedi sotto), in MANuale rispetta il comando dell'operatore.
//
// comando_freddo_reale: segnale hardware di richiesta freddo (raffreddamento_cmd),
// filtrato dalla sola isteresi del pin. NON è il segnale combinato con il
// latch raffreddamento_attivo: usare quest'ultimo per decidere quando spegnere
// se stesso creerebbe un ciclo che si auto-sostiene e non scadrebbe mai.
static void aggiornaStatoPompa(unsigned long now_ms, float frac_caldo, bool comando_freddo_reale) {

    // Protezione fisica assoluta: acqua insufficiente per far girare la pompa
    // in sicurezza. Nessun override possibile: è un limite fisico dell'impianto,
    // non una scelta di controllo (a differenza del dry-run qui sotto).
    if (p_massa_acqua < MASSA_SICURA_POMPA) {
        stato_pompa = false;
        return;
    }

    // Macchina spenta → pompa ferma sempre (anche in manuale AUTO)
    if (!macchina_accesa) {
        stato_pompa = false;
        return;
    }

    if (pump_mode != last_pump_mode) {
        t_ultimo_comando_auto_pompa = now_ms;
        last_pump_mode = pump_mode;
    }

    // Override manuale: rispettato solo se macchina_accesa (già verificato sopra)
    if (pump_manual_override) {
        if (pump_mode == PUMP_MODE_MANUAL_ON)  stato_pompa = true;
        if (pump_mode == PUMP_MODE_MANUAL_OFF) stato_pompa = false;
        return;
    }

    pump_mode = PUMP_MODE_AUTO;

    // AUTO: la pompa di circolazione gira finché c'è una richiesta termica
    // attiva (vedi stato_pompa più sotto). Il segnale caldo/freddo reale qui
    // serve a tenere aggiornato il timestamp dell'ultimo comando, usato sia
    // per rilasciare automaticamente il latch "raffreddamento_attivo" sia per
    // fermare la pompa quando non arriva più alcuna richiesta da tempo.
    //
    // Allarme marcia a secco (massa critica, galleggiante guasto, metallo
    // surriscaldato): il riscaldo è comunque forzato a 0 altrove (vedi
    // aggiornaFisica), quindi qui il segnale caldo viene ignorato in dry-run.
    const bool segnale_caldo  = (!alarm_dry_run) && (frac_caldo >= HEAT_ON_TH);

    // IMPORTANTE: per capire se "non arriva più alcun comando" si usano SOLO
    // i segnali reali (segnale_caldo, comando_freddo_reale = pin hardware),
    // MAI richiesta_freddo/segnale_freddo che include già il latch
    // raffreddamento_attivo. Usare il latch per decidere quando spegnere se
    // stesso crea un ciclo che si auto-alimenta all'infinito: finché il latch
    // è attivo, "segnale_freddo" risulta vero, il timestamp viene continuamente
    // aggiornato e il timeout non scade mai. Per questo motivo si usano
    // SOLO i segnali reali (segnale_caldo, comando_freddo_reale) per
    // determinare quando spegnere il latch.
    const bool comando_termico_reale = segnale_caldo || comando_freddo_reale;

    if (comando_termico_reale) {
        mantieni_temp_iniziale = false;
        t_ultimo_comando_auto_pompa = now_ms;
    } else if ((now_ms - t_ultimo_comando_auto_pompa) >= PUMP_AUTO_STOP_DELAY_MS) {
        // Nessun comando reale di caldo o freddo da PUMP_AUTO_STOP_DELAY_MS:
        // la modalità raffreddamento (se attiva tramite latch) si spegne, e la
        // pompa si ferma insieme ad essa nello stesso istante. La condizione
        // qui sopra dipende SOLO dal tempo trascorso dall'ultimo comando
        // reale, non dallo stato del latch stesso, altrimenti il timeout non
        // scadrebbe mai finché il latch resta attivo.
        if (raffreddamento_attivo) {
            raffreddamento_attivo = false;
            Serial.println(F("AUTO: modalita' raffreddamento disattivata (nessun comando caldo/freddo)"));
        }
        if (stato_pompa) {
            stato_pompa = false;
            Serial.println(F("AUTO: pompa arrestata insieme alla modalita' raffreddamento (nessun comando caldo/freddo)"));
        }
    }

    // La pompa di circolazione si accende quando c'e' un comando reale di
    // caldo/freddo, oppure quando la modalità raffreddamento è comunque
    // attiva tramite il latch software (es. comando seriale "RAFFREDDAMENTO
    // ON"/"START"), per garantire la circolazione richiesta dalla modalità
    // stessa. Si spegne solo tramite il ramo sopra, quando entrambe le
    // condizioni (comando reale e latch) sono assenti da tempo.
    if (comando_termico_reale || raffreddamento_attivo) {
        stato_pompa = true;
    }
}

// Gestisce riempimento automatico serbatoio con controllo guasti galleggiante
// Timeout sicurezza: 5 minuti max riempimento cumulativo
static void aggiornaRifornimentoAcqua(unsigned long now_ms) {
    static constexpr unsigned long MAX_TEMPO_RIEMPIMENTO_MS = 300000UL; // 5 minuti max
    
    float massa_acqua_letta_sensore = p_massa_acqua;
    
    if (fault_float_stuck_high) {
        massa_acqua_letta_sensore = MASSA_ACQUA_NOMINALE;  // Falso pieno
        if (p_massa_acqua < MASSA_CRITICA_ACQUA) {
            if (!alarm_float_failure) {
                alarm_float_failure = true;
                Serial.println(F("ALLARME [GALLEGGIANTE] Stuck-high: falso pieno con acqua reale critica - safe state"));
            }
            stato_pompa = false;
            adc_filtrato = 0.0f;
            rele_carico_acqua = true;
            digitalWrite(PIN_RELE_ACQUA, LOW);
        } else if (alarm_float_failure) {
            alarm_float_failure = false;
            Serial.println(F("RIPRISTINO [GALLEGGIANTE] Stuck-high: livello reale tornato sopra soglia critica"));
        }
    } else if (fault_float_stuck_low) {
        massa_acqua_letta_sensore = 0.0f;  // Falso vuoto
        if (!alarm_float_failure) {
            alarm_float_failure = true;
            Serial.println(F("ALLARME [GALLEGGIANTE] Stuck-low: falso vuoto rilevato"));
        }
        // blocca riempimento solo se livello reale è sufficiente (no refill inutile)
        if (p_massa_acqua > MASSA_SERBATOIO_VUOTO_OFF_KG) {
            rele_carico_acqua = false;
            digitalWrite(PIN_RELE_ACQUA, HIGH);
        } else if (alarm_float_failure) {
            alarm_float_failure = false;
            Serial.println(F("RIPRISTINO [GALLEGGIANTE] Stuck-low: livello reale tornato sotto soglia"));
        }
    } else if (fault_float_no_signal) {
        massa_acqua_letta_sensore = -1.0f;  // Nessun segnale
    }

    // Usa massa reale per il controllo valvola, non quella truccata (blind spot stuck-high)
    float massa_acqua_per_riempimento = fault_float_stuck_high ? p_massa_acqua : massa_acqua_letta_sensore;

    if (fault_float_no_signal) {
        if (!alarm_float_failure) {
            alarm_float_failure = true;
            Serial.println(F("ALLARME [GALLEGGIANTE] Segnale sensore livello assente - safe state"));
        }
        adc_filtrato = 0.0f;
        rele_carico_acqua = false;
        digitalWrite(PIN_RELE_ACQUA, HIGH);
        return;
    } else {
        // Il reset di alarm_float_failure non deve avvenire mentre fault_float_stuck_high è attivo
        // Il guasto sensore deve rimanere visibile indipendentemente dal livello reale
        bool stuck_high_critico = fault_float_stuck_high && (p_massa_acqua < MASSA_CRITICA_ACQUA);
        bool qualsiasi_guasto_float = fault_float_stuck_high || fault_float_stuck_low;
        if (alarm_float_failure && !stuck_high_critico && !qualsiasi_guasto_float) {
            alarm_float_failure = false;
            Serial.println(F("RIPRISTINO [GALLEGGIANTE] Segnale sensore livello ripristinato"));
        }
    }
    
    if (rele_carico_acqua) {
        if (t_inizio_riempimento == 0UL) {
            t_inizio_riempimento = now_ms;
        }
        t_totale_riempimento_ms = now_ms - t_inizio_riempimento;
        t_ultimo_riempimento = now_ms;
    } else {
        t_inizio_riempimento = 0UL;
        if (now_ms - t_ultimo_riempimento > 3600000UL) {
            t_totale_riempimento_ms = 0UL;
        }
    }

    if (rele_carico_acqua && t_totale_riempimento_ms > MAX_TEMPO_RIEMPIMENTO_MS) {
        rele_carico_acqua = false;
        digitalWrite(PIN_RELE_ACQUA, HIGH);
        Serial.println(F("ALLARME: Timeout riempimento acqua cumulativo - valvola chiusa per sicurezza"));
        t_inizio_riempimento = 0UL;
        t_totale_riempimento_ms = 0UL;
    }

    if (perdita_attiva) {
        rele_carico_acqua = true;
        digitalWrite(PIN_RELE_ACQUA, LOW);
        return;
    }

    if (errore_acqua && massa_acqua_letta_sensore < MASSA_ACQUA_NOMINALE) {
        rele_carico_acqua = true;
        digitalWrite(PIN_RELE_ACQUA, LOW);
    }

    if (acqua_pulse_attivo) {
        if (now_ms - t_pulse_acqua >= ACQUA_PULSE_MS) {
            acqua_pulse_attivo = false;
            if (!perdita_attiva && !alarm_serbatoio_vuoto && massa_acqua_letta_sensore >= MASSA_ACQUA_NOMINALE) {
                rele_carico_acqua = false;
                digitalWrite(PIN_RELE_ACQUA, HIGH);
                Serial.println(F("RIPRISTINO: ricarica acqua terminata"));
            }
        } else {
            rele_carico_acqua = true;
            digitalWrite(PIN_RELE_ACQUA, LOW);
        }
    }

    if (!alarm_serbatoio_vuoto && massa_acqua_per_riempimento <= MASSA_SERBATOIO_VUOTO_ON_KG) {
        alarm_serbatoio_vuoto = true;
        rele_carico_acqua = true;
        errore_acqua = true;
        digitalWrite(PIN_RELE_ACQUA, LOW);
        Serial.println(F("ALLARME: serbatoio vuoto -> riempimento attivo"));
    }

    if (alarm_serbatoio_vuoto && massa_acqua_per_riempimento >= MASSA_SERBATOIO_VUOTO_OFF_KG) {
        alarm_serbatoio_vuoto = false;
        errore_acqua = false;
        if (!perdita_attiva && !acqua_pulse_attivo && massa_acqua_per_riempimento >= MASSA_ACQUA_NOMINALE) {
            rele_carico_acqua = false;
            digitalWrite(PIN_RELE_ACQUA, HIGH);
        }
        Serial.println(F("RIPRISTINO: serbatoio riempito"));
    }

    if (!fault_air_in_circuit && errore_acqua && massa_acqua_per_riempimento >= MASSA_ACQUA_NOMINALE &&
        !perdita_attiva && !alarm_serbatoio_vuoto) {
        errore_acqua    = false;
    }

    if (!perdita_attiva && !acqua_pulse_attivo && !alarm_serbatoio_vuoto &&
        !fault_air_in_circuit &&
        massa_acqua_per_riempimento >= MASSA_ACQUA_NOMINALE) {
        errore_acqua    = false;
        rele_carico_acqua = false;
        digitalWrite(PIN_RELE_ACQUA, HIGH);
    }
}

// Aggiorna deriva sensore: +0.5°C/min quando guasto attivo, reset graduale quando disattivo
static void aggiornaFaultSensorDrift(float dt_s) {
    if (fault_sensor_drift_active) {
        fault_sensor_drift_offset_c += SENSOR_DRIFT_STEP_C_PER_MIN * (dt_s / 60.0f);
        fault_sensor_drift_offset_c = constrain(fault_sensor_drift_offset_c, -10.0f, 10.0f);
    } else {
        if (fabsf(fault_sensor_drift_offset_c) > 0.01f) {
            fault_sensor_drift_offset_c = filtraPL(fault_sensor_drift_offset_c, 0.0f,
                                                    alphaDaTau(dt_s, 30.0f));
        } else {
            fault_sensor_drift_offset_c = 0.0f;  // snap a zero
        }
    }
}

// Inizializzazione sistema: configurazione pin, SPI, stato iniziale
void setup() {
    Serial.begin(115200);
    delay(500);
    Serial.setTimeout(500);  // Timeout aumentato per USB-CDC ESP32 (chunk ~64B con latenza variabile)

#ifdef ARDUINO_ARCH_ESP32
    analogSetAttenuation(ADC_11db);
#endif

    pinMode(PIN_RAFFREDDAMENTO, INPUT_PULLUP);  // Ingresso freddo (attivo LOW)
    pinMode(CS_MANDATA, OUTPUT);                 // Chip Select sonda mandata
    pinMode(CS_RITORNO, OUTPUT);                // Chip Select sonda ritorno
    pinMode(PIN_RELE_ACQUA, OUTPUT);             // Relè valvola riempimento
    pinMode(PIN_ELETTROVALVOLA_HX, OUTPUT);      // Elettrovalvola scambiatore

    if (pinValido(FAULT_BTN_1_LOCAL)) pinMode(FAULT_BTN_1_LOCAL, INPUT_PULLUP);
    if (pinValido(FAULT_BTN_2_LOCAL)) pinMode(FAULT_BTN_2_LOCAL, INPUT_PULLUP);
    if (pinValido(FAULT_BTN_3_LOCAL)) pinMode(FAULT_BTN_3_LOCAL, INPUT_PULLUP);
    if (pinValido(FAULT_BTN_4_LOCAL)) pinMode(FAULT_BTN_4_LOCAL, INPUT_PULLUP);
    if (pinValido(FAULT_BTN_5_LOCAL)) pinMode(FAULT_BTN_5_LOCAL, INPUT_PULLUP);

    digitalWrite(CS_MANDATA, HIGH);
    digitalWrite(CS_RITORNO, HIGH);
    digitalWrite(PIN_RELE_ACQUA, HIGH);
    digitalWrite(PIN_ELETTROVALVOLA_HX, HIGH);  // Elettrovalvola HX spenta (attivo LOW)

    SPI.begin();

    resetStatoTermico();
    salvaProfilo(0);
    salvaProfilo(1);
    salvaProfilo(2);
    t_last = millis();
    ramp_display_accum_ms = 0.0f;  // riferimento per la rampa automatica sonde (solo display)
    t_log  = t_last;
    t_ultimo_comando_auto_pompa = t_last;

    Serial.println("READY");
    delay(800);  // dai tempo al PC di aprire la porta seriale
}

// Ciclo principale: eseguito ogni CICLO_MS (100ms) - modello fisico termodinamico
static void aggiornaFisica(unsigned long now, float dt_s);  // forward declaration

void loop() {
    gestisciSerial();

    unsigned long now = millis();
    gestisciFaultButtons(now);

    // Controllo temporizzazione: esegue il ciclo solo ogni CICLO_MS
    if (now - t_last < CICLO_MS) {
        return;
    }
    float dt_s = tempoDtSecondi(now, t_last);
    t_last = now;

    // Se dt_s == 0 (anomalia timer), salta l'aggiornamento fisico
    if (dt_s <= 0.0f) return;

    aggiornaFisica(now, dt_s);
}

// ══════════════════════════════════════════════════════════════════
//  MODELLO FISICO TERMODINAMICO - AGGIORNAMENTO PASSO
// ══════════════════════════════════════════════════════════════════
// Questa funzione implementa il cuore del simulatore: calcola l'evoluzione
// del sistema termico passo per passo (dt_s secondi) integrando i bilanci
// energetici di tutti i componenti: resistenza, serbatoio, tubazioni, stampo,
// scambiatore di calore, elettrovalvola, pompa.
//
// Parametri:
//   - now: timestamp corrente [ms]
//   - dt_s: delta tempo in secondi dal ciclo precedente
//
// Operazioni principali:
//   1. Lettura segnali hardware (pin raffreddamento, ADC calore)
//   2. Calcolo portata con inerzia idraulica e fattori di guasto
//   3. Bilancio energetico resistenza → metallo → acqua
//   4. Scambio termico con stampo e ambiente
//   5. Controllo elettrovalvola scambiatore
//   6. Simulazione dead-time trasporto fluido
//   7. Aggiornamento sonde PT1000 con calibrazione SPI
//   8. Verifica allarmi di sicurezza
//   9. Emissione telemetria JSON
static void aggiornaFisica(unsigned long now, float dt_s) {
    const bool raw_raffreddamento_pin = (digitalRead(PIN_RAFFREDDAMENTO) == LOW);
    
    // Sistema con isteresi: mantiene il segnale attivo per RAFFREDDAMENTO_HOLD_MS dopo che il pin torna HIGH
    if (raw_raffreddamento_pin) {
        // Pin LOW: aggiorna timestamp ultima attivazione
        t_last_cooling_active_ms = now;
        cooling_pin_filtered = true;
    } else {
        // Pin HIGH: spegni solo dopo RAFFREDDAMENTO_HOLD_MS dall'ultima attivazione.
        // Nota: il rilascio del latch software "raffreddamento_attivo" NON viene
        // fatto qui, ma centralizzato in aggiornaStatoPompa() insieme allo
        // spegnimento sincronizzato della pompa (vedi commento lì per il motivo:
        // farlo anche qui, basandosi su t_last_cooling_active_ms che parte da 0
        // se il pin non è mai stato attivo, spegnerebbe il latch quasi subito
        // anche quando attivato via comando seriale senza pin fisico collegato).
        if ((now - t_last_cooling_active_ms) >= RAFFREDDAMENTO_HOLD_MS) {
            cooling_pin_filtered = false;
        }
        // Se non è passato il tempo, mantieni lo stato precedente (isteresi)
    }

    raffreddamento_cmd = cooling_pin_filtered;

    // Controllo elettrovalvola scambiatore: attiva quando la richiesta di raffreddamento è effettiva
    // Il debouncing evita chatter hardware e impedisce oscillazioni del sistema quando il pin salta.
    const bool richiesta_freddo_attiva = raffreddamento_cmd || raffreddamento_attivo;
    digitalWrite(PIN_ELETTROVALVOLA_HX, richiesta_freddo_attiva ? LOW : HIGH);

    double usura_pompa = constrain(((double)ore_pompa_s / 3600000.0) * PUMP_WEAR_PER_HOUR, 0.0, 0.25);
    float eff_pompa = clampFloat(p_efficienza_pompa - (float)usura_pompa, 0.30f, 1.0f);

    float ostruzione_effettiva = coefficienteOstruzioneEffettivo(p_ostruzione_circuito, fault_clogging_active);

    // Calcolo portata con inerzia idraulica (tau variabile in base a stato pompa/fluido)
    float portata_target;
    if (stato_pompa) {
        portata_target = portataDinamicaLMin(p_portata_base_cmd, temp_serbatoio, ostruzione_effettiva);
        if (fault_air_in_circuit) portata_target *= AIR_PORTATA_FACTOR;
        portata_target *= eff_pompa;
        portata_target = max(portata_target, 0.0f);
    } else {
        portata_target = 0.0f;   // pompa spenta → portata obiettivo zero
    }
    {
        // Filtro portata con tau adattivo (olio: inerzia maggiore, portata ridotta)
        float tau_portata;
        if (stato_pompa) {
            tau_portata = is_olio ? 14.0f : 5.0f;  // olio: salita lenta per alta viscosità
        } else if (pressione_effettiva_bar > 0.1f) {
            tau_portata = is_olio ? 18.0f : 8.0f;  // olio: rallentamento più lento
        } else {
            tau_portata = is_olio ?  8.0f : 3.0f;  // olio: fermata più lenta
        }
        // Fattore viscosità olio: 0.55 a 20°C → 1.0 a 120°C (fluidifica con T)
        float portata_target_fluido = portata_target;
        if (is_olio) {
            float t_rif = clampFloat(temp_serbatoio, 20.0f, 120.0f);
            float visc_factor = 0.55f + 0.45f * ((t_rif - 20.0f) / 100.0f); // 0.55 a 20°C → 1.0 a 120°C
            portata_target_fluido *= visc_factor;
        }
        p_portata_filtrata_global = filtraPL(p_portata_filtrata_global, portata_target_fluido, alphaDaTau(dt_s, tau_portata));
        p_portata = max(p_portata_filtrata_global, 0.0f);
    }
    float flusso_lmin = p_portata;
    float portata_kgs  = portataMassicaDaLMin(flusso_lmin);

    if (is_olio) {
        pressione_effettiva_bar = 0.0f;
    } else {
        static constexpr float P_BASE_VASO_APERTO_BAR = 0.6f;
        if (p_pressione_bar <= 0.0f) {
            pressione_effettiva_bar = stato_pompa ? P_BASE_VASO_APERTO_BAR : 0.0f;
        } else {
            // ── Curva pompa H(Q): pressione sale quando portata scende (ostruzione) ──
            // H_pompa = H0 * (1 - k_q * (Q/Q_nom)^2)
            static constexpr float K_Q_PUMP = 0.40f;  // Coefficiente curva pompa (adimensionale)
            float q_ratio = clampFloat(flusso_lmin / PORTATA_NOMINALE_LMIN, 0.0f, 2.0f);
            // Pressione curva pompa + perdite distribuite + effetto aria + ostruzione
            float p_curva_pompa = stato_pompa
                ? p_pressione_bar * (1.0f + K_Q_PUMP * (1.0f - q_ratio * q_ratio))
                : p_pressione_bar;
            float dp_flow = 0.02f * q_ratio * q_ratio;  // Perdite tubazioni (crescono con Q^2)
            float dp_aria = fault_air_in_circuit ? AIR_DP_BAR : 0.0f;  // Calo pressione da aria
            float dp_ostruzione = 0.3f * ostruzione_effettiva;  // Sovrapressione da ostruzione circuito
            pressione_effettiva_bar = max(p_curva_pompa - dp_flow - dp_aria + dp_ostruzione, 0.0f);
            pressione_effettiva_bar = clampFloat(pressione_effettiva_bar, 0.0f, 5.0f);
        }
    }
    t_ebollizione = is_olio ? 300.0f
                  : (pressione_effettiva_bar <= 0.0f) ? 100.0f
                  : temperaturaEbollizioneDaPressioneBar(pressione_effettiva_bar);
    if (!is_olio && temp_serbatoio > t_ebollizione) {
        temp_serbatoio = t_ebollizione;
    }

    float Q_iniezione = 0.0f;
    // In modalità olio circuito chiuso: Q_iniezione solo per acqua
    if (!is_olio) {
        if (perdita_attiva) {
            float portata_perdita_kgs = PORTATA_PERDITA_LMIN / 60.0f;
            p_massa_acqua -= portata_perdita_kgs * dt_s;
            if (p_massa_acqua < 0.0f) p_massa_acqua = 0.0f;
            if (rele_carico_acqua) {
                float portata_fill_kgs = constrain(p_portata_valvola, 0.0f, PORTATA_VALVOLA_MAX_LMIN) / 60.0f;
                Q_iniezione = portata_fill_kgs * cp_fluido * (p_temp_rete - temp_serbatoio);
                p_massa_acqua += portata_fill_kgs * dt_s;
                if (p_massa_acqua > MASSA_ACQUA_NOMINALE) p_massa_acqua = MASSA_ACQUA_NOMINALE;
            }
        } else if (fault_air_in_circuit && rele_carico_acqua) {
            float portata_fill_kgs = constrain(p_portata_valvola, 0.0f, PORTATA_VALVOLA_MAX_LMIN) / 60.0f;
            float portata_perdita_aria_kgs = (PORTATA_PERDITA_LMIN * 0.4f) / 60.0f;
            Q_iniezione = portata_fill_kgs * cp_fluido * (p_temp_rete - temp_serbatoio);
            p_massa_acqua += (portata_fill_kgs - portata_perdita_aria_kgs) * dt_s;
            if (p_massa_acqua > MASSA_ACQUA_NOMINALE) p_massa_acqua = MASSA_ACQUA_NOMINALE;
        } else if (rele_carico_acqua) {
            float portata_fill_kgs = constrain(p_portata_valvola, 0.0f, PORTATA_VALVOLA_MAX_LMIN) / 60.0f;
            Q_iniezione = portata_fill_kgs * cp_fluido * (p_temp_rete - temp_serbatoio);
            p_massa_acqua += portata_fill_kgs * dt_s;
            if (p_massa_acqua > MASSA_ACQUA_NOMINALE) p_massa_acqua = MASSA_ACQUA_NOMINALE;
        }
    }

    float frac_caldo_raw = leggiComandoRiscaldo();
    bool richiesta_freddo = raffreddamento_cmd || raffreddamento_attivo;

    // ── Isteresi minima sulla richiesta freddo ──
    // Senza questo filtro, una richiesta_freddo che sfarfalla (pin rumoroso o
    // termostato esterno on/off) fa aprire/chiudere la valvola HX quasi
    // istantaneamente (HX_VALVE_TAU_OPEN_S = 0.10s), causando un ciclo
    // continuo temperatura-giu/scattino-su/giu finché la richiesta resta attiva.
    // Si impone quindi un tempo minimo di permanenza in ON e in OFF, sullo
    // stesso principio già usato per il periodo di grazia della pompa.
    if (richiesta_freddo != richiesta_freddo_stabile) {
        unsigned long min_dwell_ms = richiesta_freddo ? HX_MIN_OFF_DWELL_MS : HX_MIN_ON_DWELL_MS;
        if (t_ultimo_cambio_freddo_ms == 0UL) t_ultimo_cambio_freddo_ms = now;
        if ((now - t_ultimo_cambio_freddo_ms) >= min_dwell_ms) {
            richiesta_freddo_stabile = richiesta_freddo;
            t_ultimo_cambio_freddo_ms = now;
        }
    } else {
        t_ultimo_cambio_freddo_ms = now;
    }
    richiesta_freddo = richiesta_freddo_stabile;

    // Aggiorna stato pompa PRIMA di calcolare ore_pompa_s e circuito_idraulico_attivo
    aggiornaStatoPompa(now, frac_caldo_raw, raffreddamento_cmd);

    ore_pompa_s      += (stato_pompa ? (unsigned long long)lroundf(dt_s * 1000.0f) : 0ULL);

    // Pre-check surriscaldo per evitare tick extra nel contatore ore
    const bool resistenza_effettivamente_attiva = (frac_caldo_raw > 0.0f)
        && !(alarm_boiling || alarm_dry_run || alarm_overheat_res)
        && (temp_metallo < TEMP_RES_OVERHEAT_C);
    ore_hx_s         += (richiesta_freddo ? (unsigned long long)lroundf(dt_s * 1000.0f) : 0ULL);

    // Pre-check dry-run: evita 1 ciclo senza protezione (12kW + pompa ferma + secco)
    // Logica di attivazione Dry-Run ridondante con interblocco incrociato
    if ((p_massa_acqua < MASSA_CRITICA_ACQUA && !fault_float_stuck_high) ||
        alarm_float_failure ||
        (temp_metallo > TEMP_RES_OVERHEAT_C)) {
        alarm_dry_run = true;  // Sicurezza garantita anche con galleggiante bloccato alto
    }

    bool circuito_idraulico_attivo = (stato_pompa && flusso_lmin > 0.0f && !alarm_serbatoio_vuoto && p_massa_acqua > 0.0f);

    // Feedforward per compensazione carico termico stampo
    float Q_ff = -ff_gain * p_pot_stampo * (p_portata / PORTATA_NOMINALE_LMIN);
    float frac_caldo;
    if (p_pot_risc > 0.0f) {
        float potenza_risc_sicura = p_pot_risc;
        frac_caldo = constrain(frac_caldo_raw + Q_ff / potenza_risc_sicura, 0.0f, 1.0f);
    } else {
        frac_caldo = constrain(frac_caldo_raw, 0.0f, 1.0f);
    }
    if (richiesta_freddo) frac_caldo = 0.0f;

    // Safety: forza off riscaldamento in condizioni di allarme
    if (alarm_boiling || alarm_dry_run || alarm_overheat_res || !macchina_accesa) {
        frac_caldo = 0.0f;
    }

    // Guasti resistenza: fase bruciata riduce potenza, corto aumenta potenza
    float fattore_riscaldo = fault_heater_failure_active ? 0.67f : 1.0f;
    float k_scambio_res_eff = fault_heater_failure_active
                              ? K_SCAMBIO_RES * 0.72f
                              : K_SCAMBIO_RES;
    float potenza_risc_nominale = p_pot_risc;
    if (fault_heater_short_active) {
        potenza_risc_nominale *= 1.15f;
        k_scambio_res_eff *= 0.80f;
    }
    float Q_in_elettrico = potenzaRiscaldo(frac_caldo * fattore_riscaldo, potenza_risc_nominale);

    // Aggiorna ore funzionamento resistenza proporzionalmente alla potenza effettiva
    if (resistenza_effettivamente_attiva && p_pot_risc > 0.0f) {
        float fattore_potenza_res = constrain(Q_in_elettrico / potenza_risc_nominale, 0.0f, 1.0f);
        ore_resistenza_s += (unsigned long long)lroundf(dt_s * 1000.0f * fattore_potenza_res);
    }

    // Bilancio termico resistenza → metallo → acqua
    float C_res = MASSA_RES_KG * CP_ACCIAIO;
    float C_metallo = MASSA_METALLO_SERBATOIO_KG * CP_ACCIAIO;
    float Q_res_to_metallo    = k_scambio_res_eff * (temp_resistenza - temp_metallo);
    float Q_metallo_to_acqua  = K_METALLO_ACQUA   * (temp_metallo   - temp_serbatoio);

    // Perdite resistenza a secco (proporzionali alla massa acqua mancante)
    float fattore_disp = fault_insulation_loss_active ? 10.0f : 1.0f;
    float Q_loss_dry = 0.0f;
    {
        const float massa_bagnata_max = MASSA_CRITICA_ACQUA * 2.0f;
        float fattore_secco = 0.0f;
        if (p_massa_acqua <= 0.0f) {
            fattore_secco = 1.0f;
        } else if (p_massa_acqua < massa_bagnata_max) {
            fattore_secco = 1.0f - (p_massa_acqua / massa_bagnata_max);
        }
        if (fattore_secco > 0.0f) {
            Q_loss_dry = fattore_disp * K_RES_DRY * fattore_secco * max(temp_resistenza - p_temp_ambiente, 0.0f);
        }
    }

    float temp_resistenza_target = temp_resistenza + ((Q_in_elettrico - Q_res_to_metallo - Q_loss_dry) / capacitaSicura(C_res)) * dt_s;
    // Rate limiter per temp_resistenza: limita ΔT per ciclo per dinamica realistica
    float dt_res = temp_resistenza_target - temp_resistenza;
    dt_res = constrain(dt_res, -TEMP_RES_MAX_DT_PER_CYCLE_C, TEMP_RES_MAX_DT_PER_CYCLE_C);
    temp_resistenza += dt_res;
    temp_metallo    += ((Q_res_to_metallo - Q_metallo_to_acqua - fattore_disp * 0.35f * p_k_disp_serbatoio * (temp_metallo - p_temp_ambiente)) / capacitaSicura(C_metallo)) * dt_s;
    temp_resistenza = clampTempDiag(temp_resistenza);
    temp_metallo = clampTempDiag(temp_metallo);

    temp_nucleo_res = filtraPL(temp_nucleo_res, temp_metallo, alphaDaTau(dt_s, 0.8f));
    temp_resistenza_filtrata = filtraPL(temp_resistenza_filtrata, temp_resistenza, alphaDaTau(dt_s, 1.5f));

    // Controllo valvola HX con dinamica (apertura rapida, chiusura più lenta)
    float target_apertura = richiesta_freddo ? 1.0f : 0.0f;
    if (fault_valve_stuck_closed) target_apertura = 0.0f;
    else if (fault_valve_stuck_open) target_apertura = 1.0f;
    const float tau_hx = richiesta_freddo ? HX_VALVE_TAU_OPEN_S : HX_VALVE_TAU_CLOSE_S;
    apertura_valvola_hx = filtraPL(apertura_valvola_hx, target_apertura, alphaDaTau(dt_s, tau_hx));

    // Scambiatore termico (raffreddamento passivo via rete) - attivo solo su richiesta
    float Q_scambiatore = 0.0f;
    float Q_raffreddamento = 0.0f;
    float C_serbatoio = massaTermicaSerbatoioEffettiva(p_massa_acqua) * cp_fluido;
    // IMPORTANTE: il gate va sulla posizione REALE e filtrata della valvola
    // (apertura_valvola_hx), non sul comando istantaneo richiesta_freddo.
    // Usare richiesta_freddo qui creerebbe un salto discontinuo nella potenza
    // di scambio nel preciso istante in cui il comando cessa, anche se la
    // valvola è ancora fisicamente aperta e si sta chiudendo con la sua
    // costante di tempo HX_VALVE_TAU_CLOSE_S: la discesa/risalita della
    // temperatura deve seguire l'apertura reale, quindi risultare continua
    // (nessun "saltello"), e non un gradino legato al solo comando.
    bool hx_attivo = circuito_idraulico_attivo && (apertura_valvola_hx > 0.01f || fault_valve_stuck_open);
    if (hx_attivo) {
        const float flow_factor = clampFloat(p_portata / max(PORTATA_NOMINALE_LMIN, 1.0f), HX_FLOW_FACTOR_MIN, 1.0f);
        const float conductance_fraction = is_olio ? HX_CONDUCTANCE_FRACTION_OIL : HX_CONDUCTANCE_FRACTION_WATER;
        float k_hx_effettivo = p_k_hx * conductance_fraction * flow_factor * (fault_scaling_active ? 0.50f : 1.0f) * apertura_valvola_hx;
        if (fault_air_in_circuit) {
            k_hx_effettivo *= AIR_KHX_FACTOR;
        }
        // Calcola potenza HX solo se valvola è significativamente aperta (> 1%)
        // Limite realistico: lo scambiatore non può abbattere il serbatoio più velocemente
        // di quanto consentito dalla capacità termica del circuito e dal tempo di risposta.
        const float max_cooling_rate_c_per_s = is_olio ? HX_COOL_RATE_OIL_C_PER_S : HX_COOL_RATE_WATER_C_PER_S;
        const float max_cooling_power_w = capacitaSicura(C_serbatoio) * max_cooling_rate_c_per_s;
        // Limite potenza nominale unità raffreddamento
        const float max_cooling_power_w_limited = min(max_cooling_power_w, p_pot_raffreddamento);

        if (apertura_valvola_hx > 0.01f) {
            Q_scambiatore = potenzaScambiatore(true, temp_serbatoio, p_temp_rete, k_hx_effettivo, p_portata);
            Q_scambiatore = -Q_scambiatore;  // HX rimuove calore (potenza negativa)
            if (fabsf(Q_scambiatore) > max_cooling_power_w_limited) {
                Q_scambiatore = copysignf(max_cooling_power_w_limited, Q_scambiatore);
            }
        }
        // Q_raffreddamento solo per display/telemetria (non entra nel bilancio energetico).
        // Scalato anch'esso per apertura_valvola_hx: altrimenti mostrerebbe la piena
        // potenza nominale anche a valvola quasi chiusa, con un salto appena
        // superata la soglia dell'1%, invece di seguire la stessa rampa continua
        // usata per lo scambio termico reale.
        // NOTA: applicato lo stesso cap fisico max_cooling_power_w_limited per coerenza
        // tra telemetria e bilancio energetico reale (evita mismatch fino a 9x).
        float Q_fisico = potenzaRaffreddamento(true, temp_serbatoio, p_temp_rete, portata_kgs, cp_fluido) * apertura_valvola_hx;
        if (fault_air_in_circuit) {
            Q_fisico *= AIR_KHX_FACTOR;
        }
        Q_raffreddamento = -min(Q_fisico, max_cooling_power_w_limited);
    }

    // Temperatura mandata: dead-time se pompa attiva, stasi verso serbatoio se ferma
    if (circuito_idraulico_attivo) {
        t_mandata_reale = aggiornaDeadTimeMandata(temp_serbatoio, flusso_lmin, dt_s);
        t_mandata_stasi = t_mandata_reale;
    } else {
        float target_stasi = mantieni_temp_iniziale ? t_mandata_stasi : temp_serbatoio;
        float tau_stasi_mand = STASI_TAU_S * 3.0f;
        t_mandata_stasi = filtraPL(t_mandata_stasi, target_stasi, alphaDaTau(dt_s, tau_stasi_mand));
        t_mandata_reale = t_mandata_stasi;
    }

    // Temperatura tubazioni: media serbatoio/mandata se attivo, ambiente se fermo
    float target_tubi = circuito_idraulico_attivo ? 0.5f * (temp_serbatoio + t_mandata_reale) : (mantieni_temp_iniziale ? temp_tubi : p_temp_ambiente);
    float tau_tubi = 4.0f + 1.6f * max(p_massa_tubi, 0.1f);
    if (!circuito_idraulico_attivo) tau_tubi += 6.0f;
    if (fault_air_in_circuit) tau_tubi = max(tau_tubi, AIR_TAU_TUBI_MIN_S);
    temp_tubi = filtraPL(temp_tubi, target_tubi, alphaDaTau(dt_s, tau_tubi));

    // Scambio termico con stampo (dipende da portata, non dal carico)
    float Q_conv = 0.0f;
    if (circuito_idraulico_attivo) {
        float K_stampo_effettivo = K_stampo * powf(max(p_portata / PORTATA_NOMINALE_LMIN, 0.01f), 0.8f);
        Q_conv = K_stampo_effettivo * (t_mandata_reale - temp_stampo);
        float Q_conv_lim = portata_kgs * cp_fluido * fabsf(t_mandata_reale - temp_stampo);
        Q_conv = clampFloat(Q_conv, -Q_conv_lim, Q_conv_lim);
    }

    float fattore_disp_stampo = fault_insulation_loss_active ? 10.0f : 1.0f;
    float Q_disp_stampo = fattore_disp_stampo * 4.0f * (temp_stampo - p_temp_ambiente);
    float Q_netto_stampo = Q_conv + (circuito_idraulico_attivo ? p_pot_stampo : 0.0f) - Q_disp_stampo;
    float C_stampo = capacitaSicura(p_massa_stampo * CP_ACCIAIO);
    temp_stampo += (Q_netto_stampo / C_stampo) * dt_s;

    // Temperatura ritorno: mandata - deltaT(stampo) - deltaT(tubi_ritorno)
    if (circuito_idraulico_attivo) {
        float denom = portata_kgs * cp_fluido;
        float deltaT_ritorno;
        if (denom < 1e-6f) {
            deltaT_ritorno = 0.0f;
        } else {
            deltaT_ritorno = Q_conv / denom;
        }
        // Dispersione tubazioni lato ritorno (50% del totale, assunzione simmetrica)
        float Q_disp_tubi_ritorno = 0.5f * (p_k_disp_tubi * (temp_tubi - p_temp_ambiente)) * fattore_disp;
        float deltaT_tubi_ritorno = (denom > 1e-6f) ? (Q_disp_tubi_ritorno / denom) : 0.0f;
        deltaT_ritorno += deltaT_tubi_ritorno;

        t_ritorno_reale = t_mandata_reale - deltaT_ritorno;
        t_ritorno_reale = clampFloat(t_ritorno_reale, 0.0f, max(0.0f, temp_serbatoio));
        t_ritorno_stasi = t_ritorno_reale;
    } else {
        // A pompa ferma: equilibra con serbatoio (non ambiente) per stabilità calibrazione
        float target_stasi_rit = mantieni_temp_iniziale ? t_ritorno_stasi : temp_serbatoio;
        float tau_stasi_rit = STASI_TAU_S;
        t_ritorno_stasi = filtraPL(t_ritorno_stasi, target_stasi_rit, alphaDaTau(dt_s, tau_stasi_rit));
        t_ritorno_reale = t_ritorno_stasi;
    }

    float Q_proc = 0.0f;
    if (circuito_idraulico_attivo) {
        Q_proc = portata_kgs * cp_fluido * (t_ritorno_reale - temp_serbatoio);
    }
    // Dispersioni tubazioni nel bilancio finale (50% mandata se attivo, 40% se fermo)
    float Q_disp_tubi = circuito_idraulico_attivo
                      ? (0.50f * p_k_disp_tubi * fattore_disp * (temp_tubi - p_temp_ambiente))
                      : (0.40f * p_k_disp_tubi * fattore_disp * (temp_tubi - p_temp_ambiente));

    float C_serbatoio_pompa = C_serbatoio;
    float Q_pompa = circuito_idraulico_attivo
                  ? (C_serbatoio_pompa * (p_dt_pompa / 3600.0f) * (1.0f - eff_pompa))
                  : 0.0f;
    // Limite fisico: pompa non può aggiungere più di 0.5x capacità termica al secondo
    Q_pompa = min(Q_pompa, C_serbatoio_pompa * 0.5f);

    last_q_scambiatore      = Q_scambiatore;
    last_q_raffreddamento   = Q_raffreddamento;
    last_q_iniezione        = Q_iniezione;
    last_q_conv             = Q_conv;
    last_q_proc             = Q_proc;
    last_q_pompa            = Q_pompa;
    last_q_out              = -Q_scambiatore;

    // Dispersione passiva serbatoio → ambiente (legge di Newton)
    float delta_serb = temp_serbatoio - p_temp_ambiente;
    float k_disp_serb = max(p_k_disp_serbatoio, 1.0f) * fattore_disp;
    float Q_disp_serb = k_disp_serb * delta_serb;
    
    // ══════════════════════════════════════════════════════════════════
    //  BILANCIO ENERGETICO SERBATOIO
    // ══════════════════════════════════════════════════════════════════
    // Il serbatoio riceve calore dal metallo della resistenza, dal processo
    // (ritorno fluido), dall'iniezione acqua fredda, e dalla pompa (apporto
    // termico per inefficienza). Perde calore tramite scambiatore (raffreddamento
    // passivo), dispersioni verso ambiente, e perdite a secco della resistenza.
    //
    // Equazione: dT/dt = (Q_in - Q_out) / C_termica
    // dove C_termica = massa_acqua * cp_fluido
    //
    // Bilancio netto: entra da metallo resistenza, processo (ritorno), iniezione
    // acqua fredda e pompa; esce verso scambiatore (Q_scambiatore già negativo
    // quando raffredda) e dispersioni verso ambiente (tubazioni + serbatoio).
    float pot_netta = Q_metallo_to_acqua + Q_proc + Q_iniezione + Q_pompa
                     + Q_scambiatore - Q_disp_tubi - Q_disp_serb;
    temp_serbatoio += (pot_netta / capacitaSicura(C_serbatoio)) * dt_s;

    aggiornaFaultSensorDrift(dt_s);

    // ══════════════════════════════════════════════════════════════════
    //  EVAPORAZIONE ACQUA (CONSERVAZIONE ENERGIA)
    // ══════════════════════════════════════════════════════════════════
    // Se la temperatura supera il punto di ebollizione alla pressione attuale,
    // l'energia in eccesso viene convertita in calore latente di vaporizzazione
    // (2260 kJ/kg). L'evaporazione riduce la massa acqua ma mantiene l'energia
    // del sistema costante (primo principio della termodinamica).
    //
    // Limite fisico: potenza evaporazione max 5kW (realistico per resistenza 12kW)
    if (p_massa_acqua > 0.0f && temp_serbatoio > t_ebollizione) {
        float Q_ex = p_massa_acqua * cp_fluido * (temp_serbatoio - t_ebollizione);
        // Cap in W invece di kg/s per coerenza fisica (max potenza disponibile per vaporizzazione)
        constexpr float Q_EVAP_MAX_W = 5000.0f;  // 5 kW max potenza evaporazione (realistico per resistenza 12kW)
        float Q_evap_max = Q_EVAP_MAX_W * dt_s;
        if (Q_ex > Q_evap_max) {
            // Energia non smaltita dall'evaporazione: resta come sovratemperatura residua
            float Q_residua = Q_ex - Q_evap_max;
            temp_serbatoio = t_ebollizione + (Q_residua / capacitaSicura(massaTermicaSerbatoioEffettiva(p_massa_acqua) * cp_fluido));
            float m_persa = Q_evap_max / 2260000.0f;
            p_massa_acqua -= m_persa;
        } else {
            temp_serbatoio = t_ebollizione;
            float m_persa = Q_ex / 2260000.0f;  // 2260 kJ/kg calore latente vaporizzazione
            p_massa_acqua -= m_persa;
        }
        if (p_massa_acqua < 0.0f) p_massa_acqua = 0.0f;
    }

    temp_resistenza    = clampTempDiag(temp_resistenza);
    temp_metallo       = clampTempDiag(temp_metallo);
    temp_nucleo_res    = clampTempDiag(temp_nucleo_res);
    temp_serbatoio     = clampTempPerFluido(temp_serbatoio, is_olio);
    temp_tubi          = clampTempPerFluido(temp_tubi, is_olio);
    temp_stampo        = clampTempPerFluido(temp_stampo, is_olio);
    t_mandata_reale    = clampTempPerFluido(t_mandata_reale, is_olio);
    t_ritorno_reale    = clampTempPerFluido(t_ritorno_reale, is_olio);
    t_mandata_stasi    = clampTempPerFluido(t_mandata_stasi, is_olio);
    t_ritorno_stasi    = clampTempPerFluido(t_ritorno_stasi, is_olio);

    if (p_massa_acqua < 0.0f) p_massa_acqua = 0.0f;
    if (p_massa_acqua > MASSA_ACQUA_NOMINALE) p_massa_acqua = MASSA_ACQUA_NOMINALE;

    // Difesa in profondità: allarme serbatoio vuoto da modello fisico (bypass sensore)
    if (p_massa_acqua <= MASSA_SERBATOIO_VUOTO_ON_KG && !alarm_serbatoio_vuoto) {
        alarm_serbatoio_vuoto = true;
        errore_acqua = true;
        Serial.println(F("ALLARME [DIFESA]: serbatoio vuoto rilevato da modello fisico (bypass sensore)"));
    }

    // ══════════════════════════════════════════════════════════════════
    //  SIMULAZIONE SONDE PT1000 CON CALIBRAZIONE SPI
    // ══════════════════════════════════════════════════════════════════
    // Le sonde reali sono simulate con:
    // 1. Filtro termico (tau = 6s) per simulare inerzia termica PT1000
    // 2. Offset di calibrazione (r_offset_*) convertito da ohm a °C
    // 3. Deriva sensore (fault_sensor_drift_offset_c) se guasto attivo
    // 4. Rampa display (+1°C max) per transizione graduale all'avvio
    //
    // L'offset calibrato viene scritto sul potenziometro digitale via SPI
    // per correggere il valore inviato al regolatore esterno.
    float alpha_s = alphaDaTau(dt_s, SONDA_TAU_S);
    temp_sonda_mandata_pura = filtraPL(temp_sonda_mandata_pura, t_mandata_reale, alpha_s);
    temp_sonda_ritorno_pura  = filtraPL(temp_sonda_ritorno_pura, t_ritorno_reale, alpha_s);
    
    // Applica offset di calibrazione convertendo ohm in °C (simula potenziometro digitale)
    float offset_mandata_c = r_offset_mandata_ohm / pendenzaLocalePt1000(temp_sonda_mandata_pura);
    float offset_ritorno_c = r_offset_ritorno_ohm / pendenzaLocalePt1000(temp_sonda_ritorno_pura);
    
    // Guasto 3 (deriva sensore) applicato solo alla sonda di mandata
    temp_sonda_mandata = temp_sonda_mandata_pura + fault_sensor_drift_offset_c + offset_mandata_c;
    temp_sonda_ritorno  = temp_sonda_ritorno_pura + offset_ritorno_c;

    // Rampa automatica SOLO DISPLAY: aggiunge gradualmente fino a
    // STARTUP_DISPLAY_RAMP_MAX_C al valore mostrato, ma avanza SOLO quando la
    // macchina è accesa e c'è un comando di caldo o freddo attivo. A macchina
    // ferma o senza comando l'accumulatore resta congelato (non si azzera,
    // semplicemente non avanza) e nessuna scrittura SPI viene comunque fatta.
    {
        const bool comando_caldo_o_freddo = (frac_caldo > 0.0f) || richiesta_freddo;
        if (macchina_accesa && comando_caldo_o_freddo) {
            ramp_display_accum_ms += dt_s * 1000.0f;
            if (ramp_display_accum_ms > (float)STARTUP_DISPLAY_RAMP_MS) {
                ramp_display_accum_ms = (float)STARTUP_DISPLAY_RAMP_MS;
            }
        }
        float ramp_frac = ramp_display_accum_ms / (float)STARTUP_DISPLAY_RAMP_MS;
        ramp_frac = clampFloat(ramp_frac, 0.0f, 1.0f);
        float startup_ramp_c = ramp_frac * STARTUP_DISPLAY_RAMP_MAX_C;

        // Il display deve restituire la temperatura reale del sistema
        // escludendo l'offset di calibrazione applicato ai potenziometri.
        temp_sonda_mandata_display = temp_sonda_mandata_pura + fault_sensor_drift_offset_c + startup_ramp_c;
        temp_sonda_ritorno_display = temp_sonda_ritorno_pura + startup_ramp_c;
    }

    // Scrive l'offset sul potenziometro digitale per correggere il valore inviato al regolatore esterno
    aggiornaCalibrazionePT1000(CS_MANDATA, t_mandata_reale, r_offset_mandata_ohm, dither_accum_mandata);
    aggiornaCalibrazionePT1000(CS_RITORNO, t_ritorno_reale, r_offset_ritorno_ohm, dither_accum_ritorno);

    checkAlarms(t_mandata_reale, t_ritorno_reale, flusso_lmin, richiesta_freddo, circuito_idraulico_attivo, frac_caldo, frac_caldo_raw, pressione_effettiva_bar, now);
    aggiornaRifornimentoAcqua(now);

    // Log JSON telemetria ogni 1 secondo (dopo handshake)
    if (now - t_log >= 1000UL) {
        t_log = now;
        // Emissione telemetria solo dopo handshake col PC
        if (!handshake_done) return;
        const int alm_bits = (alarm_boiling                 ? 0x001 : 0)
                           | (alarm_dry_run                  ? 0x002 : 0)
                           | (alarm_pump_fail                ? 0x004 : 0)
                           | (warning_thermal_shock          ? 0x008 : 0)
                           | (alarm_circulation_insufficient ? 0x010 : 0)
                           | (alarm_serbatoio_vuoto          ? 0x020 : 0)
                           | (alarm_cavitation               ? 0x040 : 0)
                           | (alarm_sensor_dislodged         ? 0x080 : 0)
                           | (alarm_overheat_res             ? 0x100 : 0)
                           | (alarm_alta_pressione           ? 0x200 : 0)
                           | (alarm_aria_circuito            ? 0x400 : 0)
                           | (alarm_perdita_acqua            ? 0x800 : 0)
                           | (alarm_float_failure            ? 0x1000 : 0)
                           | (alarm_heater_short             ? 0x2000 : 0);

        const int flt_bits = (fault_clogging_active        ? 0x001 : 0)
                           | (fault_scaling_active         ? 0x002 : 0)
                           | (fault_insulation_loss_active ? 0x004 : 0)
                           | (fault_sensor_drift_active    ? 0x008 : 0)
                           | (fault_heater_failure_active   ? 0x010 : 0)
                           | (fault_valve_stuck_closed      ? 0x020 : 0)
                           | (fault_valve_stuck_open        ? 0x040 : 0)
                           | (fault_air_in_circuit          ? 0x080 : 0)
                           | (fault_heater_short_active     ? 0x100 : 0)
                           | (fault_float_stuck_high        ? 0x200 : 0)
                           | (fault_float_stuck_low         ? 0x400 : 0)
                           | (fault_float_no_signal         ? 0x800 : 0);

        // Ore manutenzione e usura pompa per telemetria
        const double ore_pompa_h = (double)ore_pompa_s / 3600000.0;
        const double ore_res_h   = (double)ore_resistenza_s / 3600000.0;
        const double ore_hx_h    = (double)ore_hx_s / 3600000.0;
        const double usura_h     = constrain(ore_pompa_h * PUMP_WEAR_PER_HOUR * 100.0, 0.0, 25.0);  // usura in %
        // Potenza elettrica pompa (motore): valore separato da "qpump" (che è solo
        // il calore parassita ceduto all'acqua per inefficienza, quasi sempre ~0
        // perché di default la pompa è modellata al 100% di efficienza).
        // Qui invece è la potenza reale assorbita dal motore quando è in funzione,
        // scalata con la portata attuale rispetto alla nominale (affinità pompe).
        const float pompa_pot_el_w = stato_pompa
            ? POMPA_POT_ELETTRICA_NOMINALE_W * clampFloat(p_portata / PORTATA_NOMINALE_LMIN, 0.15f, 1.0f)
            : 0.0f;
        // Efficienza/marcia pompa effettiva (stessa logica di stampaStatoSintetico)
        const bool pompa_effettiva = (stato_pompa && p_portata > 0.0f && !alarm_serbatoio_vuoto);

        // Telemetria JSON completa: tutti i dati disponibili (termici, energetici, flusso)
        Serial.printf(
            "{\"pompa\":%d,\"freddo\":%d,\"riemp\":%d,"
            "\"serb\":%.2f,\"mand\":%.2f,\"rit\":%.2f,"
            "\"acqua\":%.2f,\"port\":%.1f,\"pres\":%.2f,\"alm\":%d,\"flt\":%d,"
            "\"res\":%.2f,\"met\":%.2f,\"nucl\":%.2f,\"tubi\":%.2f,\"stampo\":%.2f,"
            "\"qhx\":%.0f,\"qraff\":%.0f,\"qfill\":%.0f,\"qconv\":%.0f,\"qproc\":%.0f,\"qpump\":%.0f,"
            "\"ost\":%.2f,\"pompaeff\":%d,\"pompapotel\":%.0f,"
            "\"orepompa\":%.1lf,\"oreres\":%.1lf,\"orehx\":%.1lf,\"usurapompa\":%.2lf}\n",
            stato_pompa ? 1 : 0,
            richiesta_freddo ? 1 : 0,
            rele_carico_acqua ? 1 : 0,
            temp_serbatoio,
            temp_sonda_mandata_display,
            temp_sonda_ritorno_display,
            p_massa_acqua,
            p_portata,
            pressione_effettiva_bar,
            alm_bits,
            flt_bits,
            temp_resistenza,
            temp_metallo,
            temp_nucleo_res,
            temp_tubi,
            temp_stampo,
            last_q_scambiatore,
            last_q_raffreddamento,
            last_q_iniezione,
            last_q_conv,
            last_q_proc,
            last_q_pompa,
            p_ostruzione_circuito,
            pompa_effettiva ? 1 : 0,
            pompa_pot_el_w,
            ore_pompa_h,
            ore_res_h,
            ore_hx_h,
            usura_h
        );
    }
}

