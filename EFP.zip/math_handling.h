#ifndef MATH_HANDLING_H
#define MATH_HANDLING_H

#include <Arduino.h>
#include <math.h>
#include "system.h"
#include "table.h"

// ══════════════════════════════════════════════════════════════════
//  UTILITÀ NUMERICHE
// ══════════════════════════════════════════════════════════════════
// Limita un valore float tra min e max
inline float clampFloat(float x, float lo, float hi) {
    return constrain(x, lo, hi);
}

// Limita temperatura a range realistico [-20°C, 180°C]
inline float clampTempRealistica(float t) {
    return clampFloat(t, -20.0f, 180.0f);
}

// Limita temperatura per diagnostici [-20°C, 260°C]
inline float clampTempDiag(float t) {
    return clampFloat(t, -20.0f, 260.0f);
}

// Limita temperatura in base al fluido: olio [-20°C, 300°C], acqua [-20°C, 180°C]
inline float clampTempPerFluido(float t, bool is_olio) {
    if (is_olio) {
        return clampFloat(t, -20.0f, 300.0f);
    } else {
        return clampFloat(t, -20.0f, 180.0f);
    }
}

// Calcola coefficiente alpha per filtro esponenziale: α = dt / (τ + dt)
inline float alphaDaTau(float dt_s, float tau_s) {
    if (dt_s <= 0.0f) return 0.0f;  // dt_s <= 0 blocca i filtri PL (alpha=0 → y_prec immutato)
    if (tau_s <= 0.0f) return 1.0f;
    float alpha = dt_s / (tau_s + dt_s);
    return clampFloat(alpha, 0.0f, 1.0f);
}

// ══════════════════════════════════════════════════════════════════
//  PROPRIETÀ DELL'ACQUA
// ══════════════════════════════════════════════════════════════════
// Calcola portata effettiva considerando ostruzione (temp non usato per evitare feedback loop)
inline float portataDinamicaLMin(float portata_base_lmin, float temp_acqua_c, float ostruzione_circuito) {
    (void)temp_acqua_c; // Parametro non usato per evitare feedback loop
    float base = max(portata_base_lmin, 0.0f);
    if (base <= 0.0f) return 0.0f;

    // Correzione per ostruzione: riduce la portata proporzionalmente
    float fattore_ostruzione = 1.0f - clampFloat(ostruzione_circuito, 0.0f, 1.0f);
    fattore_ostruzione = clampFloat(fattore_ostruzione, 0.0f, 1.0f);

    return base * fattore_ostruzione;
}

// Calcola temperatura ebollizione acqua da pressione (equazione Antoine)
inline float temperaturaEbollizioneDaPressioneBar(float pressione_bar) {
    // Antoine semplificata per l'acqua.
    // pressione_bar è una sovrapressione (gauge): 0 bar = pressione atmosferica = 100°C.
    // Va convertita in pressione ASSOLUTA prima di entrare nella formula di Antoine,
    // altrimenti per pressioni positive piccole si otterrebbe una pressione assoluta
    // vicina allo zero (quasi vuoto) e quindi una T di ebollizione bassissima:
    // un crollo fisicamente sbagliato invece dell'aumento atteso.
    const float P_ATM_BAR = 1.01325f;  // pressione atmosferica di riferimento

    float p_gauge = clampFloat(pressione_bar, 0.0f, 5.0f);
    float p_assoluta_bar = p_gauge + P_ATM_BAR;
    float p_mmhg = p_assoluta_bar * 750.061683f;

    const float A = 8.07131f;
    const float B = 1730.63f;
    const float C = 233.426f;

    float denom = A - log10f(max(p_mmhg, 1.0f));
    if (fabsf(denom) < 1.0e-6f) return 100.0f;
    float t = B / denom - C;
    return clampFloat(t, 100.0f, 180.0f);
}

// Calcola LMTD (Log Mean Temperature Difference) per scambiatori di calore
inline float mediaLogaritmicaDeltaT(float dt1, float dt2) {
    float a = fabsf(dt1);
    float b = fabsf(dt2);

    if (a <= 0.0f && b <= 0.0f) return 0.0f;
    if (a <= 0.0f) return b;
    if (b <= 0.0f) return a;
    if (fabsf(a - b) < 0.01f * a) return 0.5f * (a + b);

    float rapporto = a / b;
    if (rapporto <= 0.0f) return 0.5f * (a + b);

    return (a - b) / logf(rapporto);
}

// Calcola LMTD scambiatore considerando effetto flusso
inline float lmtdScambiatore(float t_sorgente, float t_destinazione, float portata_lmin) {
    // Formula pratica: la differenza di temperatura viene "smussata" dal flusso
    float delta1 = t_sorgente - t_destinazione;
    if (delta1 <= 0.0f) return 0.0f;

    float fattore_flusso = clampFloat(portata_lmin / PORTATA_NOMINALE_LMIN, 0.20f, 3.0f);
    // delta2 è calcolato come frazione di delta1, quindi è sempre <= delta1 (Secondo Principio)
    float divisore = 1.0f + 0.35f * fattore_flusso;   // >= 1.07, sempre > 1
    float delta2 = delta1 / divisore;                  // delta2 < delta1 per costruzione
    // Salvaguardia numerica: evita delta2 negativo o nullo (non fisico)
    if (delta2 < 0.001f) delta2 = 0.001f;
    // Garanzia del Secondo Principio: delta2 non può mai superare delta1
    if (delta2 > delta1) delta2 = delta1;

    return mediaLogaritmicaDeltaT(delta1, delta2);
}

// Calcola ostruzione effettiva (base + guasto simulato +60%)
inline float coefficienteOstruzioneEffettivo(float ostruzione_base, bool fault_clogging) {
    float totale = clampFloat(ostruzione_base, 0.0f, 1.0f);
    if (fault_clogging) totale += 0.60f;  // Guasto aggiunge 60% ostruzione
    return clampFloat(totale, 0.0f, 1.0f);
}

// ══════════════════════════════════════════════════════════════════
//  PT1000 FORWARD MODEL (temperatura -> resistenza)
// ══════════════════════════════════════════════════════════════════
// Calcola resistenza PT1000 da temperatura (Calendar-Van Dusen)
inline float tempAResistenza(float t_c) {
    float t = clampFloat(t_c, PT1000_MIN_TEMP_C, PT1000_MAX_TEMP_C);
    float r = R0_PT1000 * (1.0f + CVD_A * t + CVD_B * t * t);
    if (t < 0.0f) {
        // Termine cubico solo per temperature negative
        r += R0_PT1000 * CVD_C * (t - 100.0f) * t * t * t;
    }
    return max(r, PT1000_SAFE_MIN_RES_OHM);
}

// Calcola resistenza PT1000 con offset calibrazione hardware
inline float resistenzaPt1000Corretta(float t_c, float offset_ohm) {
    float r = tempAResistenza(t_c) + offset_ohm;
    return clampFloat(r, PT1000_SAFE_MIN_RES_OHM, PT1000_SAFE_MAX_RES_OHM);
}

// ══════════════════════════════════════════════════════════════════
//  PT1000 INVERSE MODEL (resistenza -> temperatura)
// ══════════════════════════════════════════════════════════════════
// Calcola temperatura PT1000 da resistenza (Newton-Raphson)
inline float tempDaResistenzaPt1000(float r_ohm) {
    float r = clampFloat(r_ohm, PT1000_SAFE_MIN_RES_OHM, PT1000_SAFE_MAX_RES_OHM);
    // Stima iniziale lineare (solo termine A)
    float t = (r / R0_PT1000 - 1.0f) / CVD_A;
    t = clampFloat(t, PT1000_MIN_TEMP_C, PT1000_MAX_TEMP_C);

    // Iterazione Newton-Raphson (max 8 passi)
    for (int i = 0; i < 8; ++i) {
        float f = 0.0f;
        float df = 0.0f;
        if (t >= 0.0f) {
            // Equazione quadratica per T >= 0
            f  = R0_PT1000 * (1.0f + CVD_A * t + CVD_B * t * t) - r;
            df = R0_PT1000 * (CVD_A + 2.0f * CVD_B * t);
        } else {
            // Equazione cubica per T < 0
            float t2 = t * t;
            float t3 = t2 * t;
            f  = R0_PT1000 * (1.0f + CVD_A * t + CVD_B * t2 + CVD_C * (t - 100.0f) * t3) - r;
            df = R0_PT1000 * (CVD_A + 2.0f * CVD_B * t + CVD_C * (4.0f * t3 - 300.0f * t2));
        }

        if (fabsf(df) < 1e-8f) break;
        t -= f / df;
        t = clampFloat(t, PT1000_MIN_TEMP_C, PT1000_MAX_TEMP_C);
    }

    // Fallback: se l'iterazione non converge, usa formula lineare
    if (fabsf(R0_PT1000 * (1.0f + CVD_A * t + CVD_B * t * t + (t < 0.0f ? CVD_C * (t - 100.0f) * t * t * t : 0.0f)) - r) > 1.0f) {
        t = (r / R0_PT1000 - 1.0f) / CVD_A;
        t = clampFloat(t, PT1000_MIN_TEMP_C, PT1000_MAX_TEMP_C);
    }

    return t;
}

// ══════════════════════════════════════════════════════════════════
//  BILANCI ENERGETICI
// ══════════════════════════════════════════════════════════════════
// Filtro esponenziale passa-basso: y = y + α(x - y)
inline float filtraPL(float y_prec, float x_nuovo, float alpha) {
    return y_prec + alpha * (x_nuovo - y_prec);
}

// Calcola potenza riscaldamento da frazione comando
inline float potenzaRiscaldo(float fraz_caldo, float p_max_w) {
    return fraz_caldo * p_max_w;
}

// Calcola potenza scambiata da scambiatore usando LMTD
inline float potenzaScambiatore(bool attivo,
                                float t_serb,
                                float t_rete,
                                float k_hx,
                                float portata_lmin) {
    if (!attivo || k_hx <= 0.0f) return 0.0f;
    float lmtd = lmtdScambiatore(t_serb, t_rete, portata_lmin);
    return k_hx * lmtd;
}

// Overload con portata nominale di default
inline float potenzaScambiatore(bool attivo,
                                float t_serb,
                                float t_rete,
                                float k_hx) {
    return potenzaScambiatore(attivo, t_serb, t_rete, k_hx, PORTATA_NOMINALE_LMIN);
}

// Calcola potenza raffreddamento unità (Q = ṁ·cp·ΔT)
inline float potenzaRaffreddamento(bool attivo,
                                   float t_serbatoio,
                                   float t_rete,
                                   float portata_kgs,
                                   float cp_fluido) {
    if (!attivo || portata_kgs <= 0.0f) return 0.0f;
    float dT = t_serbatoio - t_rete;
    if (dT <= 0.0f) return 0.0f;
    return portata_kgs * cp_fluido * dT;
}

// ══════════════════════════════════════════════════════════════════
//  RICERCA SU TABELLA POTENZIOMETRO DIGITALE
// ══════════════════════════════════════════════════════════════════
// Cerca configurazione potenziometro più vicina (ricerca binaria)
inline bytes8_t trovaPassiPotenziometro(float r_target) {
    float r_pot = r_target - R_FISSA;
    if (r_pot <= table[0].r_tot)            return table[0];
    if (r_pot >= table[TAB_SIZE - 1].r_tot) return table[TAB_SIZE - 1];

    // Ricerca binaria
    int left = 0;
    int right = TAB_SIZE - 1;
    while (left + 1 < right) {
        int mid = left + (right - left) / 2;
        if (table[mid].r_tot < r_pot) left = mid;
        else                          right = mid;
    }

    // Restituisce il valore più vicino tra left e right
    return (fabsf(table[left].r_tot - r_pot) <= fabsf(table[right].r_tot - r_pot))
             ? table[left]
             : table[right];
}

// Coppia di gradini adiacenti del potenziometro con frazione di interpolazione.
// Usata per il dithering temporale anti-saltelli (vedi trovaPassiPotenziometroInterpolati).
struct PassiInterpolati {
    bytes8_t lo;    // Gradino appena sotto r_target
    bytes8_t hi;    // Gradino appena sopra r_target (== lo se fuori range o gap nullo)
    float    frac;  // Posizione di r_target tra lo e hi, [0,1]: 0=lo esatto, 1=hi esatto
};

// Restituisce coppia di gradini adiacenti del potenziometro con frazione di interpolazione.
// Implementa dithering temporale per evitare saltelli nella resistenza quando la temperatura
// attraversa il punto medio tra due gradini della tabella lookup. Alternando tra i due
// gradini adiacenti con duty-cycle proporzionale alla frazione, la resistenza media nel
// tempo converge al valore continuo desiderato invece di rimanere quantizzata.
inline PassiInterpolati trovaPassiPotenziometroInterpolati(float r_target) {
    float r_pot = r_target - R_FISSA;
    if (r_pot <= table[0].r_tot)            return { table[0], table[0], 0.0f };
    if (r_pot >= table[TAB_SIZE - 1].r_tot) return { table[TAB_SIZE - 1], table[TAB_SIZE - 1], 0.0f };

    int left = 0;
    int right = TAB_SIZE - 1;
    while (left + 1 < right) {
        int mid = left + (right - left) / 2;
        if (table[mid].r_tot < r_pot) left = mid;
        else                          right = mid;
    }

    float r_lo = table[left].r_tot;
    float r_hi = table[right].r_tot;
    float frac = (r_hi > r_lo) ? (r_pot - r_lo) / (r_hi - r_lo) : 0.0f;
    frac = constrain(frac, 0.0f, 1.0f);
    return { table[left], table[right], frac };
}

// Restituisce true se la resistenza richiesta cade fuori dal range
// rappresentabile dal potenziometro digitale (tabella). In questo caso
// trovaPassiPotenziometro() blocca sul primo/ultimo elemento e QUALSIASI
// temperatura oltre quel limite produce sempre lo STESSO valore fisico:
// non esiste correzione software che possa "spingere" oltre l'hardware.
inline bool fuoriRangeTabellaPotenziometro(float r_target) {
    float r_pot = r_target - R_FISSA;
    return (r_pot <= table[0].r_tot) || (r_pot >= table[TAB_SIZE - 1].r_tot);
}

// Resistenza TOTALE realmente ottenibile dal potenziometro digitale
// (front-end + step discreto più vicino), cioè quella che l'hardware
// scriverà davvero via SPI. Serve a sapere cosa "vede" per davvero il
// regolatore esterno, invece di ragionare solo sul valore ideale continuo.
inline float resistenzaTotaleQuantizzata(float r_target) {
    bytes8_t passi = trovaPassiPotenziometro(r_target);
    return passi.r_tot + R_FISSA;
}

// Offset [Ω] REALMENTE applicato dall'hardware per un dato punto di lavoro,
// dopo la quantizzazione sul potenziometro digitale. È il valore che va
// tenuto come stato di calibrazione (non l'offset ideale non quantizzato),
// altrimenti ogni CALIBRA successivo riparte da un numero che l'hardware
// non ha mai effettivamente realizzato, e l'errore residuo si accumula o
// "balla" invece di convergere.
inline float offsetOhmRealizzato(float temperatura_c, float offset_desiderato_ohm) {
    float r_target = resistenzaPt1000Corretta(temperatura_c, offset_desiderato_ohm);
    float r_reale  = resistenzaTotaleQuantizzata(r_target);
    return r_reale - tempAResistenza(temperatura_c);
}

// ══════════════════════════════════════════════════════════════════
//  AUTOCALIBRAZIONE — SUPPORTO MATEMATICO
// ══════════════════════════════════════════════════════════════════
// Calcola pendenza locale dR/dT PT1000 (derivata analitica Calendar-Van Dusen)
inline float pendenzaLocalePt1000(float t_c) {
    float t = clampFloat(t_c, PT1000_MIN_TEMP_C, PT1000_MAX_TEMP_C);
    if (t >= 0.0f) {
        return R0_PT1000 * (CVD_A + 2.0f * CVD_B * t);
    }
    // Derivata del termine cubico aggiunta per T<0
    float t2 = t * t;
    return R0_PT1000 * (CVD_A + 2.0f * CVD_B * t + CVD_C * (4.0f * t2 * t - 300.0f * t2));
}

// Errore residuo di quantizzazione [°C] nel punto di lavoro: differenza tra
// l'offset realmente scrivibile sul potenziometro e quello ideale richiesto,
// convertita in gradi tramite la pendenza locale della curva PT1000.
// Rappresenta il limite fisico di precisione oltre il quale nessuna
// ricalibrazione software può migliorare il risultato.
inline float residuoQuantizzazioneC(float temperatura_c, float offset_desiderato_ohm) {
    float offset_reale = offsetOhmRealizzato(temperatura_c, offset_desiderato_ohm);
    float pendenza = pendenzaLocalePt1000(temperatura_c);
    if (fabsf(pendenza) < 1e-6f) pendenza = R0_PT1000 * CVD_A;
    return (offset_reale - offset_desiderato_ohm) / pendenza;
}

// Calcola offset calibrazione per annullare errore di lettura (usa pendenza locale)
inline float calcolaOffsetCorretto(float t_letta, float t_vera, float offset_attuale) {
    float errore_c = t_letta - t_vera;               // errore di lettura [°C], positivo se si legge troppo alto
    float pendenza = pendenzaLocalePt1000(t_vera);    // Ω/°C nel punto vero
    if (fabsf(pendenza) < 1e-6f) pendenza = R0_PT1000 * CVD_A;  // fallback di sicurezza
    float correzione_ohm = errore_c * pendenza;       // Ω da aggiungere per annullare l'errore
    return offset_attuale + correzione_ohm;
}

// Stima incertezza residua dopo calibrazione (tolleranze hardware non compensabili)
inline float incertezzaResiduaStimataC(float t_c) {
    float pendenza = fabsf(pendenzaLocalePt1000(t_c));
    if (pendenza < 1e-6f) pendenza = R0_PT1000 * CVD_A;

    float incertezza_r_fissa_ohm = R_FISSA * R_FISSA_TOLLERANZA_PCT;
    float incertezza_pot_ohm     = POT_DIGITALE_INL_OHM;

    // Le due fonti in Ω si convertono in °C tramite la pendenza locale e si
    // sommano in quadratura con la tolleranza PT1000 (già espressa in °C).
    float incertezza_r_c   = incertezza_r_fissa_ohm / pendenza;
    float incertezza_pot_c = incertezza_pot_ohm / pendenza;
    float incertezza_pt1000_c = PT1000_CLASSE_B_TOLL_BASE_C
                               + PT1000_CLASSE_B_TOLL_COEFF * fabsf(t_c);

    return sqrtf(incertezza_r_c * incertezza_r_c
               + incertezza_pot_c * incertezza_pot_c
               + incertezza_pt1000_c * incertezza_pt1000_c);
}

#endif