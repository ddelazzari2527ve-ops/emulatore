#ifndef SYSTEM_H
#define SYSTEM_H

#include <Arduino.h>

// ══════════════════════════════════════════════════════════════════
//  STRUTTURA DATI PER LA TABELLA DEI POTENZIOMETRI DIGITALI
// ══════════════════════════════════════════════════════════════════
// Struttura per configurazione potenziometro digitale (calibrazione PT1000 via SPI)
struct bytes8_t {
    uint16_t p1;      // Primo byte di configurazione (MSB)
    uint16_t p2;      // Secondo byte di configurazione (LSB)
    float    r_tot;   // Resistenza totale equivalente [Ω]
};

// ══════════════════════════════════════════════════════════════════
//  MODALITÀ POMPA
// ══════════════════════════════════════════════════════════════════
// Modalità operative pompa
enum PumpMode : uint8_t {
    PUMP_MODE_AUTO = 0,       // Pompa controllata automaticamente in base al comando riscaldamento
    PUMP_MODE_MANUAL_OFF,    // Pompa spenta manualmente (override)
    PUMP_MODE_MANUAL_ON      // Pompa accesa manualmente (override)
};

// ══════════════════════════════════════════════════════════════════
//  PINOUT - ASSEGNAZIONE PIN GPIO
// ══════════════════════════════════════════════════════════════════
// CRITICAL: GPIO4 e GPIO5 sono strapping pins su ESP32. Spostati su GPIO non di strap.
static constexpr uint8_t PIN_CALORE_IN      = 35;  // Ingresso analogico comando calore (ADC)
static constexpr uint8_t PIN_RAFFREDDAMENTO  = 26;   // Ingresso digitale comando freddo (attivo LOW)
static constexpr uint8_t CS_MANDATA         = 14 ;  // Chip Select sonda PT1000 mandata (SPI) - spostato da GPIO5 (strap)
static constexpr uint8_t CS_RITORNO         = 25;  // Chip Select sonda PT1000 ritorno (SPI)
static constexpr uint8_t PIN_RELE_ACQUA     = 27;  // Uscita relè valvola riempimento acqua (attivo LOW)
static constexpr uint8_t PIN_ELETTROVALVOLA_HX = 12;  // Uscita elettrovalvola scambiatore (attivo LOW)

// Pulsanti fisici per simulazione guasti
static constexpr uint8_t FAULT_BTN_1_PIN = 16;   // Pulsante guasto 1 (ostruzione)
static constexpr uint8_t FAULT_BTN_2_PIN = 17;   // Pulsante guasto 2 (calcare)
static constexpr uint8_t FAULT_BTN_3_PIN = 32;   // Pulsante guasto 3 (coibentazione) — evita SPI SCLK GPIO18
static constexpr uint8_t FAULT_BTN_4_PIN = 33;   // Pulsante guasto 4 (deriva sensore) — evita SPI MISO GPIO19
static constexpr uint8_t FAULT_BTN_5_PIN = 34;   // Pulsante guasto 5 (resistenza bruciata) — evita I2C SDA GPIO21

// ══════════════════════════════════════════════════════════════════
//  COSTANTI TERMODINAMICHE E DI MATERIALI
// ══════════════════════════════════════════════════════════════════
static constexpr float CP_ACQUA               = 4186.0f;   // Calore specifico acqua [J/(kg·K)]
static constexpr float R_FISSA                = 1004.55f;  // Resistenza fissa di front-end PT1000 [Ω]
static constexpr float CP_ACCIAIO             = 500.0f;    // Calore specifico acciaio [J/(kg·K)]
static constexpr float CP_OLIO_VAL            = 2100.0f;   // Calore specifico olio diatermico [J/(kg·K)]
static constexpr float K_STAMPO_DEFAULT       = 300.0f;    // Coefficiente scambio stampo default: ΔT = P/K ≈ 16.7°C a 5kW
static constexpr float MASSA_RES_KG           = 5.0f;      // Massa equivalente termica resistenza [kg] (aumentata per 12kW)
static constexpr float MASSA_METALLO_SERBATOIO_KG = 4.5f;  // Massa metallica del serbatoio [kg]
static constexpr float K_SCAMBIO_RES          = 700.0f;    // Coefficiente scambio resistenza-metallo [W/K] (aumentato per ΔT regime ~17°C a 12kW)
static constexpr float K_METALLO_ACQUA        = 260.0f;    // Coefficiente scambio metallo-acqua [W/K]
static constexpr float K_NUCLEO               = 300.0f;    // Coefficiente scambio nucleo interno [W/K]
static constexpr float M_NUCLEO               = 2.8f;      // Massa equivalente nucleo [kg]
static constexpr float K_RES_DRY              = 18.0f;     // Coefficiente perdita resistenza in secco [W/K]
static constexpr float MASSA_ACQUA_NOMINALE   = 15.0f;     // Massa acqua nominale serbatoio [kg]
static constexpr float MASSA_CRITICA_ACQUA    = 2.0f;      // Soglia critica acqua per allarme dry-run [kg]
static constexpr float MASSA_SICURA_POMPA     = 2.5f;      // Soglia sicurezza per fermare pompa (evita marcia a secco) [kg]
static constexpr float MASSA_TERMICA_MIN      = 0.25f;     // Massa termica minima equivalente [kg]
static constexpr float MASSA_SERBATOIO_VUOTO_ON_KG  = 1.0f; // Soglia attivazione rifornimento [kg]
static constexpr float MASSA_SERBATOIO_VUOTO_OFF_KG = 4.0f; // Soglia disattivazione rifornimento [kg]
static constexpr float PORTATA_NOMINALE_LMIN  = 20.0f;     // Portata nominale pompa [L/min]
static constexpr float PORTATA_MIN_CIRC_LMIN   = 1.0f;      // Portata minima per circolazione sufficiente [L/min]
static constexpr float PORTATA_PERDITA_LMIN    = 0.5f;      // Portata equivalente perdita/recupero [L/min]
static constexpr float PORTATA_VALVOLA_MAX_LMIN = 20.0f;    // Portata massima valvola riempimento [L/min]
// PUMP_HEAT_W rimosso: apporto termico pompa modellato come p_dt_pompa [°C/h]
static constexpr float THERMAL_SHOCK_DELTA_C    = 40.0f;    // Delta temperatura per allarme shock termico [°C]
static constexpr float POTENZA_RISCALDO_MAX_W   = 25000.0f; // Potenza massima resistenza riscaldamento [W]
static constexpr float POTENZA_RAFFREDDAMENTO_MAX_W = 120000.0f; // Potenza massima unità raffreddamento [W]
static constexpr float POMPA_POT_ELETTRICA_NOMINALE_W = 750.0f; // Potenza elettrica nominale motore pompa [W] (tipica pompa centrifuga circolazione) - solo telemetria, non entra nel bilancio termico

// ══════════════════════════════════════════════════════════════════
//  PT1000 — CALLENDAR-VAN DUSEN (equazione IEC 60751)
// ══════════════════════════════════════════════════════════════════
static constexpr float R0_PT1000                = 1000.0f;   // Resistenza PT1000 a 0°C [Ω]
static constexpr float CVD_A                    = 3.9083e-3f; // Coefficiente A Calendar-Van Dusen [1/K]
static constexpr float CVD_B                    = -5.775e-7f; // Coefficiente B Calendar-Van Dusen [1/K²]
static constexpr float CVD_C                    = -4.183e-12f;// Coefficiente C Calendar-Van Dusen [1/K⁴] (solo T<0)
static constexpr float PT1000_MIN_TEMP_C        = -200.0f;   // Temperatura minima misurabile [°C]
static constexpr float PT1000_MAX_TEMP_C        = 630.0f;   // Temperatura massima misurabile [°C] (limitata da tabella potenziometro: max r_tot=3504.55Ω a ~641°C)
static constexpr float PT1000_SAFE_MIN_RES_OHM  = 18.0f;    // Resistenza minima sicura [Ω]
static constexpr float PT1000_SAFE_MAX_RES_OHM  = 5000.0f;   // Resistenza massima sicura [Ω]

// Offset calibrazione sonde PT1000 (runtime, non persistenti). Determinati con autocalibrazione (CALIBRA).
extern float r_offset_mandata_ohm;   // Offset di calibrazione canale mandata [Ω]
extern float r_offset_ritorno_ohm;   // Offset di calibrazione canale ritorno [Ω]

// Tolleranze hardware front-end per stima incertezza residua (non compensabili da offset)
static constexpr float R_FISSA_TOLLERANZA_PCT      = 0.001f;  // Tolleranza resistore front-end 0.1% (classe metal-film precisione)
static constexpr float POT_DIGITALE_INL_OHM        = 2.0f;     // Non-linearità integrale tipica potenziometro digitale [Ω] (~1-2 LSB)
static constexpr float PT1000_CLASSE_B_TOLL_BASE_C = 0.30f;   // Tolleranza base PT1000 classe B a 0°C secondo IEC 60751 [°C]
static constexpr float PT1000_CLASSE_B_TOLL_COEFF  = 0.005f;  // Coefficiente crescita tolleranza classe B con |T| [°C/°C] (IEC: ±(0.30+0.005·|T|))

// Numero di campioni usati dall'autocalibrazione per mediare il rumore di lettura
static constexpr int   AUTOCAL_N_CAMPIONI          = 20;      // Campioni mediati per ogni canale durante CALIBRA
static constexpr unsigned long AUTOCAL_DT_MS       = 100UL;   // Intervallo fra campioni durante CALIBRA [ms]
static constexpr float AUTOCAL_MAX_OFFSET_OHM      = 15.0f;   // Limite sicurezza sull'offset calcolabile [Ω] (oltre = probabile sonda guasta)
// Parametri ADC / sonde / filtri
// Soglie ADC abbassate per catturare segnali a bassa potenza (termoregolatore reale eroga calore anche al 2-3%)
static constexpr int   ADC_ZERO_SOGLIA  = 20;        // Soglia zero ADC (rumore)
static constexpr float ADC_CALDO_MAX    = 2145.0f;   // Valore massimo ADC comando caldo
static constexpr float ADC_ALPHA         = 0.15f;     // Costante alpha filtro ingresso caldo [0-1]
static constexpr float HEAT_ON_TH       = 0.010f;     // Soglia isteresi accensione riscaldamento [0-1]
static constexpr float HEAT_OFF_TH      = 0.005f;     // Soglia isteresi spegnimento riscaldamento [0-1]
static constexpr float SONDA_TAU_S      = 6.0f;       // Costante tempo filtro sonda [s] (aumentata per simulare inerzia termica PT1000 reale e ridurre instabilità)

// ══════════════════════════════════════════════════════════════════
//  TIMING REAL-TIME
// ══════════════════════════════════════════════════════════════════
static constexpr unsigned long CICLO_MS          = 100UL;     // Periodo ciclo principale [ms]
static constexpr float         CICLO_S           = 0.100f;    // Periodo ciclo principale [s]
static constexpr float         DT_MAX_S          = 0.30f;     // Delta tempo massimo accettabile [s]
static constexpr float         DEADTIME_S        = 2.0f;      // Dead-time nominale trasporto mandata [s]
static constexpr float         DEADTIME_MAX_S    = 5.0f;      // Dead-time massimo a bassa portata [s]
static constexpr unsigned long TIMEOUT_RAFF_CONF = 5000UL;    // Timeout conferma raffreddamento [ms]

// Buffer dimensionato per coprire ritardi maggiorati a bassa portata
static constexpr int DEAD_BUF_SIZE = 50;                     // Dimensione buffer dead-time circolare

// ══════════════════════════════════════════════════════════════════
//  PARAMETRI CONFIGURABILI — DEFINITI IN EFP.ino
// ══════════════════════════════════════════════════════════════════
extern float p_temp_rete;
extern float p_portata;
extern float p_massa_acqua;
extern float p_pot_risc;
extern float p_pot_raffreddamento;
extern float p_k_hx;
extern float p_pot_stampo;
extern float p_temp_ambiente;
extern float p_k_disp_tubi;
extern float p_k_disp_serbatoio;
extern float p_massa_stampo;
extern float K_stampo;
extern float ff_gain;
extern float p_portata_valvola;
extern float p_ostruzione_circuito;
extern float p_pressione_bar;
extern float p_dt_pompa;           // [°C/h] incremento diretto di temperatura da pompa

// ══════════════════════════════════════════════════════════════════
//  STATO TERMICO — DEFINITO IN EFP.ino
// ══════════════════════════════════════════════════════════════════
extern float temp_resistenza;
extern float temp_resistenza_filtrata;
extern float temp_metallo;
extern float temp_nucleo_res;
extern float temp_serbatoio;
extern float temp_sonda_mandata;
extern float temp_sonda_ritorno;
extern float temp_stampo;
extern float adc_filtrato;
extern float t_mandata_stasi;
extern float t_ritorno_stasi;
extern float t_mandata_reale;
extern float t_ritorno_reale;

// ══════════════════════════════════════════════════════════════════
//  DEAD-TIME BUFFER — DEFINITO IN EFP.ino
// ══════════════════════════════════════════════════════════════════
extern float dead_buffer[DEAD_BUF_SIZE];
extern int   dead_buf_idx;

// ══════════════════════════════════════════════════════════════════
//  FLAG DI CONTROLLO — DEFINITI IN EFP.ino
// ══════════════════════════════════════════════════════════════════
extern bool          errore_acqua;
extern bool          raffreddamento_cmd;
extern bool          perdita_attiva;
extern bool          raffreddamento_attivo;
extern bool          stato_pompa;
extern bool          macchina_accesa;
extern PumpMode      pump_mode;
extern bool          pump_manual_override;
extern bool          rele_carico_acqua;

// ══════════════════════════════════════════════════════════════════
//  FAULT ENGINE — DEFINITO IN EFP.ino
// ══════════════════════════════════════════════════════════════════
extern bool fault_clogging_active;
extern bool fault_scaling_active;
extern bool fault_insulation_loss_active;
extern bool fault_sensor_drift_active;
extern bool fault_heater_failure_active;
extern bool fault_valve_stuck_closed;
extern bool fault_valve_stuck_open;
extern bool fault_air_in_circuit;
extern bool fault_heater_short_active;
extern bool fault_float_stuck_high;
extern bool fault_float_stuck_low;
extern bool fault_float_no_signal;
extern float fault_sensor_drift_offset_c;

// ══════════════════════════════════════════════════════════════════
//  ALLARMI — DEFINITI IN EFP.ino
// ══════════════════════════════════════════════════════════════════
extern bool alarm_boiling;
extern bool alarm_dry_run;
extern bool alarm_pump_fail;
extern bool warning_thermal_shock;
extern bool alarm_circulation_insufficient;
extern bool alarm_serbatoio_vuoto;
extern bool alarm_cavitation;
extern bool alarm_sensor_dislodged;
extern bool alarm_overheat_res;  // Allarme surriscaldamento resistenza
extern bool alarm_alta_pressione;  // Allarme alta pressione
extern bool alarm_aria_circuito;  // Allarme aria nel circuito
extern bool alarm_perdita_acqua;  // Allarme perdita acqua
extern bool alarm_float_failure;  // Guasto sensore livello liquido (galleggiante)
extern bool alarm_heater_short;   // Allarme corto parziale resistenza

// ══════════════════════════════════════════════════════════════════
//  TIMING LOOP — DEFINITI IN EFP.ino
// ══════════════════════════════════════════════════════════════════
extern unsigned long t_last;
extern unsigned long t_log;

#endif