# EFP - Emulator for Fluid Processing

Simulatore termoregolatore industriale basato su ESP32 per sistemi di controllo temperatura.

## Descrizione

EFP è un emulatore hardware/software di un termoregolatore industriale progettato per:
- Simulare il comportamento termodinamico di un sistema di raffreddamento/riscaldamento acqua
- Testare e validare sistemi di controllo PLC/SCADA
- Simulare guasti e condizioni anomale (ostruzioni, deriva sensori, perdite)
- Calibrare sonde PT1000 con autocalibrazione automatica

## Hardware

- **Microcontroller**: ESP32
- **Sonde temperatura**: PT1000 con potenziometri digitali (SPI)
- **Ingressi**: ADC comando calore, digitale comando freddo, pulsanti guasti
- **Uscite**: Relè valvola acqua, elettrovalvola scambiatore

## File Principali

- **EFP.ino**: Main loop, modello fisico termodinamico, gestione allarmi
- **system.h**: Costanti, definizioni pin, strutture dati, parametri configurabili
- **math_handling.h**: Funzioni matematiche (PT1000, bilanci energetici, filtri)
- **table.h**: Tabella lookup potenziometri digitali per calibrazione PT1000

## Funzionalità

### Modello Termodinamico
- Bilancio energetico completo (riscaldamento, scambiatore, raffreddamento, dispersioni)
- Simulazione dead-time trasporto fluido
- Modello multistadio: resistenza → metallo → acqua → mandata/ritorno
- Supporto fluidi: acqua e olio diatermico

### Sensori PT1000
- Modello Calendar-Van Dusen (IEC 60751)
- Calibrazione automatica via potenziometri digitali SPI
- Compensazione deriva termica
- Stima incertezza residua

### Sistema Guasti (12 tipi)
0. Ostruzione circuito
1. Calcare scambiatore
2. Perdita coibentazione
3. Deriva sensore
4. Fase resistenza bruciata
5. Valvola bloccata chiusa
6. Valvola bloccata aperta
7. Aria nel circuito
8. Corto parziale resistenza
9. Galleggiante bloccato alto
10. Galleggiante bloccato basso
11. Sensore rotto/scollegato

### Allarmi
- Bollitura acqua
- Marcia a secco
- Guasto pompa
- Shock termico
- Circolazione insufficiente
- Serbatoio vuoto
- Cavitazione
- Sonda fuori sede
- Surriscaldamento resistenza
- Alta pressione
- Aria nel circuito
- Perdita acqua
- Guasto galleggiante

## Comandi Seriali

- `CALIBRA`: Autocalibrazione sonde PT1000 (richiede pompa OFF)
- `CALIBRA <t_mandata> <t_ritorno>`: Calibrazione con riferimento regolatore esterno
- `POMPA ON/OFF`: Controllo pompa
- `P0/P1/P2`: Modalità pompa (AUTO/MAN-OFF/MAN-ON)
- `SONDE`: Stato sonde PT1000
- `FAULT <n> ON/OFF`: Attiva/disattiva guasto simulato

## Configurazione

I parametri principali sono configurabili in EFP.ino:
- `p_pot_risc`: Potenza riscaldamento [W]
- `p_pot_raffreddamento`: Potenza raffreddamento [W]
- `p_k_hx`: Coefficiente scambiatore [W/K]
- `p_portata`: Portata pompa [L/min]
- `p_massa_acqua`: Massa acqua serbatoio [kg]

## Note Tecniche

- Ciclo principale: 100ms
- Protocollo SPI per potenziometri digitali
- Comunicazione seriale per logging JSON
- Watchdog FreeRTOS per stabilità
- Gestione overflow timestamp con unsigned long long
